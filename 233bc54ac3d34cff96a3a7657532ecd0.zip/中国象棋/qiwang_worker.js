// ============================================================================
//  qiwang_worker.js — 在 Web Worker 中运行 WASM 中国象棋引擎
//  通过 UCCI 协议与主线程 JS 交互：
//    主线程 → worker: { id, cmd }   （cmd 为一行 UCCI 命令，如 "position fen ..."）
//    worker → 主线程: { id, out }   （引擎输出的全部文本行）
//  引擎编译产物 qiwang_engine.js 为 SINGLE_FILE 模式（wasm 已内嵌 base64），
//  因此本 worker 无额外网络请求，file:// 直开也能用。
// ============================================================================
importScripts('qiwang_engine.js');

let engine = null;

createQiwangEngine().then(function (m) {
  engine = m;
  try { engine.ccall('qw_reset', null, [], []); } catch (e) {}
  postMessage({ type: 'ready' });
}).catch(function (e) {
  postMessage({ type: 'error', error: String(e) });
});

self.onmessage = function (e) {
  const d = e.data || {};
  const id = d.id;
  const cmd = d.cmd;
  if (!engine) {
    postMessage({ type: 'error', id: id, error: 'engine not ready' });
    return;
  }
  try {
    engine.ccall('qw_ucci', null, ['string'], [cmd]);
    const out = engine.ccall('qw_take_output', 'string', [], []) || '';
    postMessage({ type: 'line', id: id, out: out });
  } catch (err) {
    postMessage({ type: 'error', id: id, error: String(err) });
  }
};
