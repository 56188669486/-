// 棋王 · 中国象棋（中国象棋 Game），普通对战 + 盲棋翻棋，含内置AI与UCCI WASM引擎接入
class XiangqiGame extends GameBase{
  constructor(mode){
    super('xiangqi',mode==='blind'?'blind':'battle');
    this.ROWS=this.mode==='blind'?4:10;this.COLS=this.mode==='blind'?8:9;
    this.firstSide='red';this.secondSide='black';
    this.board=[];this.currentTurn='red';this.selected=null;
    this.capturedRed=[];this.capturedBlack=[];
    this.lastMove=null;this.offsetX=0;this.offsetY=0;
    this.gameId='xiangqi_'+Date.now()+'_'+Math.floor(Math.random()*9999);
    // 高级AI搜索变量
    this.transpositionTable=new Map();this.historyTable=new Map();this.killerMoves=[];
    this.searchStartTime=0;this.searchTimeLimit=5000;this.maxSearchDepth=12;
    this.searchInterrupted=false;this.nodesSearched=0;this.lastBestMove=null;
    // AI进化系统
    this.aiPersonality='balanced';this.aiMood='normal';
    this.playerSkillTracker={gamesPlayed:0,gamesWon:0,currentStreak:0,effectiveDifficulty:0.5};
    this.aiMistakeChance=0.08;this.aiInspirationChance=0.12;
    this.endMsg=null;
  }
  init(){
    this.canvas=$('gameCanvas');this.ctx=this.canvas.getContext('2d');
    this.board=this.mode==='blind'?this.createBlindBoard():this.createInitialBoard();
    this.currentTurn='red';this.selected=null;this.moveHistory=[];
    this.capturedRed=[];this.capturedBlack=[];this.lastMove=null;
    this.gameOver=false;this.winner=null;this.aiThinking=false;this.endMsg=null;
    this.clearTimers();
    // 清空历史与吃子显示
    this.historyListEl.innerHTML='';
    this.updateCapturedDisplay();
    if(this.mode==='blind'){
      $('capturedBar').classList.add('show');
      $('typeSelector').classList.remove('show');
    } else {
      $('capturedBar').classList.remove('show');
    }
    $('historyPanel').style.display='block';
    this.resize();this.bindEvents();this.updateAiStatus();
    this.draw();
    const ctrl=this.controllerFor('red');
    this.setTurnUI('red');
    this.status(ctrl==='human'?(this.mode==='blind'?'点击暗棋翻开 / 选择己方明棋移动':'点击己方棋子开始'):'');
  }
  destroy(){this.unbindEvents();this.clearTimers();}
  createInitialBoard(){
    const b=Array.from({length:10},()=>Array(9).fill(null));
    const p=(r,c,s,t)=>{b[r][c]={side:s,type:t,revealed:true};};
    const back=['车','马','相','士','帅','士','相','马','车'];
    for(let c=0;c<9;c++){p(0,c,'black',back[c].replace('帅','将').replace('相','象'));p(9,c,'red',back[c]);}
    p(2,1,'black','炮');p(2,7,'black','炮');p(7,1,'red','炮');p(7,7,'red','炮');
    for(let c=0;c<9;c+=2){p(3,c,'black','卒');p(6,c,'red','兵');}
    return b;
  }
  createBlindBoard(){
    const b=Array.from({length:4},()=>Array(8).fill(null));
    const pieces=[];
    ['车','马','相','士','将','士','相','马','车','炮','炮','卒','卒','卒','卒','卒'].forEach(t=>pieces.push({side:'black',type:t,revealed:false}));
    ['车','马','象','士','将','士','象','马','车','炮','炮','兵','兵','兵','兵','兵'].forEach(t=>pieces.push({side:'red',type:t,revealed:false}));
    shuffle(pieces);
    let idx=0;
    for(let r=0;r<4;r++)for(let c=0;c<8;c++){b[r][c]=pieces[idx++];}
    return b;
  }
  resize(){
    const rect=this.canvas.parentElement.getBoundingClientRect();const dpr=window.devicePixelRatio||1;
    this.canvas.width=rect.width*dpr;this.canvas.height=rect.height*dpr;this.ctx.setTransform(dpr,0,0,dpr,0,0);
    if(this.mode==='blind'){
      this.cellSize=Math.min(rect.width/8,rect.height/4);
      this.offsetX=(rect.width-this.cellSize*7)/2;
      this.offsetY=(rect.height-this.cellSize*3)/2;
    }else{
      this.cellSize=Math.min(rect.width/9,rect.height/10);
      this.offsetX=(rect.width-this.cellSize*8)/2;
      this.offsetY=(rect.height-this.cellSize*9)/2;
    }
  }
  bindEvents(){
    this._tap=(e)=>this.handleTap(e);
    this._unbindTap=bindTap(this.canvas,this._tap)||null;
    this._resize=(()=>{this.resize();this.draw();});
    this._orientation=(()=>setTimeout(()=>{this.resize();this.draw();},200));
    window.addEventListener('resize',this._resize);
    window.addEventListener('orientationchange',this._orientation);
  }
  unbindEvents(){
    if(this._unbindTap){try{this._unbindTap();}catch(e){}this._unbindTap=null;}
    if(this._resize)window.removeEventListener('resize',this._resize);
    if(this._orientation)window.removeEventListener('orientationchange',this._orientation);
  }
  getPos(e){
    const rect=this.canvas.getBoundingClientRect();
    const x=e.clientX-rect.left,y=e.clientY-rect.top;
    const col=Math.round((x-this.offsetX)/this.cellSize);
    const row=Math.round((y-this.offsetY)/this.cellSize);
    return{row,col};
  }
  winrateFor(side){const s=this.evaluateBoard(side);return 1/(1+Math.exp(-s/2500));}
  pixelAt(row,col){return{x:this.offsetX+col*this.cellSize,y:this.offsetY+row*this.cellSize};}
  detectDivineXiangqi(side,row,col,captured,beforeWin,afterWin){
    const isKing=captured&&(captured.type==='帅'||captured.type==='将');
    const val=captured?(TYPE_VALUES[captured.type]||0):0;
    const swing=afterWin-beforeWin;
    if(isKing)this.triggerDivine(side,{row,col},'绝杀·直取中军');
    else if(swing>=0.55)this.triggerDivine(side,{row,col},'惊世妙手·逆转乾坤');
    else if(captured&&val>=800&&swing>=0.40)this.triggerDivine(side,{row,col},'神来之笔·一击定势');
  }
  isInBoard(r,c){return r>=0&&r<this.ROWS&&c>=0&&c<this.COLS;}
  isInPalace(r,c,side){return side==='red'?(r>=7&&r<=9&&c>=3&&c<=5):(r>=0&&r<=2&&c>=3&&c<=5);}
  // ===== 人机交互 =====
  handleTap(e){
    if(this.gameOver||this.aiThinking)return;
    if(this.controllerFor(this.currentTurn)!=='human')return;
    const {row,col}=this.getPos(e);
    if(!this.isInBoard(row,col))return;
    const piece=this.board[row][col];
    const side=this.currentTurn;
    if(this.mode==='blind'){
      // 盲棋：已选中暗棋并弹出类型选择器时，点击棋盘=取消
      if(this.selected && !this.selected.revealed && $('typeSelector').classList.contains('show')){
        this.selected=null;this.assumedType=null;
        $('typeSelector').classList.remove('show');
        this.status('已取消');
        this.draw();return;
      }
      if(this.selected){
        if(this.selected.row===row&&this.selected.col===col){this.selected=null;this.draw();return;}
        // 目标位置为未翻开的暗棋时不能落子
        if(piece&&!piece.revealed){this.selected=null;this.draw();return;}
        const moves=this.getBlindMoves(this.selected.row,this.selected.col,this.assumedType);
        if(moves.some(m=>m.row===row&&m.col===col)){
          const st=this.assumedType;
          this.commitMove(this.selected.row,this.selected.col,row,col,st);
          this.selected=null;this.assumedType=null;this.draw();this.afterAction();return;
        }
        if(piece&&piece.revealed&&piece.side===side){this.selected={row,col};this.assumedType=null;this.draw();return;}
        this.selected=null;this.draw();
      }else{
        if(piece&&piece.revealed&&piece.side===side){this.selected={row,col};this.assumedType=null;this.draw();}
        else if(piece&&!piece.revealed&&piece.side===side){
          // 选择己方暗棋：弹出类型选择器（可移动为所选类型，或翻开）
          this.selected={row,col};this.assumedType=null;
          $('typeSelector').classList.add('show');
          this.status('请选择将暗棋当做什么类型移动，或直接翻开');
          this.draw();
        }
      }
    }else{
      if(this.selected){
        const moves=this.getLegalMoves(this.selected.row,this.selected.col);
        if(moves.some(m=>m.row===row&&m.col===col)){
          this.commitMove(this.selected.row,this.selected.col,row,col,null);
          this.selected=null;this.draw();this.afterAction();return;
        }
        if(piece&&piece.side===side){this.selected={row,col};this.draw();return;}
        this.selected=null;this.draw();
      }else{
        if(piece&&piece.side===side){this.selected={row,col};this.draw();}
      }
    }
  }
  // 类型选择后移动（由 type-btn 点击触发，在 GameLauncher 中绑定）
  selectBlindType(type){
    if(!this.selected) return;
    const pos=this.selected;
    const piece=this.board[pos.row][pos.col];
    if(!piece || piece.revealed) return;
    // 暂存假设类型
    this.assumedType=type;
    $('typeSelector').classList.remove('show');
    // 计算该假设类型下的合法移动
    const moves=this.getBlindMoves(pos.row,pos.col,type);
    this.legalMovesForSelected=moves;
    this.status(`已选择「${type}」，点击目标位置移动`);
    this.draw();
  }
  cancelBlindType(){
    this.assumedType=null;
    this.selected=null;
    $('typeSelector').classList.remove('show');
    this.status('已取消');
    this.draw();
  }
  // 翻开当前选中的暗棋（由 typeSelector 的「翻开」按钮触发）
  flipSelectedBlind(){
    const pos=this.selected;
    if(!pos) return;
    const piece=this.board[pos.row][pos.col];
    if(!piece || piece.revealed || piece.side!==this.currentTurn) return;
    this.assumedType=null;
    this.selected=null;
    $('typeSelector').classList.remove('show');
    this.commitReveal(pos.row,pos.col);
    this.draw();
    this.afterAction();
  }
  // ===== 盲棋规则 =====
  getBlindMoves(row,col,assumedType){
    const piece=this.board[row][col];if(!piece)return[];
    // 未翻开的棋子只有在提供了假设类型时才能移动
    if(!piece.revealed&&!assumedType)return[];
    const type=assumedType||piece.type;
    const moves=[];const side=piece.side;
    [[0,1],[0,-1],[1,0],[-1,0]].forEach(([dr,dc])=>{
      const r=row+dr,c=col+dc;
      if(!this.isInBoard(r,c))return;
      const target=this.board[r][c];
      if(!target){moves.push({row:r,col:c});return;}
      if(!target.revealed)return;
      if(target.side===side)return;
      if(type==='炮')return;
      if(this.canBlindCapture(type,target.type))moves.push({row:r,col:c});
    });
    if(type==='炮'){
      [[0,1],[0,-1],[1,0],[-1,0]].forEach(([dr,dc])=>{
        let r=row+dr,c=col+dc,jumped=false;
        while(this.isInBoard(r,c)){
          if(this.board[r][c]){
            if(!jumped){jumped=true;}
            else{
              if(this.board[r][c].revealed&&this.board[r][c].side!==side)moves.push({row:r,col:c});
              break;
            }
          }
          r+=dr;c+=dc;
        }
      });
    }
    return moves;
  }
  canBlindCapture(attacker,defender){
    if((attacker==='兵'||attacker==='卒')&&(defender==='将'||defender==='帅'))return true;
    if((attacker==='将'||attacker==='帅')&&(defender==='兵'||defender==='卒'))return false;
    return BLIND_RANK[attacker]>=BLIND_RANK[defender];
  }
  // ===== 正常对战规则 =====
  getLegalMovesForPiece(row,col,piece,tempType){
    if(!piece)return[];
    const type=tempType||piece.type;
    if(!type)return[];
    const side=piece.side;
    const moves=[];
    const canMoveTo=(r,c)=>{
      if(!this.isInBoard(r,c))return false;
      const t=this.board[r][c];
      if(t){if(t.revealed&&t.side===side)return false;return true;}
      return true;
    };
    const addMove=(r,c)=>{if(canMoveTo(r,c))moves.push({row:r,col:c});};
    switch(type){
      case '帅':case '将':{
        if(!this.isInPalace(row,col,side))return[];
        for(const [dr,dc] of [[1,0],[-1,0],[0,1],[0,-1]]){
          const nr=row+dr,nc=col+dc;
          if(this.isInBoard(nr,nc)&&this.isInPalace(nr,nc,side))addMove(nr,nc);
        }
        for(let r=row+(side==='red'?-1:1);this.isInBoard(r,col);r+=(side==='red'?-1:1)){
          const t=this.board[r][col];
          if(t){
            if(t.revealed&&((t.type==='帅'&&t.side!==side)||(t.type==='将'&&t.side!==side)))moves.push({row:r,col:col});
            break;
          }
        }
        break;
      }
      case '士':
        if(!this.isInPalace(row,col,side))return[];
        for(const [dr,dc] of [[1,1],[1,-1],[-1,1],[-1,-1]]){
          const nr=row+dr,nc=col+dc;
          if(this.isInBoard(nr,nc)&&this.isInPalace(nr,nc,side))addMove(nr,nc);
        }
        break;
      case '相':case '象':
        for(const [dr,dc] of [[2,2],[2,-2],[-2,2],[-2,-2]]){
          const nr=row+dr,nc=col+dc;
          if(!this.isInBoard(nr,nc))continue;
          if(this.board[row+dr/2]&&this.board[row+dr/2][col+dc/2])continue;
          if(side==='red'&&nr<5)continue;
          if(side==='black'&&nr>4)continue;
          addMove(nr,nc);
        }
        break;
      case '马':
        for(const [dr,dc] of [[2,1],[2,-1],[-2,1],[-2,-1],[1,2],[1,-2],[-1,2],[-1,-2]]){
          const nr=row+dr,nc=col+dc;
          if(!this.isInBoard(nr,nc))continue;
          const br=row+(Math.abs(dr)===2?dr/2:0),bc=col+(Math.abs(dc)===2?dc/2:0);
          if(this.board[br]&&this.board[br][bc])continue;
          addMove(nr,nc);
        }
        break;
      case '车':
        for(const [dr,dc] of [[1,0],[-1,0],[0,1],[0,-1]]){
          let nr=row+dr,nc=col+dc;
          while(this.isInBoard(nr,nc)){
            if(this.board[nr][nc]){addMove(nr,nc);break;}
            addMove(nr,nc);
            nr+=dr;nc+=dc;
          }
        }
        break;
      case '炮':
        for(const [dr,dc] of [[1,0],[-1,0],[0,1],[0,-1]]){
          let nr=row+dr,nc=col+dc,jumped=false;
          while(this.isInBoard(nr,nc)){
            const t=this.board[nr][nc];
            if(!jumped){
              if(!t)addMove(nr,nc);
              else jumped=true;
            }else{
              if(t){addMove(nr,nc);break;}
            }
            nr+=dr;nc+=dc;
          }
        }
        break;
      case '兵':case '卒':
        if(side==='red'){
          if(row>5)addMove(row-1,col);
          else{addMove(row-1,col);addMove(row,col-1);addMove(row,col+1);}
        }else{
          if(row<4)addMove(row+1,col);
          else{addMove(row+1,col);addMove(row,col-1);addMove(row,col+1);}
        }
        break;
    }
    return moves;
  }
  getLegalMoves(row,col){
    const piece=this.board[row][col];
    if(!piece)return[];
    const side=piece.side;
    return this.getLegalMovesForPiece(row,col,piece,null).filter(m=>{
      const snap=this.snapshotBoard();
      this.applyMove(row,col,m.row,m.col,null);
      const ic=this.isInCheck(side,this.board);
      this.restoreBoard(snap);
      return !ic;
    });
  }
  // ===== 将军检测 =====
  findKing(side,brd){
    const b=brd||this.board;
    const kingType=side==='red'?'帅':'将';
    for(let r=0;r<this.ROWS;r++)for(let c=0;c<this.COLS;c++){
      const p=b[r][c];
      if(p&&p.revealed&&p.side===side&&p.type===kingType)return{r,c};
    }
    return null;
  }
  isSquareAttacked(row,col,attackerSide,brd){
    const b=brd||this.board;
    for(const [dr,dc] of [[1,0],[-1,0],[0,1],[0,-1]]){
      let r=row+dr,c=col+dc;
      while(this.isInBoard(r,c)){
        const p=b[r][c];
        if(p){
          if(p.revealed&&p.side===attackerSide){
            if(p.type==='车')return true;
            if(p.type==='帅'||p.type==='将')return true;
          }
          break;
        }
        r+=dr;c+=dc;
      }
    }
    for(const [dr,dc] of [[2,1],[2,-1],[-2,1],[-2,-1],[1,2],[1,-2],[-1,2],[-1,-2]]){
      const nr=row+dr,nc=col+dc;
      if(!this.isInBoard(nr,nc))continue;
      const p=b[nr][nc];
      if(p&&p.revealed&&p.side===attackerSide&&p.type==='马'){
        const br=row+(Math.abs(dr)===2?dr/2:0),bc=col+(Math.abs(dc)===2?dc/2:0);
        if(!(b[br]&&b[br][bc]))return true;
      }
    }
    for(const [dr,dc] of [[1,0],[-1,0],[0,1],[0,-1]]){
      let r=row+dr,c=col+dc,jumped=false;
      while(this.isInBoard(r,c)){
        const p=b[r][c];
        if(p){
          if(!jumped)jumped=true;
          else{if(p.revealed&&p.side===attackerSide&&p.type==='炮')return true;break;}
        }
        r+=dr;c+=dc;
      }
    }
    for(const [dr,dc] of [[1,0],[-1,0],[0,1],[0,-1]]){
      const nr=row+dr,nc=col+dc;
      if(!this.isInBoard(nr,nc))continue;
      const p=b[nr][nc];
      if(p&&p.revealed&&p.side===attackerSide&&(p.type==='兵'||p.type==='卒')){
        if(attackerSide==='red'&&dr===-1)return true;
        if(attackerSide==='black'&&dr===1)return true;
        const crossedRed=row<5,crossedBlack=row>4;
        if((attackerSide==='red'&&crossedRed)||(attackerSide==='black'&&crossedBlack)){
          if(dc!==0)return true;
        }
      }
    }
    return false;
  }
  isInCheck(side,brd){
    const king=this.findKing(side,brd);
    if(!king)return true;
    return this.isSquareAttacked(king.r,king.c,side==='red'?'black':'red',brd);
  }
  // ===== 棋盘快照与恢复 =====
  snapshotBoard(){
    return{
      board:this.board.map(r=>r.map(p=>p?{side:p.side,type:p.type,revealed:p.revealed}:null)),
      gameOver:this.gameOver,winner:this.winner,
      lastMove:this.lastMove?{...this.lastMove}:null,
      capturedRed:[...this.capturedRed],capturedBlack:[...this.capturedBlack]
    };
  }
  restoreBoard(s){
    this.board=s.board;this.gameOver=s.gameOver;this.winner=s.winner;
    this.lastMove=s.lastMove;this.capturedRed=s.capturedRed;this.capturedBlack=s.capturedBlack;
  }
  boardToKey(brd,side){
    let k='';
    for(let r=0;r<this.ROWS;r++)for(let c=0;c<this.COLS;c++){
      const p=brd[r][c];
      k+=p?(p.side[0]+p.type+(p.revealed?'1':'0')):'..';
    }
    return k+(side||this.currentTurn);
  }
  // ===== 走法执行 =====
  applyMove(fr,fc,tr,tc,assumedType){
    const moving=this.board[fr][fc];
    // 防御性检查：源位置无棋子则直接返回，避免空指针错误
    if(!moving){
      console.warn('applyMove: 源位置无棋子', fr, fc);
      return {captured:null,moverRevealed:null};
    }
    const target=this.board[tr][tc];
    let captured=null;
    if(target){
      target.revealed=true;
      captured=target;
      if(target.side==='red')this.capturedRed.push(target.type);
      else this.capturedBlack.push(target.type);
      if(target.type==='帅'||target.type==='将'){
        this.gameOver=true;
        this.winner=target.side==='red'?'black':'red';
      }
    }
    moving.revealed=true;
    this.board[tr][tc]=moving;
    this.board[fr][fc]=null;
    this.lastMove={fromRow:fr,fromCol:fc,toRow:tr,toCol:tc};
    return {captured,moverRevealed:moving};
  }
  applyReveal(row,col){const p=this.board[row][col];if(p)p.revealed=true;this.lastMove=null;}
  applyAction(action){
    if(action.isReveal)this.applyReveal(action.fromRow,action.fromCol);
    else this.applyMove(action.fromRow,action.fromCol,action.toRow,action.toCol,action.assumedType);
  }
  // ===== 真实走棋 =====
  commitMove(fr,fc,tr,tc,assumedType){
    const piece=this.board[fr][fc];
    // 防御性检查：源位置无棋子则直接返回
    if(!piece){
      console.warn('commitMove: 源位置无棋子', fr, fc);
      return {captured:null,moverRevealed:null};
    }
    const captured=this.board[tr][tc]?{side:this.board[tr][tc].side,type:this.board[tr][tc].type,revealed:true}:null;
    const side=this.currentTurn;
    const beforeWin=this.mode==='battle'?this.winrateFor(side):0.5;
    const result=this.applyMove(fr,fc,tr,tc,assumedType);
    const afterWin=this.mode==='battle'?this.winrateFor(side):0.5;
    this.moveHistory.push({fr,fc,tr,tc,piece:{...piece},captured,side});
    this.currentTurn=this.currentTurn==='red'?'black':'red';
    // 添加历史记录文本
    let text = `${side==='red'?'红':'黑'} ${piece.type||'?'} (${fr},${fc})→(${tr},${tc})`;
    if(captured) text += ` 吃${captured.type}`;
    this.addHistory(side, text);
    // 更新被吃子显示
    this.updateCapturedDisplay();
    SoundFX.play('piece');
    if(this.mode==='battle')this.detectDivineXiangqi(side,tr,tc,captured,beforeWin,afterWin);
    return result;
  }
  commitReveal(row,col){
    const piece=this.board[row][col];
    const side=this.currentTurn;
    this.applyReveal(row,col);
    this.moveHistory.push({reveal:true,row,col,piece:{...piece},side});
    this.currentTurn=this.currentTurn==='red'?'black':'red';
    this.addHistory(side, `${side==='red'?'红':'黑'} 翻开 (${row},${col}) 是${piece.type}`);
    if(this.mode==='blind'){
      this.updateCapturedDisplay();
    }
  }
  undoMove(){
    const last=this.moveHistory.pop();
    if(!last)return false;
    if(last.reveal){
      const p=this.board[last.row][last.col];
      if(p)p.revealed=false;
    }else{
      this.board[last.fr][last.fc]=last.piece;
      this.board[last.tr][last.tc]=last.captured;
      if(last.captured){
        const arr=last.captured.side==='red'?this.capturedRed:this.capturedBlack;
        const idx=arr.lastIndexOf(last.captured.type);
        if(idx>=0)arr.splice(idx,1);
      }
    }
    this.currentTurn=last.side;
    this.updateCapturedDisplay();
    // 移除最后一条历史
    if(this.historyListEl.lastChild) this.historyListEl.removeChild(this.historyListEl.lastChild);
    return true;
  }
  undo(){
    if(this.aiThinking||CONFIG.opponentType==='aivai'||this.gameOver)return;
    if(this.moveHistory.length===0)return;
    const n=CONFIG.opponentType==='human'?1:2;
    for(let i=0;i<n&&this.moveHistory.length>0;i++)this.undoMove();
    this.clearTimers();this.aiThinking=false;this.gameOver=false;this.winner=null;this.selected=null;this.endMsg=null;
    $('typeSelector').classList.remove('show');
    this.draw();
    const ctrl=this.controllerFor(this.currentTurn);
    if(ctrl==='human'){this.setTurnUI(this.currentTurn);}
    else{this.aiThinking=true;this.setTurnUI(this.currentTurn);this.schedule(()=>this.triggerAI(this.currentTurn,ctrl),CONFIG.aiDelay);}
  }
  restart(){
    this.clearTimers();
    this.divineCount=0;this._divineLastPly=null;  // 重置「神之一手」计数，新一局重新累积高光
    this.board=this.mode==='blind'?this.createBlindBoard():this.createInitialBoard();
    this.currentTurn='red';this.selected=null;this.moveHistory=[];
    this.capturedRed=[];this.capturedBlack=[];this.lastMove=null;
    this.gameOver=false;this.winner=null;this.aiThinking=false;this.endMsg=null;
    this.gameId='xiangqi_'+Date.now()+'_'+Math.floor(Math.random()*9999);
    aivaiRunning=false;aivaiPaused=false;
    GameLauncher.updateAivaiControls();
    GameLauncher.hideWin();
    this.historyListEl.innerHTML='';
    this.updateCapturedDisplay();
    if(this.mode==='blind'){
      $('capturedBar').classList.add('show');
      $('typeSelector').classList.remove('show');
    } else {
      $('capturedBar').classList.remove('show');
    }
    this.updateAiStatus();
    this.draw();
    const ctrl=this.controllerFor('red');
    this.setTurnUI('red');
    this.status(ctrl==='human'?'':'');
  }
  pass(){}
  // 更新被吃子显示
  updateCapturedDisplay(){
    const render=(container,list,label)=>{
      container.innerHTML='<span class="cs-label">'+label+'</span>';
      list.forEach(type=>{
        const span=document.createElement('span');
        span.className='cs-piece';
        span.textContent=type;
        container.appendChild(span);
      });
    };
    render(this.capturedRedEl,this.capturedRed,'红方损失');
    render(this.capturedBlackEl,this.capturedBlack,'黑方损失');
  }
  // ===== 全部合法走法 =====
  getAllLegalMoves(side){
    const moves=[];
    for(let r=0;r<this.ROWS;r++)for(let c=0;c<this.COLS;c++){
      const p=this.board[r][c];
      if(!p)continue;
      if(this.mode==='battle'){
        if(p.revealed&&p.side===side){
          const legal=this.getLegalMovesForPiece(r,c,p,null);
          for(const m of legal){
            const hasTarget=this.board[m.row][m.col]&&this.board[m.row][m.col].side!==side;
            if(!this.moveLeavesInCheck(r,c,m.row,m.col,side))continue;
            moves.push({fromRow:r,fromCol:c,toRow:m.row,toCol:m.col,pieceType:p.type,captured:hasTarget});
          }
        }
      }else{
        if(!p.revealed){
          // 翻开（任何未翻开的棋子都可以翻开）
          moves.push({fromRow:r,fromCol:c,toRow:r,toCol:c,pieceType:'reveal',isReveal:true});
          // 假设类型移动 - 只有己方未翻开的棋子才能以假设类型移动
          if(p.side===side){
            for(const t of ['车','马','炮','相','士','帅','兵']){
              const legal=this.getBlindMoves(r,c,t);
              for(const m of legal){
                moves.push({fromRow:r,fromCol:c,toRow:m.row,toCol:m.col,pieceType:t,assumedType:t,isReveal:false});
              }
            }
          }
        }else if(p.side===side){
          const legal=this.getBlindMoves(r,c);
          for(const m of legal){
            const hasTarget=this.board[m.row][m.col]&&this.board[m.row][m.col].side!==side;
            moves.push({fromRow:r,fromCol:c,toRow:m.row,toCol:m.col,pieceType:p.type,captured:hasTarget,capturedValue:hasTarget?(TYPE_VALUES[this.board[m.row][m.col].type]||0):0});
          }
        }
      }
    }
    return moves;
  }
  moveLeavesInCheck(fr,fc,tr,tc,side){
    const snap=this.snapshotBoard();
    this.applyMove(fr,fc,tr,tc,null);
    const ic=this.isInCheck(side,this.board);
    this.restoreBoard(snap);
    return !ic;
  }
  // ===== 回合流转 =====
  afterAction(){
    if(this.gameOver){this.finishWin();return;}
    if(this.mode==='battle'){
      const opp=this.currentTurn;
      const legal=this.getAllLegalMoves(opp);
      if(legal.length===0){
        this.gameOver=true;this.winner=opp==='red'?'black':'red';
        this.endMsg=(this.isInCheck(opp,this.board)?'将死！':'困毙！')+this.sideLabel(this.winner)+'获胜';
        this.finishWin();return;
      }
    }else{
      const side=this.currentTurn;
      if(this.getAllLegalMoves(side).length===0){
        this.gameOver=true;this.winner=side==='red'?'black':'red';
        this.endMsg=this.sideLabel(this.winner)+'获胜！对方无棋可走';
        this.finishWin();return;
      }
    }
    GameBase.prototype.afterAction.call(this);
  }
  finishWin(){
    this.aiThinking=false;this.clearTimers();
    if(!this.winner){this.setTurnUI(this.currentTurn);this.draw();return;}
    this.updateAdaptiveDifficulty();
    let msg=this.endMsg||(this.sideLabel(this.winner)+'获胜！');
    if(CONFIG.opponentType==='human')msg='双人对战结束 · '+this.sideLabel(this.winner)+'胜';
    else if(CONFIG.opponentType==='aivai')msg='AI对战结束 · '+this.sideLabel(this.winner)+'AI胜';
    GameLauncher.showWin(this.winner,msg);
    this.setTurnUI(this.currentTurn);
    this.draw();
  }
  updateAdaptiveDifficulty(){
    if(CONFIG.opponentType!=='builtin'&&CONFIG.opponentType!=='external')return;
    if(!this.winner)return;
    const playerWin=this.winner===this.humanSide();
    this.playerSkillTracker.gamesPlayed++;
    if(playerWin){
      this.playerSkillTracker.gamesWon++;
      this.playerSkillTracker.currentStreak++;
      this.playerSkillTracker.effectiveDifficulty=Math.min(1.0,this.playerSkillTracker.effectiveDifficulty+0.08);
    }else{
      this.playerSkillTracker.currentStreak=0;
      this.playerSkillTracker.effectiveDifficulty=Math.max(0.2,this.playerSkillTracker.effectiveDifficulty-0.06);
    }
    if(this.playerSkillTracker.currentStreak>=3)
      this.playerSkillTracker.effectiveDifficulty=Math.min(1.0,this.playerSkillTracker.effectiveDifficulty+0.05);
  }
  // ===== 外部AI协议 =====
  buildExternalPayload(side){
    return{
      gameId:this.gameId,
      gameType:'xiangqi',
      mode:this.mode,
      currentTurn:side,
      board:this.board.map(row=>row.map(p=>p?{side:p.side,type:p.type,revealed:p.revealed}:null)),
      legalMoves:this.getAllLegalMoves(side).map(m=>({...m})),
      moveHistory:this.moveHistory
    };
  }
  parseExternalMove(data){
    if(!data)return null;
    const toNum=(v)=>typeof v==='number'?v:parseInt(v,10);
    if(data.isReveal||data.pieceType==='reveal'){
      return{fromRow:toNum(data.fromRow),fromCol:toNum(data.fromCol),toRow:toNum(data.fromRow),toCol:toNum(data.fromCol),isReveal:true};
    }
    return{fromRow:toNum(data.fromRow),fromCol:toNum(data.fromCol),toRow:toNum(data.toRow),toCol:toNum(data.toCol),assumedType:data.assumedType||null};
  }
  validateExternalMove(move,side){
    if(!move)return false;
    const legal=this.getAllLegalMoves(side);
    if(move.isReveal){
      return legal.some(m=>m.isReveal&&m.fromRow===move.fromRow&&m.fromCol===move.fromCol);
    }
    return legal.some(m=>!m.isReveal&&m.fromRow===move.fromRow&&m.fromCol===move.fromCol&&m.toRow===move.toRow&&m.toCol===move.toCol);
  }
  applyAIMove(side,move){
    // 验证AI走法是否合法，防止非法走法导致错误
    if(!move||!this.validateAIMove(move,side)){
      console.warn('AI生成了非法走法，已跳过:', move);
      // 重新获取合法走法并选择第一个
      const legal=this.getAllLegalMoves(side);
      if(legal.length>0){
        move=legal[0];
      }else{
        // 无合法走法，判负
        this.gameOver=true;this.winner=side==='red'?'black':'red';
        this.endMsg=this.sideLabel(this.winner)+'获胜';
        this.finishWin();
        return;
      }
    }
    if(this.mode==='blind'&&move.isReveal){
      this.commitReveal(move.fromRow,move.fromCol);
      this.draw();this.afterAction();return;
    }
    this.commitMove(move.fromRow,move.fromCol,move.toRow,move.toCol,move.assumedType||null);
    this.draw();this.afterAction();
  }
  validateAIMove(move,side){
    if(!move)return false;
    const legal=this.getAllLegalMoves(side);
    if(move.isReveal){
      return legal.some(m=>m.isReveal&&m.fromRow===move.fromRow&&m.fromCol===move.fromCol);
    }
    return legal.some(m=>!m.isReveal&&m.fromRow===move.fromRow&&m.fromCol===move.fromCol&&m.toRow===move.toRow&&m.toCol===move.toCol);
  }
  // ---- WASM 引擎（UCCI 协议）相关 ----
  pieceFenChar(side,type){
    const map={'帅':'K','士':'A','相':'B','象':'B','马':'N','车':'R','炮':'C','兵':'P','卒':'P'};
    const ch=map[type]||'';
    return side==='red'?ch:ch.toLowerCase();
  }
  boardToFen(){
    const rows=[];
    for(let r=0;r<10;r++){
      let rowStr='',empty=0;
      for(let c=0;c<9;c++){
        const p=this.board[r][c];
        if(!p||!p.revealed){empty++;continue;}
        if(empty){rowStr+=empty;empty=0;}
        rowStr+=this.pieceFenChar(p.side,p.type);
      }
      if(empty)rowStr+=empty;
      rows.push(rowStr);
    }
    return rows.join('/')+' '+(this.currentTurn==='red'?'w':'b')+' - - 0 1';
  }
  ucciToMove(mv){
    const fc=mv.charCodeAt(0)-97, fr=9-(mv.charCodeAt(1)-48);
    const tc=mv.charCodeAt(2)-97, tr=9-(mv.charCodeAt(3)-48);
    return {fromRow:fr,fromCol:fc,toRow:tr,toCol:tc};
  }
  wasmTimeLimit(){
    return {easy:300,medium:700,hard:1200,master:2500}[CONFIG.difficulty]||700;
  }
  async runWasmAI(side){
    const start=performance.now();
    let move=null, err=null;
    try{
      const fen=this.boardToFen();
      await UcciEngine.init();
      await UcciEngine.send('position fen '+fen);
      const out=await UcciEngine.send('go movetime '+this.wasmTimeLimit());
      const mv=UcciEngine.parseBestMove(out);
      if(mv)move=this.ucciToMove(mv);
    }catch(e){
      err=e;
      console.error('WASM引擎出错，回退内置JS:',e);
    }
    const wait=Math.max(0,CONFIG.aiDelay-(performance.now()-start));
    this.schedule(()=>{
      if(this.gameOver){this.aiThinking=false;return;}
      if(!move){
        this.aiThinking=false;
        if(this.hasAnyLegalMove(side)){
          if(err)this.status('WASM引擎不可用，改用内置JS');
          else this.status('WASM引擎异常，改用内置JS');
          this.runBuiltinJSAI(side);
        }else{
          // 将死或困毙，判对方胜
          this.gameOver=true;this.winner=side==='red'?'black':'red';
          this.endMsg=this.sideLabel(this.winner)+'获胜';
          this.finishWin();
        }
        return;
      }
      this.aiThinking=false;
      this.applyAIMove(side,move);
    },wait);
  }
  hasAnyLegalMove(side){
    for(let r=0;r<this.ROWS;r++)for(let c=0;c<this.COLS;c++){
      const p=this.board[r][c];
      if(!p||p.side!==side)continue;
      if(this.mode==='blind'&&!p.revealed)continue;
      if(this.getLegalMoves(r,c).length>0)return true;
    }
    return false;
  }
  runBuiltinAI(side){
    if(CONFIG.engine==='wasm'&&this.mode==='battle'){this.runWasmAI(side);return;}
    this.runBuiltinJSAI(side);
  }
  runBuiltinJSAI(side){
    const start=performance.now();
    let move;
    if(this.mode==='blind')move=this.blindBestAction(side);
    else move=this.getBestAIAction(side);
    const wait=Math.max(0,CONFIG.aiDelay-(performance.now()-start));
    this.schedule(()=>{
      if(this.gameOver){this.aiThinking=false;return;}
      if(!move){
        this.gameOver=true;this.winner=side==='red'?'black':'red';
        this.endMsg=this.sideLabel(this.winner)+'获胜';
        this.finishWin();return;
      }
      this.aiThinking=false;
      this.applyAIMove(side,move);
    },wait);
  }
  // ============================================================
  // 强化AI引擎
  // ============================================================
  isSameMove(m1,m2){return !!(m1&&m2&&m1.fromRow===m2.fromRow&&m1.fromCol===m2.fromCol&&m1.toRow===m2.toRow&&m1.toCol===m2.toCol);}
  evaluateMaterialDifference(side){
    let my=0,opp=0;
    for(let r=0;r<this.ROWS;r++)for(let c=0;c<this.COLS;c++){
      const p=this.board[r][c];
      if(!p||!p.revealed)continue;
      const val=TYPE_VALUES[p.type]||0;
      if(p.side===side)my+=val;else opp+=val;
    }
    return my-opp;
  }
  getBestAIAction(side){
    this.transpositionTable=new Map();
    this.historyTable=new Map();
    this.killerMoves=Array(this.maxSearchDepth+2).fill().map(()=>[null,null]);
    this.searchStartTime=performance.now();
    this.searchInterrupted=false;
    this.nodesSearched=0;
    const totalMoves=this.moveHistory.length;
    if(totalMoves<=1){
      this.aiPersonality=AI_PERSONALITIES[Math.floor(Math.random()*AI_PERSONALITIES.length)];
      this.aiMood='normal';
      this.opponentStyle=null;
      this.styleConfidence=0;
    }
    // 识别对手风格（走满10步后开始分析）
    if(totalMoves>=10&&totalMoves%4===0){
      this.analyzeOpponentStyle(side==='red'?'black':'red');
    }
    const baseDifficulty=CONFIG.difficulty;
    let difficultyMultiplier=1.0;
    switch(baseDifficulty){
      case 'easy':difficultyMultiplier=0.5;break;
      case 'medium':difficultyMultiplier=0.8;break;
      case 'hard':difficultyMultiplier=1.0;break;
      case 'master':difficultyMultiplier=1.3;break;
    }
    difficultyMultiplier*=(0.7+this.playerSkillTracker.effectiveDifficulty*0.6);
    switch(baseDifficulty){
      case 'easy':this.searchTimeLimit=Math.floor(400*difficultyMultiplier);this.maxSearchDepth=2+Math.floor(difficultyMultiplier);this.aiMistakeChance=0.18;break;
      case 'medium':this.searchTimeLimit=Math.floor(1500*difficultyMultiplier);this.maxSearchDepth=4+Math.floor(difficultyMultiplier*2);this.aiMistakeChance=0.10;break;
      case 'hard':this.searchTimeLimit=Math.floor(3500*difficultyMultiplier);this.maxSearchDepth=6+Math.floor(difficultyMultiplier*2);this.aiMistakeChance=0.05;break;
      case 'master':this.searchTimeLimit=Math.floor(5500*difficultyMultiplier);this.maxSearchDepth=8+Math.floor(difficultyMultiplier*2);this.aiMistakeChance=0.03;break;
      default:this.searchTimeLimit=2000;this.maxSearchDepth=6;this.aiMistakeChance=0.08;
    }
    if(totalMoves<6)this.searchTimeLimit=Math.min(this.searchTimeLimit,2500);
    if(totalMoves>35)this.searchTimeLimit=Math.min(this.searchTimeLimit*1.4,8000);
    const materialDiff=this.evaluateMaterialDifference(side);
    if(materialDiff>300)this.aiMood='confident';
    else if(materialDiff<-400)this.aiMood='desperate';
    else if(materialDiff<-150)this.aiMood='pressured';
    else this.aiMood='normal';
    let bestMove=this.iterativeDeepeningSearch(side);
    if(bestMove&&Math.random()<this.aiMistakeChance&&this.aiMood!=='desperate'){
      const allMoves=this.getAllLegalMoves(side);
      if(allMoves.length>3){
        const scored=this.scoreAndSortActions(allMoves,side,true);
        const midRange=scored.slice(1,Math.max(2,Math.floor(scored.length*0.4)));
        if(midRange.length>0)bestMove=midRange[Math.floor(Math.random()*midRange.length)].action;
      }
    }
    if(bestMove&&this.aiMood==='desperate'&&Math.random()<this.aiInspirationChance){
      const extraDepth=Math.min(this.maxSearchDepth+2,10);
      const inspired=this.deepSearchForInspiration(side,extraDepth);
      if(inspired)bestMove=inspired;
    }
    this.lastBestMove=bestMove;
    return bestMove;
  }
  deepSearchForInspiration(side,depth){
    const actions=this.getAllLegalMoves(side);
    if(actions.length===0)return null;
    let bestMove=null,bestScore=-Infinity;
    const scored=this.scoreAndSortActions(actions,side,true);
    const candidates=scored.slice(0,Math.min(5,scored.length));
    for(const item of candidates){
      if(performance.now()-this.searchStartTime>this.searchTimeLimit*1.5)break;
      const snapshot=this.snapshotBoard();
      this.applyAction(item.action);
      let score;
      if(this.gameOver&&this.winner===side)score=1000000;
      else if(this.gameOver)score=-1000000;
      else score=this.alphaBetaSearch(depth-1,side==='red'?'black':'red',side,-Infinity,Infinity,false);
      this.restoreBoard(snapshot);
      if(score>bestScore){bestScore=score;bestMove=item.action;}
    }
    if(bestScore>200)return bestMove;
    return null;
  }
  iterativeDeepeningSearch(side){
    const actions=this.getAllLegalMoves(side);
    if(actions.length===0)return null;
    if(actions.length===1)return actions[0];
    let bestMove=actions[0],bestScore=-Infinity;
    this.lastBestMove=null;
    for(let depth=1;depth<=this.maxSearchDepth;depth++){
      if(performance.now()-this.searchStartTime>this.searchTimeLimit){this.searchInterrupted=true;break;}
      let currentBest=null;
      let alpha=-Infinity;
      const beta=Infinity;
      const scoredRoot=this.scoreAndSortActionsV2(actions,side,depth);
      for(const item of scoredRoot){
        if(performance.now()-this.searchStartTime>this.searchTimeLimit){this.searchInterrupted=true;break;}
        const snapshot=this.snapshotBoard();
        this.applyAction(item.action);
        let score;
        if(this.gameOver&&this.winner===side)score=1000000+depth;
        else if(this.gameOver)score=-1000000-depth;
        else score=this.alphaBetaSearch(depth-1,side==='red'?'black':'red',side,alpha,beta,false);
        this.restoreBoard(snapshot);
        if(score>alpha){alpha=score;currentBest=item.action;}
      }
      if(!this.searchInterrupted&&currentBest){bestMove=currentBest;bestScore=alpha;this.lastBestMove=currentBest;}
      if(bestScore>90000||bestScore<-90000)break;
      if(performance.now()-this.searchStartTime>this.searchTimeLimit)break;
    }
    return bestMove;
  }
  alphaBetaSearch(depth,currentSide,aiSide,alpha,beta,isQuiescence){
    this.nodesSearched++;
    if(performance.now()-this.searchStartTime>this.searchTimeLimit){this.searchInterrupted=true;return this.evaluateBoard(aiSide);}
    if(depth===0){if(isQuiescence)return this.evaluateBoard(aiSide);return this.quiescenceSearch(currentSide,aiSide,alpha,beta,3);}
    if(this.gameOver){return this.winner===aiSide?1000000+depth:-1000000-depth;}
    const key=this.boardToKey(this.board,currentSide);
    const ttEntry=this.transpositionTable.get(key);
    if(ttEntry&&ttEntry.depth>=depth){
      if(ttEntry.flag==='exact')return ttEntry.score;
      if(ttEntry.flag==='lower'&&ttEntry.score>alpha)alpha=ttEntry.score;
      if(ttEntry.flag==='upper'&&ttEntry.score<beta)beta=ttEntry.score;
      if(alpha>=beta)return ttEntry.score;
    }
    const moves=this.getAllLegalMoves(currentSide);
    if(moves.length===0){return currentSide===aiSide?-1000000-depth:1000000+depth;}
    const scoredMoves=this.scoreAndSortActionsV2(moves,currentSide,depth);
    let bestVal=(currentSide===aiSide)?-Infinity:Infinity;
    const originalAlpha=alpha;
    let flag='upper';
    let bestMoveThisNode=null;
    for(const item of scoredMoves){
      if(performance.now()-this.searchStartTime>this.searchTimeLimit){this.searchInterrupted=true;break;}
      const snapshot=this.snapshotBoard();
      this.applyAction(item.action);
      let score;
      if(this.gameOver&&this.winner===currentSide)score=1000000+depth;
      else if(this.gameOver)score=-1000000-depth;
      else score=this.alphaBetaSearch(depth-1,currentSide==='red'?'black':'red',aiSide,alpha,beta,false);
      this.restoreBoard(snapshot);
      if(currentSide===aiSide){
        if(score>bestVal){bestVal=score;flag='lower';bestMoveThisNode=item.action;}
        if(score>alpha)alpha=score;
      }else{
        if(score<bestVal){bestVal=score;flag='upper';bestMoveThisNode=item.action;}
        if(score<beta)beta=score;
      }
      if(beta<=alpha){
        if(!item.action.isReveal){
          const moveKey=item.action.fromRow+','+item.action.fromCol+'-'+item.action.toRow+','+item.action.toCol;
          const histScore=this.historyTable.get(moveKey)||0;
          this.historyTable.set(moveKey,histScore+depth*depth);
          const target=this.board[item.action.toRow][item.action.toCol];
          if(!target&&this.killerMoves[depth]){
            if(!this.killerMoves[depth][0]||!this.isSameMove(this.killerMoves[depth][0],item.action)){
              this.killerMoves[depth][1]=this.killerMoves[depth][0];
              this.killerMoves[depth][0]=item.action;
            }
          }
        }
        break;
      }
    }
    if(!this.searchInterrupted){
      this.transpositionTable.set(key,{score:bestVal,depth,flag:bestVal<=originalAlpha?'upper':(bestVal>=beta?'lower':'exact'),bestMove:bestMoveThisNode});
    }
    return bestVal;
  }
  quiescenceSearch(currentSide,aiSide,alpha,beta,maxDepth){
    const standPat=this.evaluateBoard(aiSide);
    if(maxDepth===0)return standPat;
    if(currentSide===aiSide){
      if(standPat>=beta)return standPat;
      if(standPat>alpha)alpha=standPat;
    }else{
      if(standPat<=alpha)return standPat;
      if(standPat<beta)beta=standPat;
    }
    const moves=this.getAllLegalMoves(currentSide);
    const captureMoves=moves.filter(m=>{
      const target=this.board[m.toRow][m.toCol];
      return target&&!m.isReveal;
    });
    const sortedCaptures=this.scoreAndSortActions(captureMoves,currentSide,false);
    let bestVal=standPat;
    for(const item of sortedCaptures){
      if(performance.now()-this.searchStartTime>this.searchTimeLimit){this.searchInterrupted=true;break;}
      const snapshot=this.snapshotBoard();
      this.applyAction(item.action);
      let score;
      if(this.gameOver&&this.winner===currentSide)score=1000000;
      else if(this.gameOver)score=-1000000;
      else score=this.quiescenceSearch(currentSide==='red'?'black':'red',aiSide,alpha,beta,maxDepth-1);
      this.restoreBoard(snapshot);
      if(currentSide===aiSide){
        if(score>bestVal)bestVal=score;
        if(score>alpha)alpha=score;
      }else{
        if(score<bestVal)bestVal=score;
        if(score<beta)beta=score;
      }
      if(beta<=alpha)break;
    }
    return bestVal;
  }
  scoreAndSortActionsV2(actions,side,depth){
    const scored=actions.map(a=>{
      let score=0;
      const target=this.board[a.toRow][a.toCol];
      const mover=this.board[a.fromRow][a.fromCol];
      if(a.isReveal){score+=30;}
      else if(target){
        if(target.revealed&&target.side!==side){
          score+=(TYPE_VALUES[target.type]||100)*10+500;
          if(target.type==='帅'||target.type==='将')score+=10000;
          if(a.pieceType&&TYPE_VALUES[a.pieceType]){
            score+=(TYPE_VALUES[target.type]||100)-TYPE_VALUES[a.pieceType];
          }
        }else if(!target.revealed){score+=80;}
      }
      if(!a.isReveal){
        const snapshot=this.snapshotBoard();
        this.applyAction(a);
        if(!this.gameOver&&this.isInCheck(side==='red'?'black':'red'))score+=300;
        this.restoreBoard(snapshot);
      }
      if(this.aiPersonality==='aggressive'){
        if(target&&target.revealed&&target.side!==side)score+=150;
        const advance=side==='red'?(a.fromRow-a.toRow):(a.toRow-a.fromRow);
        if(advance>0)score+=advance*8;
        if(a.toRow<5&&side==='red')score+=30;
        if(a.toRow>4&&side==='black')score+=30;
      }else if(this.aiPersonality==='solid'){
        if(target&&target.revealed&&target.side!==side)score-=50;
        const retreat=side==='red'?(a.toRow-a.fromRow):(a.fromRow-a.toRow);
        if(retreat>0)score+=retreat*5;
        if(mover&&(mover.type==='士'||mover.type==='相'||mover.type==='象'))score+=40;
      }
      if(this.aiMood==='desperate'){
        if(target&&target.revealed&&target.side!==side)score+=200;
        score+=Math.random()*100;
      }else if(this.aiMood==='confident'){score-=Math.random()*30;}
      if(mover&&mover.revealed&&(mover.type==='兵'||mover.type==='卒')){
        const progress=side==='red'?(9-a.toRow):a.toRow;
        score+=progress*4;
      }
      if(mover&&mover.revealed&&mover.type==='车'){
        let openLine=true;
        for(let r=0;r<this.ROWS;r++){
          if(r!==a.toRow&&this.board[r][a.toCol]){openLine=false;break;}
        }
        if(openLine)score+=25;
      }
      if(this.killerMoves[depth]){
        if(this.isSameMove(this.killerMoves[depth][0],a))score+=4000;
        else if(this.isSameMove(this.killerMoves[depth][1],a))score+=3000;
      }
      const moveKey=a.fromRow+','+a.fromCol+'-'+a.toRow+','+a.toCol;
      const histScore=this.historyTable.get(moveKey)||0;
      score+=Math.min(histScore,2000);
      if(this.lastBestMove&&this.isSameMove(this.lastBestMove,a))score+=5000;
      if(target&&target.side===side&&target.revealed)score-=500;
      score+=Math.random()*15;
      return{action:a,score};
    });
    scored.sort((a,b)=>b.score-a.score);
    return scored;
  }
  scoreAndSortActions(actions,side,isRoot){
    const scored=actions.map(a=>{
      let score=0;
      const target=this.board[a.toRow][a.toCol];
      if(a.isReveal){score+=40;}
      else if(target){
        if(target.revealed){
          if(target.side!==side){
            score+=TYPE_VALUES[target.type]*10+500;
            if(target.type==='帅'||target.type==='将')score+=10000;
            if(a.pieceType&&TYPE_VALUES[a.pieceType])score-=TYPE_VALUES[a.pieceType];
          }
        }else{score+=100;}
      }
      if(a.assumedType&&!a.isReveal)score+=TYPE_VALUES[a.assumedType]||0;
      const mover=this.board[a.fromRow][a.fromCol];
      if(mover&&mover.revealed&&(mover.type==='兵'||mover.type==='卒')){
        const progress=side==='red'?(9-a.toRow):a.toRow;
        score+=progress*3;
      }
      if(target&&target.side===side&&target.revealed)score-=500;
      score+=Math.random()*20;
      return{action:a,score};
    });
    scored.sort((a,b)=>b.score-a.score);
    return scored;
  }
  // ===== 对手风格识别 =====
  // ===== 中国象棋 · 四维度风格识别 =====
  analyzeOpponentStyle(oppSide){
    const history=this.moveHistory;
    if(history.length<5)return; // 5步后就开始分析
    const oppMoves=history.filter(m=>m.side===oppSide);
    if(oppMoves.length<3)return;
    
    // 初始化风格分析结果（如果不存在）
    if(!this.styleProfile)this.styleProfile={
      offenseDefense:null, // 攻防倾向
      tactic:null,         // 战术打法
      opening:null,        // 开局流派
      temperament:null,    // 棋手气质
      history:[]           // 历史风格记录
    };
    
    // ===== 维度1：攻防倾向 =====
    this.analyzeOffenseDefense(oppMoves,oppSide);
    
    // ===== 维度2：战术打法 =====
    if(oppMoves.length>=8)this.analyzeTacticStyle(oppMoves,oppSide);
    
    // ===== 维度3：开局流派（前8步判断） =====
    if(oppMoves.length<=12&&history.length<=20)this.analyzeOpeningStyle(oppMoves,oppSide);
    
    // ===== 维度4：棋手气质（综合判断） =====
    if(oppMoves.length>=10)this.analyzeTemperament(oppMoves,oppSide);
    
    // 记录历史风格，用于检测风格切换
    const currentSnapshot={
      step:history.length,
      od:this.styleProfile.offenseDefense,
      tactic:this.styleProfile.tactic
    };
    this.styleProfile.history.push(currentSnapshot);
    if(this.styleProfile.history.length>10)this.styleProfile.history.shift();
    
    // 检测风格切换
    this.detectStyleShift();
    
    // 综合主风格（用于评估函数）
    this.updatePrimaryStyle();
    
    // 保存到双方画像（用于AI vs AI风格面板）
    this.saveOpponentStyleProfile(oppSide);
  }
  analyzeOffenseDefense(moves,side){
    let agg=0,def=0,total=moves.length;
    for(const mv of moves){
      const advancing=(side==='red'&&mv.tr<mv.fr)||(side==='black'&&mv.tr>mv.fr);
      const captures=mv.captured!==null;
      const defensive=mv.piece.type==='士'||mv.piece.type==='相'||mv.piece.type==='象'||
        ((side==='red'&&mv.tr>mv.fr&&mv.piece.type!=='兵')||
         (side==='black'&&mv.tr<mv.fr&&mv.piece.type!=='卒'));
      if(advancing||captures)agg++;
      if(defensive)def++;
    }
    const aggRate=agg/total,defRate=def/total;
    let style,conf;
    if(aggRate>=0.65&&defRate<0.3){style='offense';conf=Math.min(0.9,aggRate*0.8+(1-defRate)*0.2);}
    else if(defRate>=0.6){style='defense';conf=Math.min(0.9,defRate);}
    else if(Math.abs(aggRate-defRate)<0.25){style='balanced';conf=0.6;}
    else{style='balanced';conf=0.4;}
    
    if(!this.styleProfile.offenseDefense||this.styleProfile.offenseDefense.style===style){
      this.styleProfile.offenseDefense={style,conf:Math.min(1,(this.styleProfile.offenseDefense?.conf||0)+0.1)};
    }else{
      const curConf=this.styleProfile.offenseDefense.conf-0.1;
      if(curConf<=0.3)this.styleProfile.offenseDefense={style,conf:0.4};
      else this.styleProfile.offenseDefense.conf=curConf;
    }
  }
  analyzeTacticStyle(moves,side){
    const recent=moves.slice(-10);
    let exchangeCount=0,attackCount=0,defenseCount=0,controlCount=0;
    let total=recent.length;
    
    for(const mv of recent){
      // 交换型
      if(mv.captured){
        const tVal=TYPE_VALUES[mv.captured.type]||0;
        const mVal=TYPE_VALUES[mv.piece.type]||0;
        if(Math.abs(tVal-mVal)<250)exchangeCount++;
      }
      // 进攻型/突破型
      const advancing=(side==='red'&&mv.tr<mv.fr)||(side==='black'&&mv.tr>mv.fr);
      if(advancing&&(mv.piece.type==='车'||mv.piece.type==='马'||mv.piece.type==='炮'))attackCount++;
      // 防守/控制型
      if(mv.piece.type==='士'||mv.piece.type==='相'||mv.piece.type==='象')defenseCount++;
    }
    
    const exchRate=exchangeCount/total;
    const attRate=attackCount/total;
    const defRate=defenseCount/total;
    
    let tactic='balanced';
    let score=0;
    
    if(exchRate>0.4){tactic='exchange';score=exchRate;}
    else if(attRate>0.5){tactic='breakthrough';score=attRate;}
    else if(defRate>0.4){tactic='control';score=defRate;}
    else if(attRate>0.35&&defRate>0.25){tactic='counterPunch';score=0.5;}
    
    if(!this.styleProfile.tactic||this.styleProfile.tactic.style===tactic){
      this.styleProfile.tactic={style:tactic,conf:Math.min(0.85,(this.styleProfile.tactic?.conf||0.3)+0.08)};
    }else{
      const curConf=this.styleProfile.tactic.conf-0.08;
      if(curConf<=0.25)this.styleProfile.tactic={style:tactic,conf:0.35};
      else this.styleProfile.tactic.conf=curConf;
    }
  }
  analyzeOpeningStyle(moves,side){
    // 分析前几步的开局类型
    const firstMoves=moves.slice(0,3);
    if(firstMoves.length===0)return;
    
    let opening=null;
    const first=firstMoves[0];
    
    // 第一步判断
    if(first.piece.type==='炮'){
      if(first.toCol===4)opening='cannonOpening'; // 当头炮
      else if(Math.abs(first.toCol-4)>=2)opening='cannonOpening'; // 过宫炮/士角炮
      else opening='cannonOpening';
    }else if(first.piece.type==='兵'||first.piece.type==='卒'){
      opening='pawnOpening'; // 仙人指路
    }else if(first.piece.type==='相'||first.piece.type==='象'){
      opening='elephantOpening'; // 飞相局
    }else if(first.piece.type==='马'){
      opening='horseOpening'; // 起马局
    }else if(first.piece.type==='车'){
      opening='wildOpening'; // 铁滑车之类
    }
    
    if(opening){
      this.styleProfile.opening={style:opening,conf:0.7};
    }
  }
  analyzeTemperament(moves,side){
    const recent=moves.slice(-15);
    // 计算气质指标
    let aggression=0,defensiveness=0,flexibility=0,steadiness=0;
    const total=recent.length;
    
    for(const mv of recent){
      const advancing=(side==='red'&&mv.tr<mv.fr)||(side==='black'&&mv.tr>mv.fr);
      const retreating=(side==='red'&&mv.tr>mv.fr&&mv.piece.type!=='兵')||
                       (side==='black'&&mv.tr<mv.fr&&mv.piece.type!=='卒');
      
      if(advancing&&mv.captured)aggression+=2; // 猛攻
      else if(advancing)aggression+=1;
      
      if(mv.piece.type==='士'||mv.piece.type==='相'||mv.piece.type==='象')defensiveness+=2;
      else if(retreating)defensiveness+=1;
      
      // 灵活性：不同类型棋子的移动
      if(mv.piece.type==='马'||mv.piece.type==='炮')flexibility+=1;
    }
    
    const aggScore=aggression/total;
    const defScore=defensiveness/total;
    const flexScore=flexibility/total;
    
    // 四象判断
    let temperament,conf;
    if(aggScore>=2&&defScore<1){temperament='taiyang';conf=0.6;} // 太阳：极攻
    else if(aggScore>=1.2&&flexScore>=0.5){temperament='shaoyang';conf=0.5;} // 少阳：灵动
    else if(defScore>=1.5&&aggScore>=0.8){temperament='shaoyin';conf=0.5;} // 少阴：反击
    else if(defScore>=2){temperament='taiyin';conf=0.6;} // 太阴：极守
    else{temperament='shaoyang';conf=0.3;}
    
    if(!this.styleProfile.temperament||this.styleProfile.temperament.style===temperament){
      this.styleProfile.temperament={style:temperament,conf:Math.min(0.8,(this.styleProfile.temperament?.conf||0.3)+0.06)};
    }else{
      const curConf=this.styleProfile.temperament.conf-0.06;
      if(curConf<=0.25)this.styleProfile.temperament={style:temperament,conf:0.3};
      else this.styleProfile.temperament.conf=curConf;
    }
  }
  detectStyleShift(){
    // 检测对手是否切换了风格
    if(!this.styleProfile||this.styleProfile.history.length<5)return;
    const hist=this.styleProfile.history;
    const recent=hist.slice(-3);
    const earlier=hist.slice(0,3);
    
    let shiftDetected=false;
    // 比较早期和近期的攻防倾向
    const recentOD=recent.filter(h=>h.od).map(h=>h.od.style);
    const earlierOD=earlier.filter(h=>h.od).map(h=>h.od.style);
    
    if(recentOD.length>=2&&earlierOD.length>=2){
      const recentMode=this.modeOf(recentOD);
      const earlierMode=this.modeOf(earlierOD);
      if(recentMode!==earlierMode&&!this.styleShiftDetected){
        this.styleShiftDetected=true;
        this.styleShiftCount=(this.styleShiftCount||0)+1;
        // 风格切换时重置部分置信度
        if(this.styleProfile.tactic)this.styleProfile.tactic.conf*=0.6;
      }
    }
  }
  modeOf(arr){
    const counts={};
    arr.forEach(x=>counts[x]=(counts[x]||0)+1);
    let best=null,bestCount=0;
    for(const k in counts){if(counts[k]>bestCount){bestCount=counts[k];best=k;}}
    return best;
  }
  updatePrimaryStyle(){
    // 综合出一个主风格用于评估函数
    if(!this.styleProfile)return;
    const od=this.styleProfile.offenseDefense;
    if(od&&od.conf>0.4){
      this.opponentStyle=od.style;
      this.styleConfidence=od.conf;
    }
    // 同时保存到双方画像中（用于AI vs AI风格面板）
    // 注意：this.styleProfile存储的是"对手"的风格
    // 我们需要找到对手是哪一方，然后存入对应位置
  }
  // 保存对手风格到双方画像（在分析完对手风格后调用）
  saveOpponentStyleProfile(oppSide){
    if(!this.styleProfile)return;
    if(!this.styleProfiles)this.styleProfiles={red:null,black:null};
    // 深拷贝风格画像
    this.styleProfiles[oppSide]=JSON.parse(JSON.stringify(this.styleProfile));
  }
  // 象棋风格维度中文名称
  getTopTwoDimensions(sp){
    if(!sp)return [null,null];
    const nameMap={
      offenseDefense:'攻防倾向',
      tactic:'战术打法',
      opening:'开局流派',
      temperament:'棋手气质'
    };
    const styleNames={
      offense:'进攻型',defense:'防守型',balanced:'均衡型',
      sharp:'搏杀型',steady:'稳健型',tricky:'诡秘型',
      central:'中炮派',screen:'屏风马',feihu:'飞相局',
      dragon:'青龙',tiger:'白虎',rose:'朱雀',tortoise:'玄武'
    };
    const dims=[];
    for(const key in sp){
      const v=sp[key];
      if(v&&typeof v==='object'&&v.style&&typeof v.conf==='number'){
        dims.push({
          key,
          style:v.style,
          conf:v.conf,
          name:(nameMap[key]||key)+'·'+(styleNames[v.style]||v.style),
          desc:''
        });
      }
    }
    dims.sort((a,b)=>b.conf-a.conf);
    return dims.slice(0,2);
  }
  isLikelyExchange(move,side){
    if(!move.captured)return false;
    const targetVal=TYPE_VALUES[move.captured.type]||0;
    const moverVal=TYPE_VALUES[move.piece.type]||0;
    // 价值接近的吃子更可能是交换
    return Math.abs(targetVal-moverVal)<200;
  }
  // ===== 全局战略评估 =====
  evaluateGlobalStrategy(aiSide){
    const oppSide=aiSide==='red'?'black':'red';
    let bonus=0;
    if(!this.styleProfile)return 0;
    
    const od=this.styleProfile.offenseDefense;
    const tactic=this.styleProfile.tactic;
    const temperament=this.styleProfile.temperament;
    
    // 统计双方子力
    let myMajorPieces=0,oppMajorPieces=0;
    let myPawns=0,oppPawns=0;
    let myDefenders=0,oppDefenders=0;
    for(let r=0;r<this.ROWS;r++)for(let c=0;c<this.COLS;c++){
      const p=this.board[r][c];
      if(!p||!p.revealed)continue;
      if(p.side===aiSide){
        if(p.type==='车'||p.type==='马'||p.type==='炮')myMajorPieces++;
        if(p.type==='兵'||p.type==='卒')myPawns++;
        if(p.type==='士'||p.type==='相'||p.type==='象')myDefenders++;
      }else{
        if(p.type==='车'||p.type==='马'||p.type==='炮')oppMajorPieces++;
        if(p.type==='兵'||p.type==='卒')oppPawns++;
        if(p.type==='士'||p.type==='相'||p.type==='象')oppDefenders++;
      }
    }
    
    // ===== 攻防倾向应对 =====
    if(od&&od.conf>0.35){
      switch(od.style){
        case 'offense': // 进攻型 - 防守反击
          bonus+=myDefenders*15*od.conf;
          bonus-=myMajorPieces*2*od.conf;
          bonus+=(2-oppDefenders)*25*od.conf;
          break;
        case 'defense': // 防御型 - 围困压缩
          bonus+=myMajorPieces*10*od.conf;
          bonus+=myPawns*6*od.conf;
          const avgOppRow=this.averageRow(oppSide);
          const oppTurtled=(oppSide==='red')?(avgOppRow>6):(avgOppRow<3);
          if(oppTurtled)bonus+=20*od.conf;
          break;
        case 'balanced': // 攻守兼备 - 比拼综合
          bonus+=myMajorPieces*3*od.conf;
          break;
      }
    }
    
    // ===== 战术打法应对 =====
    if(tactic&&tactic.conf>0.35){
      switch(tactic.style){
        case 'exchange': // 消耗型 - 保留主力
          bonus+=myMajorPieces*8*tactic.conf;
          bonus+=myPawns*10*tactic.conf;
          if(myMajorPieces<=2)bonus+=myPawns*6*tactic.conf;
          break;
        case 'breakthrough': // 突破型 - 守住要害
          bonus+=myDefenders*12*tactic.conf;
          bonus+=(oppMajorPieces-myMajorPieces)*5*tactic.conf;
          break;
        case 'control': // 控制型 - 寻找突破
          bonus+=myMajorPieces*6*tactic.conf;
          break;
        case 'counterPunch': // 拆解型 - 隐藏意图
          bonus+=4*tactic.conf; // 略偏保守
          break;
      }
    }
    
    // ===== 棋手气质应对 =====
    if(temperament&&temperament.conf>0.4){
      switch(temperament.style){
        case 'taiyang': // 太阳派 - 以柔克刚
          bonus+=myDefenders*8*temperament.conf;
          break;
        case 'taiyin': // 太阴派 - 耐心磨棋
          bonus+=myPawns*5*temperament.conf;
          break;
        case 'shaoyang': // 少阳派 - 比拼灵活
          bonus+=myMajorPieces*4*temperament.conf;
          break;
        case 'shaoyin': // 少阴派 - 加强进攻
          bonus+=myMajorPieces*5*temperament.conf;
          break;
      }
    }
    
    // 风格切换时增加不确定性
    if(this.styleShiftDetected){
      bonus*=0.5; // 降低风格应对的权重
    }
    
    return bonus;
  }
  averageRow(side){
    let total=0,count=0;
    for(let r=0;r<this.ROWS;r++)for(let c=0;c<this.COLS;c++){
      const p=this.board[r][c];
      if(p&&p.revealed&&p.side===side){total+=r;count++;}
    }
    return count>0?total/count:4.5;
  }
  evaluateBoard(aiSide){
    let score=0;
    let myMobility=0,oppMobility=0;
    let myPieces={车:0,马:0,炮:0,相:0,士:0,兵:0,帅:0};
    let oppPieces={车:0,马:0,炮:0,相:0,士:0,兵:0,帅:0};
    for(let r=0;r<this.ROWS;r++)for(let c=0;c<this.COLS;c++){
      const p=this.board[r][c];
      if(!p||!p.revealed)continue;
      const val=TYPE_VALUES[p.type]||0;
      const posIdx=r*this.COLS+c;
      const pstVal=(PST[p.type]&&PST[p.type][posIdx])?PST[p.type][posIdx]:0;
      const totalVal=val*10+pstVal;
      score+=(p.side===aiSide)?totalVal:-totalVal;
      const pieceCount=p.side===aiSide?myPieces:oppPieces;
      if(pieceCount[p.type]!==undefined)pieceCount[p.type]++;
      const moves=this.getLegalMovesForPiece(r,c,p,null);
      const mobility=moves.length;
      if(p.side===aiSide)myMobility+=mobility;
      else oppMobility+=mobility;
      if(p.type==='兵'||p.type==='卒'){
        const crossed=(p.side==='red'&&r<5)||(p.side==='black'&&r>4);
        if(crossed)score+=(p.side===aiSide)?50:-50;
        const advance=p.side==='red'?(9-r):r;
        score+=(p.side===aiSide)?advance*8:-advance*8;
        if(crossed&&c>=2&&c<=6)score+=(p.side===aiSide)?20:-20;
      }
      if(p.type==='车'){
        let openFile=true;
        for(let rr=0;rr<this.ROWS;rr++){
          if(rr!==r&&this.board[rr][c]){openFile=false;break;}
        }
        if(openFile)score+=(p.side===aiSide)?35:-35;
        if(c===4||c===3||c===5)score+=(p.side===aiSide)?15:-15;
      }
      if(p.type==='马'){
        const centerDist=Math.abs(c-4)+Math.abs(r-4.5);
        score+=(p.side===aiSide)?(20-centerDist*3):-(20-centerDist*3);
        let legBlocked=0;
        for(const [br,bc] of [[r-1,c],[r+1,c],[r,c-1],[r,c+1]]){
          if(this.isInBoard(br,bc)&&this.board[br][bc])legBlocked++;
        }
        score+=(p.side===aiSide)?(-legBlocked*12):(legBlocked*12);
      }
      if(p.type==='炮'){
        let hasPlatform=false,platformCount=0;
        for(const [dr,dc] of [[1,0],[-1,0],[0,1],[0,-1]]){
          let nr=r+dr,nc=c+dc,found=false;
          while(this.isInBoard(nr,nc)){
            if(this.board[nr][nc]){
              if(found){hasPlatform=true;platformCount++;break;}
              found=true;
            }
            nr+=dr;nc+=dc;
          }
        }
        if(hasPlatform)score+=(p.side===aiSide)?(20+platformCount*5):(-20-platformCount*5);
      }
      if(p.type==='帅'||p.type==='将'){
        const danger=this.isSquareAttacked(r,c,p.side==='red'?'black':'red',this.board);
        if(danger)score+=(p.side===aiSide)?-80:80;
      }
      if(p.type==='相'||p.type==='象'){
        const defensivePos=(p.side==='red'&&r>=7)||(p.side==='black'&&r<=2);
        if(defensivePos)score+=(p.side===aiSide)?15:-15;
      }
    }
    score+=(myMobility-oppMobility)*2;
    if(myPieces.车>=2)score+=40;if(oppPieces.车>=2)score-=40;
    if(myPieces.马>=2)score+=20;if(oppPieces.马>=2)score-=20;
    if(myPieces.炮>=2)score+=25;if(oppPieces.炮>=2)score-=25;
    if(myPieces.车>=1&&myPieces.马>=1&&myPieces.炮>=1)score+=30;
    if(oppPieces.车>=1&&oppPieces.马>=1&&oppPieces.炮>=1)score-=30;
    if(myPieces.士>=2&&myPieces.相>=2)score+=35;
    if(oppPieces.士>=2&&(oppPieces.相>=2||oppPieces.象>=2))score-=35;
    score+=(myPieces.兵-oppPieces.兵)*15;
    let mySpace=0,oppSpace=0;
    for(let r=0;r<this.ROWS;r++)for(let c=0;c<this.COLS;c++){
      if(!this.board[r][c]){
        if(r<5)oppSpace++;
        else mySpace++;
      }
    }
    if(aiSide==='red')score+=(mySpace-oppSpace)*1;
    else score+=(oppSpace-mySpace)*1;
    const myKing=this.findKing(aiSide);
    if(!myKing)return-1000000;
    const oppKing=this.findKing(aiSide==='red'?'black':'red');
    if(!oppKing)return 1000000;
    if(this.isInCheck(aiSide))score-=100;
    if(this.isInCheck(aiSide==='red'?'black':'red'))score+=120;
    if(this.aiPersonality==='aggressive'){
      score+=myMobility*1;
      score-=(myPieces.士+myPieces.相)*5;
    }else if(this.aiPersonality==='solid'){
      score-=myMobility*0.5;
      score+=(myPieces.士+myPieces.相)*10;
    }
    // 全局战略评估（根据对手风格调整）
    score+=this.evaluateGlobalStrategy(aiSide);
    if(this.moveHistory.length>40)score+=Math.random()*8;
    return score;
  }
  // ===== 盲棋AI =====
  blindBestAction(side){
    const actions=this.getAllLegalMoves(side);
    if(actions.length===0)return null;
    if(actions.length===1)return actions[0];
    
    // 根据难度决定搜索深度
    let searchDepth=1;
    if(CONFIG.difficulty==='medium')searchDepth=2;
    else if(CONFIG.difficulty==='hard')searchDepth=3;
    else if(CONFIG.difficulty==='master')searchDepth=3;
    
    if(searchDepth<=1){
      // 单层评估
      const scored=actions.map(a=>({action:a,score:this.evaluateBlindAction(a,side)}));
      scored.sort((a,b)=>b.score-a.score);
      const topScore=scored[0].score;
      const threshold=CONFIG.difficulty==='easy'?120:(CONFIG.difficulty==='hard'||CONFIG.difficulty==='master'?30:60);
      const candidates=scored.filter(x=>(topScore-x.score)<threshold);
      return candidates[Math.floor(Math.random()*candidates.length)].action;
    }
    
    // 多层搜索：先快速排序，再对前N个走法做深度搜索
    const quickScored=actions.map(a=>({action:a,score:this.evaluateBlindAction(a,side)}));
    quickScored.sort((a,b)=>b.score-a.score);
    
    // 只搜索前几个最佳走法，避免搜索空间过大
    const topN=CONFIG.difficulty==='master'?12:8;
    const candidates=quickScored.slice(0,Math.min(topN,quickScored.length));
    
    let bestMove=candidates[0].action;
    let bestScore=-Infinity;
    
    for(const item of candidates){
      const snap=this.snapshotBoard();
      this.applyAction(item.action);
      let score;
      if(this.gameOver&&this.winner===side)score=100000;
      else if(this.gameOver)score=-100000;
      else score=this.blindMinimax(searchDepth-1,side==='red'?'black':'red',side,-Infinity,Infinity);
      this.restoreBoard(snap);
      if(score>bestScore){bestScore=score;bestMove=item.action;}
    }
    
    // 根据难度加入随机性
    const mistakeChance=CONFIG.difficulty==='easy'?0.25:(CONFIG.difficulty==='medium'?0.12:(CONFIG.difficulty==='hard'?0.05:0.02));
    if(Math.random()<mistakeChance&&candidates.length>2){
      const midCandidates=candidates.slice(1,Math.min(4,candidates.length));
      return midCandidates[Math.floor(Math.random()*midCandidates.length)].action;
    }
    
    return bestMove;
  }
  blindMinimax(depth,currentSide,aiSide,alpha,beta){
    if(depth===0)return this.evaluateBlindBoard(aiSide);
    if(this.gameOver)return this.winner===aiSide?100000+depth:-100000-depth;
    
    const moves=this.getAllLegalMoves(currentSide);
    if(moves.length===0)return currentSide===aiSide?-100000-depth:100000+depth;
    
    // 快速排序以提升剪枝效率
    const scored=moves.map(a=>({action:a,score:this.evaluateBlindActionQuick(a,currentSide)}));
    scored.sort((a,b)=>b.score-a.score);
    
    // 只搜索前几个最佳走法
    const maxMoves=depth>=2?10:15;
    const searchMoves=scored.slice(0,Math.min(maxMoves,scored.length));
    
    if(currentSide===aiSide){
      let maxVal=-Infinity;
      for(const item of searchMoves){
        const snap=this.snapshotBoard();
        this.applyAction(item.action);
        const score=this.blindMinimax(depth-1,currentSide==='red'?'black':'red',aiSide,alpha,beta);
        this.restoreBoard(snap);
        if(score>maxVal)maxVal=score;
        if(score>alpha)alpha=score;
        if(beta<=alpha)break;
      }
      return maxVal;
    }else{
      let minVal=Infinity;
      for(const item of searchMoves){
        const snap=this.snapshotBoard();
        this.applyAction(item.action);
        const score=this.blindMinimax(depth-1,currentSide==='red'?'black':'red',aiSide,alpha,beta);
        this.restoreBoard(snap);
        if(score<minVal)minVal=score;
        if(score<beta)beta=score;
        if(beta<=alpha)break;
      }
      return minVal;
    }
  }
  evaluateBlindActionQuick(action,side){
    // 快速评估，用于移动排序
    let score=0;
    if(action.isReveal){
      score+=20;
      const p=this.board[action.fromRow][action.fromCol];
      if(p&&p.side===side)score+=15;
    }else{
      const target=this.board[action.toRow][action.toCol];
      if(target&&target.side!==side){
        score+=(TYPE_VALUES[target.type]||0)*2;
        if(target.type==='帅'||target.type==='将')score+=9000;
      }
      if(action.assumedType)score+=(TYPE_VALUES[action.assumedType]||0)*0.5;
    }
    return score;
  }
  evaluateBlindBoard(aiSide){
    // 盲棋局面评估
    let score=0;
    let myRevealed=0,oppRevealed=0;
    let myHidden=0,oppHidden=0;
    let myMaterial=0,oppMaterial=0;
    
    for(let r=0;r<this.ROWS;r++)for(let c=0;c<this.COLS;c++){
      const p=this.board[r][c];
      if(!p)continue;
      const val=TYPE_VALUES[p.type]||0;
      if(p.side===aiSide){
        if(p.revealed){myRevealed++;myMaterial+=val;}
        else myHidden++;
      }else{
        if(p.revealed){oppRevealed++;oppMaterial+=val;}
        else oppHidden++;
      }
      // 位置评估
      if(p.revealed){
        const centerDist=Math.abs(c-3.5)+Math.abs(r-1.5);
        const posBonus=(6-centerDist)*3;
        if(p.side===aiSide)score+=posBonus;
        else score-=posBonus;
        // 兵/卒推进奖励
        if((p.type==='兵'||p.type==='卒')&&p.side===aiSide){
          const advance=aiSide==='red'?(3-r):r;
          score+=advance*8;
        }
      }
    }
    
    // 物质优势
    score+=(myMaterial-oppMaterial)*2;
    // 已翻开棋子数量（信息优势）
    score+=(myRevealed-oppRevealed)*5;
    // 未翻开棋子数量（潜在力量）
    score+=(myHidden-oppHidden)*3;
    // 灵活性/机动性估计
    const mobilityEst=myRevealed*3-oppRevealed*3;
    score+=mobilityEst;
    
    // 将帅安全
    const myKing=this.findBlindKing(aiSide);
    const oppKing=this.findBlindKing(aiSide==='red'?'black':'red');
    if(!myKing)score-=50000;
    if(!oppKing)score+=50000;
    
    return score;
  }
  findBlindKing(side){
    const kingType=side==='red'?'帅':'将';
    for(let r=0;r<this.ROWS;r++)for(let c=0;c<this.COLS;c++){
      const p=this.board[r][c];
      if(p&&p.revealed&&p.side===side&&p.type===kingType)return{r,c};
    }
    return null;
  }
  evaluateBlindAction(action,side){
    let score=Math.random()*10;
    if(action.isReveal){
      score+=30;
      const p=this.board[action.fromRow][action.fromCol];
      if(p){
        if(p.side===side)score+=25;
        else score-=15;
        if(p.type==='帅'||p.type==='将')score+=(p.side===side?50:-50);
        if(p.type==='车')score+=25;
        if(p.type==='马'||p.type==='炮')score+=15;
        if(p.type==='兵'||p.type==='卒')score+=5;
      }
      // 优先翻开中心区域的棋子
      const centerDist=Math.abs(action.fromCol-3.5)+Math.abs(action.fromRow-1.5);
      score+=Math.max(0,(6-centerDist))*3;
      // 避免第一手就翻开自己的帅/将
      if(this.moveHistory.length<2&&p&&p.side===side&&(p.type==='帅'||p.type==='将'))score-=30;
    }else{
      const target=this.board[action.toRow][action.toCol];
      const mover=this.board[action.fromRow][action.fromCol];
      // 吃子得分
      if(target&&target.revealed&&target.side!==side){
        score+=(TYPE_VALUES[target.type]||0)*2;
        if(target.type==='帅'||target.type==='将')score+=9000;
        // 交换评估：用弱子吃强子更划算
        if(mover&&mover.revealed){
          const trade=(TYPE_VALUES[target.type]||0)-(TYPE_VALUES[mover.type]||0);
          score+=trade;
        }
      }
      // 吃未翻开的棋子（有风险但可能有收益）
      if(target&&!target.revealed){
        score+=40; // 冒险吃暗子的基础分
        // 如果己方是大子，吃暗子风险高
        if(mover&&mover.revealed){
          const moverVal=TYPE_VALUES[mover.type]||0;
          if(moverVal>300)score-=20; // 大子少吃暗子
        }
      }
      // 移动棋子的类型加成
      if(mover){
        if(mover.type==='兵'||mover.type==='卒'){
          const advance=side==='red'?(action.fromRow-action.toRow):(action.toRow-action.fromRow);
          score+=advance*10;
        }
        if(mover.type==='炮')score+=15;
        if(mover.type==='车')score+=8;
      }
      // 假设类型移动的额外评估
      if(action.assumedType){
        score+=(TYPE_VALUES[action.assumedType]||0)*0.3;
        // 优先用假设的强子移动，因为移动后会翻开，若是弱子也不亏太多
        if(action.assumedType==='车'||action.assumedType==='马'||action.assumedType==='炮')score+=10;
      }
      // 位置优势：向中心移动
      const fromCenter=Math.abs(action.fromCol-3.5)+Math.abs(action.fromRow-1.5);
      const toCenter=Math.abs(action.toCol-3.5)+Math.abs(action.toRow-1.5);
      if(toCenter<fromCenter)score+=5;
      score+=Math.random()*8;
    }
    return score;
  }
  // ===== 绘制 =====
  draw(){
    const ctx=this.ctx;const cs=this.cellSize;
    ctx.clearRect(0,0,this.canvas.width,this.canvas.height);
    if(this.mode==='blind'){this.drawBlindBoard();return;}
    ctx.strokeStyle='#4a3018';ctx.lineWidth=1.5;
    for(let r=0;r<10;r++){ctx.beginPath();ctx.moveTo(this.offsetX,this.offsetY+r*cs);ctx.lineTo(this.offsetX+8*cs,this.offsetY+r*cs);ctx.stroke();}
    for(let c=0;c<9;c++){
      if(c===0||c===8){ctx.beginPath();ctx.moveTo(this.offsetX+c*cs,this.offsetY);ctx.lineTo(this.offsetX+c*cs,this.offsetY+9*cs);ctx.stroke();}
      else{ctx.beginPath();ctx.moveTo(this.offsetX+c*cs,this.offsetY);ctx.lineTo(this.offsetX+c*cs,this.offsetY+4*cs);ctx.stroke();ctx.beginPath();ctx.moveTo(this.offsetX+c*cs,this.offsetY+5*cs);ctx.lineTo(this.offsetX+c*cs,this.offsetY+9*cs);ctx.stroke();}
    }
    ctx.beginPath();ctx.moveTo(this.offsetX+3*cs,this.offsetY);ctx.lineTo(this.offsetX+5*cs,this.offsetY+2*cs);ctx.moveTo(this.offsetX+5*cs,this.offsetY);ctx.lineTo(this.offsetX+3*cs,this.offsetY+2*cs);ctx.stroke();
    ctx.beginPath();ctx.moveTo(this.offsetX+3*cs,this.offsetY+7*cs);ctx.lineTo(this.offsetX+5*cs,this.offsetY+9*cs);ctx.moveTo(this.offsetX+5*cs,this.offsetY+7*cs);ctx.lineTo(this.offsetX+3*cs,this.offsetY+9*cs);ctx.stroke();
    ctx.fillStyle='#8a6a30';ctx.font='bold '+(cs*0.32)+'px KaiTi,STKaiti,serif';ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillText('楚 河',this.offsetX+2*cs,this.offsetY+4.5*cs);ctx.fillText('汉 界',this.offsetX+6*cs,this.offsetY+4.5*cs);
    if(this.selected){
      const moves=this.getLegalMoves(this.selected.row,this.selected.col);
      ctx.fillStyle='rgba(74,153,119,0.35)';
      moves.forEach(m=>{ctx.beginPath();ctx.arc(this.offsetX+m.col*cs,this.offsetY+m.row*cs,cs*0.16,0,Math.PI*2);ctx.fill();});
      ctx.strokeStyle='#e8c45a';ctx.lineWidth=2.5;
      ctx.strokeRect(this.offsetX+this.selected.col*cs-cs*0.4,this.offsetY+this.selected.row*cs-cs*0.4,cs*0.8,cs*0.8);
    }
    for(let r=0;r<10;r++)for(let c=0;c<9;c++){const p=this.board[r][c];if(p)this.drawPiece(this.offsetX+c*cs,this.offsetY+r*cs,p,cs);}
  }
  drawBlindBoard(){
    const ctx=this.ctx;const cs=this.cellSize;
    ctx.strokeStyle='#4a3018';ctx.lineWidth=1.2;
    for(let r=0;r<=4;r++){ctx.beginPath();ctx.moveTo(this.offsetX,this.offsetY+r*cs);ctx.lineTo(this.offsetX+7*cs,this.offsetY+r*cs);ctx.stroke();}
    for(let c=0;c<=8;c++){ctx.beginPath();ctx.moveTo(this.offsetX+c*cs,this.offsetY);ctx.lineTo(this.offsetX+c*cs,this.offsetY+3*cs);ctx.stroke();}
    if(this.selected){
      let moves=[];
      const selPiece=this.board[this.selected.row][this.selected.col];
      if(this.assumedType) moves=this.getBlindMoves(this.selected.row,this.selected.col,this.assumedType);
      else if(selPiece&&selPiece.revealed) moves=this.getBlindMoves(this.selected.row,this.selected.col);
      ctx.fillStyle='rgba(74,153,119,0.35)';
      moves.forEach(m=>{ctx.beginPath();ctx.arc(this.offsetX+m.col*cs,this.offsetY+m.row*cs,cs*0.16,0,Math.PI*2);ctx.fill();});
      ctx.strokeStyle='#e8c45a';ctx.lineWidth=2.5;
      ctx.strokeRect(this.offsetX+this.selected.col*cs-cs*0.4,this.offsetY+this.selected.row*cs-cs*0.4,cs*0.8,cs*0.8);
    }
    for(let r=0;r<4;r++)for(let c=0;c<8;c++){
      const p=this.board[r][c];if(!p)continue;
      const x=this.offsetX+c*cs,y=this.offsetY+r*cs;
      if(!p.revealed){
        const rad=cs*0.4;
        const grad=ctx.createRadialGradient(x-rad*0.3,y-rad*0.3,rad*0.1,x,y,rad);
        grad.addColorStop(0,'#8b6914');grad.addColorStop(1,'#5a4010');
        ctx.beginPath();ctx.arc(x,y,rad,0,Math.PI*2);ctx.fillStyle=grad;ctx.fill();
        ctx.strokeStyle='#3a2808';ctx.lineWidth=2;ctx.stroke();
        ctx.fillStyle='#d4a843';ctx.font='bold '+(cs*0.3)+'px KaiTi,STKaiti,serif';ctx.textAlign='center';ctx.textBaseline='middle';
        ctx.fillText('?',x,y+1);
      }else{
        this.drawPiece(x,y,p,cs);
      }
    }
  }
  drawPiece(x,y,piece,cs){
    const ctx=this.ctx;const r=cs*0.4;
    const grad=ctx.createRadialGradient(x-r*0.3,y-r*0.3,r*0.1,x,y,r);
    grad.addColorStop(0,'#f5e6c8');grad.addColorStop(1,'#d4b896');
    ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=grad;ctx.fill();
    ctx.strokeStyle=piece.side==='red'?'#8b1a1a':'#1a1a1a';ctx.lineWidth=1.8;ctx.stroke();
    ctx.beginPath();ctx.arc(x,y,r*0.8,0,Math.PI*2);ctx.lineWidth=0.8;ctx.stroke();
    ctx.fillStyle=piece.side==='red'?'#c8342c':'#1a1a1a';
    ctx.font='bold '+(cs*0.38)+'px KaiTi,STKaiti,serif';ctx.textAlign='center';ctx.textBaseline='middle';
    ctx.fillText(piece.type,x,y+1);
  }
}
