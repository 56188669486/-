#!/usr/bin/env python3
# 独立中国象棋走法合法性校验器（不依赖引擎逻辑，纯按规则实现）
# 用法: python3 validate_moves.py < "MOVES=b2b6 b7b5 ..."
import sys, re

EMPTY=0
def fen_board(fen):
    b=[[EMPTY]*9 for _ in range(10)]
    rows=fen.split()[0].split('/')
    for r,row in enumerate(rows):
        c=0
        for ch in row:
            if ch.isdigit(): c+=int(ch)
            else:
                side=1 if ch.isupper() else -1
                t={'K':1,'A':2,'B':3,'N':4,'R':5,'C':6,'P':7}[ch.upper()]
                b[r][c]=side*t; c+=1
    return b

def in_palace(r,c,s): return 3<=c<=5 and (7<=r<=9 if s==1 else 0<=r<=2)
def own_half(r,s): return (r>=5) if s==1 else (r<=4)
def opp(s): return -s

def attacked(b, r, c, by):
    for dr,dc,leg in [(-2,-1,(-1,0)),(-2,1,(-1,0)),(-1,2,(0,1)),(1,2,(0,1)),(2,1,(1,0)),(2,-1,(1,0)),(1,-2,(0,-1)),(-1,-2,(0,-1))]:
        nr,nc=r+dr,c+dc
        if 0<=nr<10 and 0<=nc<9 and b[nr][nc]==by*4 and b[r+leg[0]][c+leg[1]]==EMPTY: return True
    for dr,dc in [(-1,0),(1,0),(0,-1),(0,1)]:
        nr,nc=r+dr,c+dc
        if 0<=nr<10 and 0<=nc<9 and abs(b[nr][nc])==1 and (b[nr][nc]>0)==(by>0): return True
    # 将帅照面
    kp=None
    for rr in range(10):
        if b[rr][c]==by*1: kp=rr; break
    if kp is not None and kp!=r:
        lo,hi=sorted((kp,r))
        if all(b[x][c]==EMPTY for x in range(lo+1,hi)): return True
    if in_palace(r,c,by):
        for dr,dc in [(-1,-1),(-1,1),(1,-1),(1,1)]:
            nr,nc=r+dr,c+dc
            if 0<=nr<10 and 0<=nc<9 and b[nr][nc]==by*2: return True
    if own_half(r,by):
        for dr,dc in [(-2,-2),(-2,2),(2,-2),(2,2)]:
            nr,nc=r+dr,c+dc
            if 0<=nr<10 and 0<=nc<9 and b[nr][nc]==by*3 and b[r+dr//2][c+dc//2]==EMPTY: return True
    pr = r+1 if by==1 else r-1
    if 0<=pr<10 and b[pr][c]==by*7: return True
    if by==1:
        if r<=4:
            for dc in (-1,1):
                nc=c+dc
                if 0<=nc<9 and b[r][nc]==7: return True
    else:
        if r>=5:
            for dc in (-1,1):
                nc=c+dc
                if 0<=nc<9 and b[r][nc]==-7: return True
    for dr,dc in [(-1,0),(1,0),(0,-1),(0,1)]:
        nr,nc=r+dr,c+dc
        while 0<=nr<10 and 0<=nc<9:
            if b[nr][nc]!=EMPTY:
                if b[nr][nc]==by*5: return True
                break
            nr+=dr; nc+=dc
    for dr,dc in [(-1,0),(1,0),(0,-1),(0,1)]:
        nr,nc=r+dr,c+dc; screen=False
        while 0<=nr<10 and 0<=nc<9:
            if b[nr][nc]!=EMPTY:
                if not screen: screen=True
                else:
                    if b[nr][nc]==by*6: return True
                    break
            nr+=dr; nc+=dc
    return False

def in_check(b, side):
    for r in range(10):
        for c in range(9):
            if b[r][c]==side*1: return attacked(b,r,c,opp(side))
    return False

def pseudo_moves(b, side):
    res=[]
    for r in range(10):
        for c in range(9):
            p=b[r][c]
            if p==EMPTY or (p>0)!=(side==1): continue
            t=abs(p)
            if t==1:
                for dr,dc in [(-1,0),(1,0),(0,-1),(0,1)]:
                    nr,nc=r+dr,c+dc
                    if 0<=nr<10 and 0<=nc<9 and in_palace(nr,nc,side) and (b[nr][nc]==EMPTY or (b[nr][nc]>0)!=(side==1)): res.append((r,c,nr,nc))
            elif t==2:
                for dr,dc in [(-1,-1),(-1,1),(1,-1),(1,1)]:
                    nr,nc=r+dr,c+dc
                    if 0<=nr<10 and 0<=nc<9 and in_palace(nr,nc,side) and (b[nr][nc]==EMPTY or (b[nr][nc]>0)!=(side==1)): res.append((r,c,nr,nc))
            elif t==3:
                for dr,dc in [(-2,-2),(-2,2),(2,-2),(2,2)]:
                    nr,nc=r+dr,c+dc
                    if 0<=nr<10 and 0<=nc<9 and own_half(nr,side) and b[r+dr//2][c+dc//2]==EMPTY and (b[nr][nc]==EMPTY or (b[nr][nc]>0)!=(side==1)): res.append((r,c,nr,nc))
            elif t==4:
                for dr,dc,leg in [(-2,-1,(-1,0)),(-2,1,(-1,0)),(-1,2,(0,1)),(1,2,(0,1)),(2,1,(1,0)),(2,-1,(1,0)),(1,-2,(0,-1)),(-1,-2,(0,-1))]:
                    nr,nc=r+dr,c+dc
                    if 0<=nr<10 and 0<=nc<9 and b[r+leg[0]][c+leg[1]]==EMPTY and (b[nr][nc]==EMPTY or (b[nr][nc]>0)!=(side==1)): res.append((r,c,nr,nc))
            elif t==5:
                for dr,dc in [(-1,0),(1,0),(0,-1),(0,1)]:
                    nr,nc=r+dr,c+dc
                    while 0<=nr<10 and 0<=nc<9:
                        if b[nr][nc]==EMPTY: res.append((r,c,nr,nc))
                        else:
                            if (b[nr][nc]>0)!=(side==1): res.append((r,c,nr,nc))
                            break
                        nr+=dr; nc+=dc
            elif t==6:
                for dr,dc in [(-1,0),(1,0),(0,-1),(0,1)]:
                    nr,nc=r+dr,c+dc
                    while 0<=nr<10 and 0<=nc<9:
                        if b[nr][nc]==EMPTY: res.append((r,c,nr,nc)); nr+=dr; nc+=dc
                        else: break
                    if 0<=nr<10 and 0<=nc<9:
                        nr+=dr; nc+=dc
                        while 0<=nr<10 and 0<=nc<9:
                            if b[nr][nc]!=EMPTY:
                                if (b[nr][nc]>0)!=(side==1): res.append((r,c,nr,nc))
                                break
                            nr+=dr; nc+=dc
            elif t==7:
                nr=r-1 if side==1 else r+1
                if 0<=nr<10 and (b[nr][c]==EMPTY or (b[nr][c]>0)!=(side==1)): res.append((r,c,nr,c))
                crossed = r<=4 if side==1 else r>=5
                if crossed:
                    for dc in (-1,1):
                        nc=c+dc
                        if 0<=nc<9 and (b[r][nc]==EMPTY or (b[r][nc]>0)!=(side==1)): res.append((r,c,r,nc))
    return res

def legal_moves(b, side):
    lm=[]
    for (r,c,nr,nc) in pseudo_moves(b,side):
        cap=b[nr][nc]
        b[nr][nc]=b[r][c]; b[r][c]=EMPTY
        if not in_check(b,side): lm.append((r,c,nr,nc))
        b[r][c]=b[nr][nc]; b[nr][nc]=cap
    return lm

def main():
    data=sys.stdin.read()
    m=re.search(r'MOVES=(.*)', data)
    if not m: print("NO MOVES FOUND"); sys.exit(1)
    mvlist=m.group(1).split()
    b=fen_board("rnbakabnr/9/1c5c1/p1p1p1p1p/9/9/P1P1P1P1P/1C5C1/9/RNBAKABNR w - - 0 1")
    side=1
    bad=0
    for i,mv in enumerate(mvlist):
        fc,fr,tc,tr=ord(mv[0])-97,9-int(mv[1]),ord(mv[2])-97,9-int(mv[3])
        lm=legal_moves(b,side)
        found=next(((r,c,nr,nc) for (r,c,nr,nc) in lm if (r,c,nr,nc)==(fr,fc,tr,tc)),None)
        if found is None:
            print(f"ILLEGAL ply {i}: {mv} (side {side})"); bad+=1
            continue
        r,c,nr,nc=found
        b[nr][nc]=b[r][c]; b[r][c]=EMPTY
        side=opp(side)
    print(f"validated {len(mvlist)} moves, illegal={bad}")
    sys.exit(1 if bad else 0)

if __name__ == '__main__':
    main()
