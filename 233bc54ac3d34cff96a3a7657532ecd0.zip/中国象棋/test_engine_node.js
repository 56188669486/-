// node 端 UCCI 冒烟测试：加载 qiwang_engine.js，跑一轮完整 UCCI 会话
const path = require('path');
const enginePath = path.resolve(__dirname, process.argv[2] || 'web/qiwang_engine.js');
delete require.cache[require.resolve(enginePath)];
const createQiwangEngine = require(enginePath);

async function main() {
  const Module = await createQiwangEngine();
  function send(cmd) {
    Module.ccall('qw_ucci', null, ['string'], [cmd]);
    return Module.ccall('qw_take_output', 'string', [], []) || '';
  }
  // 握手
  console.log('--- ucci ---'); console.log(send('ucci'));
  console.log('--- isready ---'); console.log(send('isready'));
  // 初始局面
  console.log('--- position startpos + go movetime 600 ---');
  send('position startpos');
  const out = send('go movetime 600');
  console.log(out);
  const m = /bestmove\s+([a-i][0-9][a-i][0-9])/.exec(out);
  if (!m) { console.error('FAIL: no bestmove'); process.exit(1); }
  console.log('bestmove =', m[1]);
  // 指定局面（红车吃黑车）
  console.log('--- fen capture test ---');
  send('position fen r3k4/9/9/9/9/9/9/9/9/R3K4 w - - 0 1');
  const out2 = send('go movetime 600');
  console.log(out2);
  const m2 = /bestmove\s+([a-i][0-9][a-i][0-9])/.exec(out2);
  if (!m2) { console.error('FAIL: no bestmove2'); process.exit(1); }
  console.log('bestmove2 =', m2[1], m2[1]==='a0a9'?'✓':'✗');
  console.log('ALL OK');
  process.exit(0);
}
main().catch(e => { console.error('ERROR', e); process.exit(1); });
