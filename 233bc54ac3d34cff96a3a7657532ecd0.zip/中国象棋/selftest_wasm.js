// wasm 引擎自对弈：走 N 步，输出走法序列（供 Python 独立校验）
// 通过 position startpos moves ... 累积走法，正确推进局面
const createQiwangEngine = require("./qiwang_engine.js");
(async () => {
  const M = await createQiwangEngine();
  M.ccall("qw_reset", null, [], []);
  const send = (c) => {
    M.ccall("qw_ucci", null, ["string"], [c]);
    return M.ccall("qw_take_output", "string", [], []) || "";
  };
  const moves = [];
  for (let ply = 0; ply < 240; ply++) {
    const pos = "position startpos" + (moves.length ? " moves " + moves.join(" ") : "");
    send(pos);
    const out = send("go movetime 80");
    const m = /bestmove\s+([a-i][0-9][a-i][0-9])/.exec(out);
    if (!m) { console.log("NO_MOVE at ply", ply); break; }
    moves.push(m[1]);
    if (ply < 8 || ply % 20 === 0) console.log(ply, m[1]);
  }
  console.log("PLAYED=" + moves.length);
  console.log("MOVES=" + moves.join(" "));
  process.exit(0);
})();
