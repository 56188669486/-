# 中国象棋

- `xiangqi.js` — 象棋游戏逻辑（正常对战 + 盲棋翻棋，含吃子/胜负/风格识别）
- `qiwang_engine.js` — C++ 源码用 Emscripten 编译为 WASM 的象棋引擎（SINGLE_FILE，WASM 已内嵌）
- `qiwang_worker.js` — 在 Web Worker 中通过 UCCI 协议驱动上述引擎，不阻塞 UI

其它为开发/自检辅助脚本：`selftest_wasm.js`、`test_engine_node.js`、`validate_moves.py`。

## 引擎说明

- **WASM 引擎**（默认）：`qiwang_engine.js` + `qiwang_worker.js`，通过 UCCI 协议通信，强度更高、更省电
- **内置 JS 引擎**：`xiangqi.js` 自带的启发式搜索（在对战设置里可切换）

盲棋翻棋的「翻棋/吃子」规则、假设棋子类型选择，均由 `xiangqi.js` 实现。