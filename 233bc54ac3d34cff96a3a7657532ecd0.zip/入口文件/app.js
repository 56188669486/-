// 棋王 · 入口装配（设置面板事件绑定、类型选择、AI对战控制、初始化）
// ============================================================
// 设置面板事件绑定
// ============================================================
function bindOptionRow(rowId,onChange){
  const row=$(rowId);
  if(!row)return;
  row.querySelectorAll('.settings-option').forEach(btn=>{
    btn.addEventListener('click',()=>{
      row.querySelectorAll('.settings-option').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      if(onChange)onChange();
    });
  });
}
bindOptionRow('opponentTypeRow',()=>GameLauncher.updateSettingsVisibility());
bindOptionRow('difficultyRow');
bindOptionRow('engineRow');
bindOptionRow('playerSideRow');
bindOptionRow('goSizeRow');
document.querySelectorAll('[data-aivai]').forEach(btn=>{
  btn.addEventListener('click',()=>{
    const side=btn.dataset.aivai;
    document.querySelectorAll(`[data-aivai="${side}"]`).forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    GameLauncher.updateSettingsVisibility();
  });
});
$('settingsOverlay').addEventListener('click',(e)=>{if(e.target===$('settingsOverlay'))GameLauncher.closeSettings();});
// 类型选择器事件
document.querySelectorAll('.type-btn[data-type]').forEach(btn=>{
  btn.addEventListener('click',()=>{
    if(window.CurrentGame && window.CurrentGame instanceof XiangqiGame && window.CurrentGame.mode==='blind'){
      window.CurrentGame.selectBlindType(btn.dataset.type);
    }
  });
});
$('typeCancel').addEventListener('click',()=>{
  if(window.CurrentGame && window.CurrentGame instanceof XiangqiGame) window.CurrentGame.cancelBlindType();
});
$('typeFlip').addEventListener('click',()=>{
  if(window.CurrentGame && window.CurrentGame instanceof XiangqiGame && window.CurrentGame.mode==='blind'){
    window.CurrentGame.flipSelectedBlind();
  }
});
// 历史面板折叠
$('historyToggle').addEventListener('click',()=>{
  const list=$('historyList');
  if(list.classList.contains('hidden')){
    list.classList.remove('hidden');
    $('historyToggle').textContent='收起 ▲';
  }else{
    list.classList.add('hidden');
    $('historyToggle').textContent='展开 ▼';
  }
});
// ============================================================
// AI对战控制
// ============================================================
$('aivaiPlay').addEventListener('click',()=>GameLauncher.startAivai());
$('aivaiPause').addEventListener('click',()=>GameLauncher.pauseAivai());
$('aivaiStop').addEventListener('click',()=>GameLauncher.stopAivai());
$('aivaiSpeed').addEventListener('change',(e)=>{CONFIG.aivaiSpeed=parseInt(e.target.value,10)||1000;});
// ============================================================
// 初始化
// ============================================================
window.addEventListener('load',()=>{
  try{
    const saved=localStorage.getItem('chessMasterConfig');
    if(saved){
      const c=JSON.parse(saved);
      if(c&&c.opponentType)Object.assign(CONFIG,c);
    }
  }catch(e){}
  GameLauncher.updateMenuInfo();
  GameLauncher.syncSettingsUI();
  $('aivaiSpeed').value=String(CONFIG.aivaiSpeed||1000);
});
document.addEventListener('gesturestart',e=>e.preventDefault());
document.addEventListener('dblclick',e=>e.preventDefault());
