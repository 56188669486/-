"""
棋王 v9.0 · 多棋种智能对战平台（网页 + 豆包AI中转服务）
=====================================================
一个 FastAPI 应用同时提供：
  1. 棋王网页（/ ）— 中国象棋（正常对战+盲棋翻棋）、五子棋、围棋
  2. 豆包AI走棋接口（/api/move）— 支持全部棋类
  3. 健康检查（/health, /docs）

同源部署，浏览器直接访问即可，无 CORS 问题。

v9.0 相对前代版本的升级（合并 象棋王 v7.0 与 棋王 v8.0）：
  - 恢复并强化全部对战模式：内置AI / 外部AI(豆包) / 双人对战 / AI对战(AI vs AI)
  - 四类棋种全部接入豆包大模型，含盲棋翻棋的"翻棋/吃子"扩展协议
  - 外部AI调用失败自动降级为内置AI/随机走棋，保证任何情况都能继续下棋

使用前请配置环境变量（可选，不配置则进入随机测试模式）：
  DOUBAO_API_KEY  - 火山方舟API密钥
  ENDPOINT_ID     - 豆包接入点ID（如 ep-2024xxxxxx-xxxxx）

启动：
  python main.py
  然后浏览器打开 http://localhost:8000
"""
import os
import re
import json
import random
import logging
import mimetypes
from pathlib import Path
from typing import Any, Dict, List, Optional
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse, RedirectResponse
try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

# ===================== 配置 =====================
DOUBAO_API_KEY = os.environ.get("DOUBAO_API_KEY", "")
ENDPOINT_ID = os.environ.get("ENDPOINT_ID", "")
PORT = int(os.environ.get("PORT", "8000"))
HOST = os.environ.get("HOST", "0.0.0.0")
REQUEST_TIMEOUT = int(os.environ.get("REQUEST_TIMEOUT", "20"))

# 没有配置API密钥时自动进入"随机下棋"测试模式
TEST_MODE = not DOUBAO_API_KEY or not ENDPOINT_ID or OpenAI is None

# HTML文件路径（与本文件同目录）
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
HTML_PATH = os.path.join(BASE_DIR, "index.html")

# 项目根目录（入口文件/ 的上一级），用于提供 围棋/中国象棋/五子棋 等静态资源
PROJECT_ROOT = Path(BASE_DIR).resolve().parent

# 静态资源 MIME 映射（KataGo 本地AI 需正确提供 .wasm / .bin.gz 等二进制）
_MIME = {
    ".html": "text/html",
    ".htm": "text/html",
    ".js": "application/javascript",
    ".mjs": "application/javascript",
    ".json": "application/json",
    ".css": "text/css",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".wasm": "application/wasm",
    ".gz": "application/octet-stream",
    ".bin": "application/octet-stream",
    ".map": "application/json",
    ".py": "text/plain",
    ".txt": "text/plain",
    ".md": "text/plain",
}

# ===================== 日志 =====================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("qiwang-v9")

# ===================== FastAPI =====================
app = FastAPI(title="棋王·多棋种智能对战平台", version="9.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 豆包客户端（测试模式下不初始化）
client = None
if not TEST_MODE:
    client = OpenAI(
        base_url="https://ark.cn-beijing.volces.com/api/v3",
        api_key=DOUBAO_API_KEY,
    )
    logger.info("豆包API客户端已初始化，接入点: %s", ENDPOINT_ID)
else:
    logger.warning("未配置 DOUBAO_API_KEY / ENDPOINT_ID，进入【随机下棋】测试模式")


# ===================== 工具函数 =====================
def extract_json(text: str) -> Optional[Dict[str, Any]]:
    """从大模型输出中健壮地提取JSON对象。"""
    if not text:
        return None
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    json_block = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if json_block:
        try:
            return json.loads(json_block.group(1).strip())
        except json.JSONDecodeError:
            pass
    brace_match = re.search(r"\{[\s\S]*\}", text)
    if brace_match:
        try:
            return json.loads(brace_match.group(0))
        except json.JSONDecodeError:
            pass
    try:
        fixed = text.replace("'", '"')
        fixed = re.sub(r",\s*([}\]])", r"\1", fixed)
        return json.loads(fixed)
    except (json.JSONDecodeError, AttributeError):
        pass
    return None


def pick_random_move(legal_moves: List[Dict[str, Any]], game_type: str, mode: str = "battle") -> Dict[str, Any]:
    """从合法走法中随机选一步（带启发式偏好）。"""
    if not legal_moves:
        return {}

    def _is_reveal(m: Dict[str, Any]) -> bool:
        return bool(m.get("isReveal")) or m.get("pieceType") == "reveal"

    if game_type == "xiangqi":
        if mode == "blind":
            # 盲棋：先看有没有直接吃子（大子优先），偶尔翻棋
            capture_moves = [m for m in legal_moves if not _is_reveal(m) and m.get("captured")]
            if capture_moves and random.random() < 0.6:
                capture_moves.sort(key=lambda m: -(m.get("capturedValue") or 0))
                return capture_moves[0]
            reveal_moves = [m for m in legal_moves if _is_reveal(m)]
            if reveal_moves and random.random() < 0.35:
                return random.choice(reveal_moves)
            moves = [m for m in legal_moves if not _is_reveal(m)]
            if moves:
                return random.choice(moves)
            if reveal_moves:
                return random.choice(reveal_moves)
            return random.choice(legal_moves)
        # 正常象棋：60%概率优先吃子
        capture_moves = [m for m in legal_moves if m.get("captured")]
        if capture_moves and random.random() < 0.6:
            return random.choice(capture_moves)
    elif game_type in ("gomoku", "go"):
        # 五子棋/围棋：优先中心区域
        center_moves = [m for m in legal_moves if 5 <= m.get("row", 7) <= 9 and 5 <= m.get("col", 7) <= 9]
        if center_moves and random.random() < 0.5:
            return random.choice(center_moves)
    return random.choice(legal_moves)


def build_system_prompt(game_type: str, side: str, mode: str = "battle") -> str:
    """根据棋类构建系统提示词。"""
    if game_type == "xiangqi":
        red_side = "红方" if side == "red" else "黑方"
        if mode == "blind":
            return f"""你是中国象棋盲棋（翻棋）大师。棋盘 4 行 × 8 列，row 0-3 从上到下，col 0-7 从左到右。
32 枚棋子背面朝上随机摆放，红黑各 16 枚。规则：
- 单击翻开自己的暗棋（翻棋动作 isReveal=true，fromRow==toRow 且 fromCol==toCol）。
- 已翻开的明棋可移动/吃子；吃子按等级：将/帅 > 士 > 相/象 > 马 > 车 > 炮 > 兵/卒（兵/卒可以吃将/帅，将/帅不能吃兵/卒）。
- 炮需要隔一个棋子吃子。
你现在执{red_side}。
输入会给你棋盘 board 和全部合法走法 legalMoves。
你必须且只能从 legalMoves 中选择一步，优先吃子、优先翻开关键暗棋、保持局势主动。
严格输出纯JSON：{{"fromRow":数字,"fromCol":数字,"toRow":数字,"toCol":数字,"isReveal":true或false}}"""
        return f"""你是中国象棋特级大师。棋盘坐标规则：row 0-9 从上到下，col 0-8 从左到右。
红方棋子：帅、士、相、马、车、炮、兵；黑方棋子：将、士、象、马、车、炮、卒。
你现在执{red_side}。
输入会给你完整棋局和全部合法走法列表 legalMoves。
你必须且只能从 legalMoves 里面选择一步棋。
优先选择吃子、将军、进攻性走法，注意防守。
严格输出纯JSON，不要任何其他文字、解释或markdown标记。
输出格式：{{"fromRow":数字,"fromCol":数字,"toRow":数字,"toCol":数字}}"""
    elif game_type == "gomoku":
        side_name = "黑方" if side == "black" else "白方"
        return f"""你是五子棋世界冠军。棋盘 15x15，row 和 col 都是 0-14。
黑白轮流落子，先在横、竖、斜方向连成五子者胜。
你现在执{side_name}。
输入会给你当前棋盘 board（二维数组，null为空，'black'/'white'为棋子）和合法落点 legalMoves。
你必须且只能从 legalMoves 里面选择一个落子点。
策略：优先活四、冲四、活三；防守对手的活四和活三；占据中心和关键连接点。
严格输出纯JSON：{{"row":数字,"col":数字}}"""
    elif game_type == "go":
        side_name = "黑方" if side == "black" else "白方"
        return f"""你是围棋职业九段。棋盘大小由 boardSize 字段给出（9/13/19）。
黑白轮流落子，没有气的棋子被提掉，禁止自杀和打劫立即回提。
你现在执{side_name}。
输入会给你当前棋盘 board 和合法落点 legalMoves。
你必须且只能从 legalMoves 里面选择一个落子点。
策略：金角银边草肚皮，先占角后占边；注意棋的死活和连接；适时打入和浅消；收官阶段精确计算。
严格输出纯JSON：{{"row":数字,"col":数字}}"""
    return "你是棋类大师。"


def call_doubao(payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """调用豆包API获取走棋决策。"""
    if not client:
        return None
    game_type = payload.get("gameType", "xiangqi")
    mode = payload.get("mode", "battle")
    side = payload.get("currentTurn", "black")
    legal_moves = payload.get("legalMoves", [])
    system_prompt = build_system_prompt(game_type, side, mode)
    user_content = (
        f"当前对局信息：\n"
        f"gameType: {game_type}\n"
        f"mode: {mode}\n"
        f"currentTurn: {side}\n"
        f"board: {json.dumps(payload.get('board', []), ensure_ascii=False)}\n"
        f"legalMoves: {json.dumps(legal_moves, ensure_ascii=False)}\n"
        f"moveHistory: {json.dumps(payload.get('moveHistory', []), ensure_ascii=False)}\n\n"
        f"请从 legalMoves 中选出一步最优棋，只输出JSON。"
    )
    try:
        resp = client.chat.completions.create(
            model=ENDPOINT_ID,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content},
            ],
            temperature=0.3,
            max_tokens=256,
            timeout=REQUEST_TIMEOUT,
        )
        llm_text = resp.choices[0].message.content.strip()
        logger.info("豆包原始输出: %s", llm_text[:200])
        move = extract_json(llm_text)
        if move:
            for key in ("fromRow", "fromCol", "toRow", "toCol", "row", "col"):
                if key in move:
                    try:
                        move[key] = int(move[key])
                    except (TypeError, ValueError):
                        pass
        return move
    except Exception as e:
        logger.error("调用豆包API失败: %s", str(e))
        return None


def is_valid_move(move: Dict[str, Any], legal_moves: List[Dict[str, Any]], game_type: str) -> bool:
    """校验走法是否存在于合法走法列表中。"""
    if not move or not legal_moves:
        return False
    try:
        if game_type == "xiangqi":
            is_rev = bool(move.get("isReveal")) or move.get("pieceType") == "reveal"
            if is_rev:
                return any(
                    (m.get("isReveal") or m.get("pieceType") == "reveal")
                    and m.get("fromRow") == move.get("fromRow")
                    and m.get("fromCol") == move.get("fromCol")
                    for m in legal_moves
                )
            return any(
                m.get("fromRow") == move["fromRow"]
                and m.get("fromCol") == move["fromCol"]
                and m.get("toRow") == move["toRow"]
                and m.get("toCol") == move["toCol"]
                for m in legal_moves
            )
        else:
            return any(
                m.get("row") == move["row"] and m.get("col") == move["col"]
                for m in legal_moves
            )
    except (KeyError, TypeError):
        return False


def enrich_move(move: Dict[str, Any], legal_moves: List[Dict[str, Any]], game_type: str, mode: str) -> Dict[str, Any]:
    """把大模型返回的走法补充上原始合法走法里的元信息（吃子、盲棋翻棋标记等）。"""
    if not move:
        return move
    if game_type == "xiangqi":
        is_rev = bool(move.get("isReveal")) or move.get("pieceType") == "reveal"
        if is_rev:
            original = next(
                (m for m in legal_moves
                 if (m.get("isReveal") or m.get("pieceType") == "reveal")
                 and m.get("fromRow") == move.get("fromRow")
                 and m.get("fromCol") == move.get("fromCol")),
                None,
            )
        else:
            original = next(
                (m for m in legal_moves
                 if m.get("fromRow") == move.get("fromRow")
                 and m.get("fromCol") == move.get("fromCol")
                 and m.get("toRow") == move.get("toRow")
                 and m.get("toCol") == move.get("toCol")),
                None,
            )
        if original:
            if original.get("isReveal") or original.get("pieceType") == "reveal":
                move["isReveal"] = True
                move["pieceType"] = "reveal"
            if original.get("assumedType"):
                move["assumedType"] = original["assumedType"]
            if original.get("captured"):
                move["captured"] = True
            if original.get("pieceType") and move.get("pieceType") != "reveal":
                move["pieceType"] = original["pieceType"]
    return move


# ===================== 路由 =====================
@app.get("/", response_class=HTMLResponse)
async def serve_index():
    """重定向到根目录引导文件 index.html，其内部相对资源路径（入口文件/shared.js、中国象棋、围棋 等）均以根目录为基准，无 ../ 引用。"""
    return RedirectResponse(url="/index.html")


@app.get("/health")
async def health():
    return {"status": "ok", "mode": "test" if TEST_MODE else "doubao", "version": "9.0.0"}


@app.post("/api/move")
async def chess_move(req: Request):
    """
    棋王网页的AI走棋接口（支持象棋正常对战、盲棋翻棋、五子棋、围棋）。
    接收棋局状态，调用豆包API（或测试模式随机），返回走棋决策。
    """
    try:
        payload = await req.json()
    except Exception:
        raise HTTPException(status_code=400, detail="无效的JSON请求体")

    game_type = payload.get("gameType", "xiangqi")
    mode = payload.get("mode", "battle")
    legal_moves = payload.get("legalMoves", [])
    turn = payload.get("currentTurn", "black")
    game_id = payload.get("gameId", "unknown")

    if not legal_moves:
        logger.warning("[%s] 合法走法列表为空，无棋可走", game_id)
        raise HTTPException(status_code=400, detail="legalMoves为空，无合法走法")

    logger.info(
        "[%s] 收到棋局 - 类型:%s 模式:%s 执子方:%s 合法走法数:%d",
        game_id, game_type, mode, turn, len(legal_moves),
    )

    # 测试模式：直接随机选
    if TEST_MODE:
        move = pick_random_move(legal_moves, game_type, mode)
        logger.info("[%s] 测试模式随机走棋: %s", game_id, move)
        return move

    # 调用豆包API
    move = call_doubao(payload)

    # 解析失败或校验失败 → 降级随机选
    if move is None:
        logger.warning("[%s] 豆包输出解析失败，降级随机走棋", game_id)
        move = pick_random_move(legal_moves, game_type, mode)
    elif not is_valid_move(move, legal_moves, game_type):
        logger.warning("[%s] 豆包返回非法走法 %s，降级随机走棋", game_id, move)
        move = pick_random_move(legal_moves, game_type, mode)
    else:
        move = enrich_move(move, legal_moves, game_type, mode)
        logger.info("[%s] 豆包走棋: %s", game_id, move)
    return move


@app.get("/{path:path}")
async def serve_static(path: str):
    """提供项目内静态资源（围棋 KataGo 页面、模型、WASM、图片等）。

    仅允许访问项目根目录（入口文件/ 的上一级）之下的文件，防止路径穿越。
    注意：此路由放在最后，作为其余路由匹配失败后的兜底静态文件服务。
    """
    root = str(PROJECT_ROOT)
    fp = (PROJECT_ROOT / path).resolve()
    if not str(fp).startswith(root + os.sep) and str(fp) != root:
        raise HTTPException(status_code=404, detail="Not found")
    if not fp.is_file():
        raise HTTPException(status_code=404, detail=f"Static file not found: {path}")
    media = _MIME.get(fp.suffix.lower()) or mimetypes.guess_type(str(fp))[0] or "application/octet-stream"
    return FileResponse(str(fp), media_type=media)


# ===================== 启动 =====================
def get_lan_ip():
    """获取本机局域网 IP，用于提示外部设备如何连接（无网络时返回 None）。"""
    import socket
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(0.5)
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except Exception:
        return None
    finally:
        if sock:
            try:
                sock.close()
            except Exception:
                pass


if __name__ == "__main__":
    import uvicorn
    logger.info("=" * 50)
    logger.info("棋王·多棋种智能对战平台 v9.0 启动中...")
    logger.info("监听地址: http://%s:%d", HOST, PORT)
    logger.info("网页地址: http://localhost:%d/", PORT)
    logger.info("走棋接口: http://localhost:%d/api/move", PORT)
    logger.info("API文档: http://localhost:%d/docs", PORT)
    lan_ip = get_lan_ip()
    if lan_ip and lan_ip != "127.0.0.1":
        logger.info("外部访问(LAN): http://%s:%d/  ← 手机/其它设备用此地址连接", lan_ip, PORT)
    logger.info("提示: 围棋 KataGo 神经网络需通过本服务器访问，请勿双击 HTML 直接打开")
    if TEST_MODE:
        logger.info("当前模式: 随机下棋测试模式（未配置API密钥）")
    else:
        logger.info("当前模式: 豆包AI模式")
    logger.info("=" * 50)
    uvicorn.run(app, host=HOST, port=PORT)
