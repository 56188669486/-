# 入口文件

后端服务与公共框架所在目录。

- `index.html` — 兼容旧入口，自动跳转到**根目录引导文件** `../index.html`（真正的入口在根目录）
- `shared.js` — 公共框架：全局配置 CONFIG、UCCI 引擎桥、音效、神之一手特效、GameBase 基类、GameLauncher 启动器、三大棋风格库
- `app.js` — 入口装配：设置面板事件、AI 对战控制、初始化
- `main.py` — FastAPI 后端（网页服务 + 豆包 AI 走棋接口 + 静态资源兜底），访问 `/` 会重定向到根目录 `index.html`
- `requirements.txt` — Python 依赖

> 真正的主菜单界面在**根目录 `index.html`（引导文件）**，它按顺序加载本目录的 `shared.js`、`app.js` 以及各棋种目录下的 `xiangqi.js` / `gomoku.js` / `go.js`。

## 运行

```bash
cd 入口文件
python main.py        # 浏览器打开 http://localhost:8000/ ，自动进入根目录引导文件
```