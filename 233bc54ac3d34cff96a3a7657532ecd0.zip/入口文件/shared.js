// 棋王 · 公共框架（配置 / 工具 / UCCI引擎桥 / 音效 / 特效 / GameBase / GameLauncher / 棋风常量）
// ============================================================
// 全局配置
// ============================================================
const CONFIG={
  opponentType:'builtin',      // builtin 内置AI / external 外部AI / human 双人对战 / aivai AI对战
  difficulty:'medium',         // easy / medium / hard / master
  engine:'wasm',               // wasm = C++ 编译的 WASM 引擎(UCCI协议) / js = 内置 JS 引擎
  playerSide:'red',            // red 先手 / black 后手
  goBoardSize:19,
  aiDelay:280,
  externalAiUrl:'http://localhost:8000/api/move',
  aivai:{
    red:{type:'builtin',url:'http://localhost:8000/api/move'},
    black:{type:'builtin',url:'http://localhost:8000/api/move'}
  },
  aivaiSpeed:1000
};
const DIFFICULTY_DEPTH={easy:2,medium:3,hard:4,master:6};
// 安全调用游戏方法，防止CurrentGame为null时报错
function safeCall(method){
  try{
    if(window.CurrentGame&&typeof window.CurrentGame[method]==='function'){
      window.CurrentGame[method]();
    }
  }catch(e){console.warn('safeCall error:',method,e);}
}
// ============================================================
// WASM 引擎 · UCCI 协议桥接层
// 通过 UCCI（中国象棋版 UCI）协议与 C++ 编译的 wasm 引擎交互：
//   JS  →  qw_ucci("position fen ...") / qw_ucci("go movetime N")
//   wasm → 输出 "bestmove b2e2" 等 UCCI 文本行
// 优先放入 Web Worker（不阻塞 UI），失败自动回退主线程直连。
// ============================================================
const UcciEngine={
  mode:null,          // 'worker' | 'main'
  worker:null,
  Module:null,
  _seq:0,
  _pending:{},
  _promise:null,
  init(){
    if(this._promise)return this._promise;
    this._promise=new Promise((resolve,reject)=>{
      if(typeof Worker!=='undefined'){
        try{
          const w=new Worker('中国象棋/qiwang_worker.js');
          this.worker=w;
          const timer=setTimeout(()=>{this.worker=null;try{w.terminate();}catch(e){}this._mainInit(resolve,reject);},4000);
          w.onmessage=(e)=>{
            const d=e.data||{};
            if(d.type==='ready'){clearTimeout(timer);this.mode='worker';resolve();}
            else if(d.type==='error'){clearTimeout(timer);this.worker=null;try{w.terminate();}catch(err){}this._mainInit(resolve,reject);}
            else if(d.type==='line'){
              const cb=this._pending[d.id];
              if(cb){delete this._pending[d.id];cb(d.out||'');}
            }
          };
          w.onerror=()=>{clearTimeout(timer);this.worker=null;this._mainInit(resolve,reject);};
          return;
        }catch(e){this.worker=null;}
      }
      this._mainInit(resolve,reject);
    });
    return this._promise;
  },
  _mainInit(resolve,reject){
    this.mode='main';
    const boot=()=>{
      if(!window.createQiwangEngine){reject(new Error('qiwang_engine.js 未定义 createQiwangEngine'));return;}
      window.createQiwangEngine().then(m=>{this.Module=m;try{m.ccall('qw_reset',null,[],[]);}catch(e){}resolve();}).catch(reject);
    };
    if(window.createQiwangEngine){boot();return;}
    const s=document.createElement('script');
    s.src='中国象棋/qiwang_engine.js';
    s.onload=boot;
    s.onerror=()=>reject(new Error('加载 qiwang_engine.js 失败（请确认 中国象棋 目录下存在该文件）'));
    document.head.appendChild(s);
  },
  async send(cmd){
    await this.init();
    if(this.mode==='worker'){
      const id=++this._seq;
      return new Promise((resolve,reject)=>{
        this._pending[id]=resolve;
        try{this.worker.postMessage({id,cmd});}
        catch(e){delete this._pending[id];reject(e);}
      });
    }
    try{
      this.Module.ccall('qw_ucci', null, ['string'], [cmd]);
      return this.Module.ccall('qw_take_output', 'string', [], []) || '';
    }catch(e){throw new Error('引擎调用失败: '+e);}
  },
  parseBestMove(out){
    const m=/bestmove\s+([a-i][0-9][a-i][0-9])/.exec(out||'');
    return m?m[1]:null;
  },
  isWasmReady(){return !!this._promise;}
};
let aivaiRunning=false;   // AI对战是否正在运行
let aivaiPaused=false;    // AI对战是否暂停
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function $(id){return document.getElementById(id);}
function setText(id,t){const el=$(id);if(el)el.textContent=t;}
function ctlLabel(c){return c==='human'?'玩家':(c==='external'?'外部AI':'内置AI');}
function opponentName(){
  const c=CONFIG.opponentType;
  if(c==='builtin')return '内置AI';
  if(c==='external')return '外部AI';
  if(c==='human')return '双人对战';
  return 'AI对战';
}
// ============================================================
// 通用：触摸事件绑定（手机端零延迟）
// ============================================================
function bindTap(el,handler){
  let startX=0,startY=0,moved=false,touchId=null;
  const onStart=(e)=>{const t=e.changedTouches[0];startX=t.clientX;startY=t.clientY;moved=false;touchId=t.identifier;};
  const onMove=(e)=>{const t=Array.from(e.changedTouches).find(x=>x.identifier===touchId);if(t&&Math.abs(t.clientX-startX)+Math.abs(t.clientY-startY)>10)moved=true;};
  const onEnd=(e)=>{const t=Array.from(e.changedTouches).find(x=>x.identifier===touchId);if(!moved&&t){e.preventDefault();handler({clientX:t.clientX,clientY:t.clientY,target:el});}};
  const onClick=(e)=>{if(!('ontouchstart' in window))handler(e);};
  el.addEventListener('touchstart',onStart,{passive:true});
  el.addEventListener('touchmove',onMove,{passive:true});
  el.addEventListener('touchend',onEnd,{passive:false});
  el.addEventListener('click',onClick);
  return function unbindTap(){
    el.removeEventListener('touchstart',onStart);
    el.removeEventListener('touchmove',onMove);
    el.removeEventListener('touchend',onEnd);
    el.removeEventListener('click',onClick);
  };
}
// ============================================================
// 音效系统：Web Audio 合成，无需外部音频文件
//   stone    落子     capture  提子     divine  神之一手(高光/胜负手)   gameover  终局
// ============================================================
const SoundFX=(function(){
  let ctx=null;
  function ensure(){
    if(!ctx){
      const AC=(typeof window!=='undefined')&&(window.AudioContext||window.webkitAudioContext);
      if(!AC)return null;
      ctx=new AC();
    }
    if(ctx.state==='suspended'){try{ctx.resume();}catch(e){}}
    return ctx;
  }
  function tone(ac,f0,f1,t0,dur,type,vol){
    if(!ac)return;
    try{
      const o=ac.createOscillator(),g=ac.createGain();
      o.type=type||'sine';
      o.frequency.setValueAtTime(Math.max(1,f0),ac.currentTime+t0);
      if(f1&&f1!==f0)o.frequency.exponentialRampToValueAtTime(Math.max(1,f1),ac.currentTime+t0+dur);
      g.gain.setValueAtTime(0.0001,ac.currentTime+t0);
      g.gain.exponentialRampToValueAtTime(vol,ac.currentTime+t0+0.012);
      g.gain.exponentialRampToValueAtTime(0.0001,ac.currentTime+t0+dur);
      o.connect(g);g.connect(ac.destination);
      o.start(ac.currentTime+t0);o.stop(ac.currentTime+t0+dur+0.05);
    }catch(e){}
  }
  function noiseBurst(ac,t0,dur,vol){
    if(!ac)return;
    try{
      const n=Math.max(1,Math.floor(ac.sampleRate*dur));
      const buf=ac.createBuffer(1,n,ac.sampleRate),d=buf.getChannelData(0);
      for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,2);
      const src=ac.createBufferSource();src.buffer=buf;
      const g=ac.createGain();g.gain.setValueAtTime(vol,ac.currentTime+t0);
      g.gain.exponentialRampToValueAtTime(0.0001,ac.currentTime+t0+dur);
      const f=ac.createBiquadFilter();f.type='lowpass';f.frequency.value=1400;
      src.connect(f);f.connect(g);g.connect(ac.destination);
      src.start(ac.currentTime+t0);
    }catch(e){}
  }
  function divine(ac){
    // 层一：厚重棋子落玉的共鸣（低频嗡鸣 + 轻微噪声，长混响似空旷古阁楼）
    tone(ac,87,87,0,2.2,'sine',0.24);
    tone(ac,174,174,0.02,1.8,'sine',0.10);
    noiseBurst(ac,0.02,0.4,0.10);
    // 层二：轻柔弦乐缓缓升起
    [261.63,329.63,392.0].forEach((f,i)=>{tone(ac,f,f,0.10+i*0.14,1.4,'triangle',0.05);});
    // 层三：钟磬 / 编钟泛音，悠长空灵
    [523.25,659.25,783.99,1046.5,1318.51].forEach((f,i)=>{tone(ac,f,f*1.002,0.24+i*0.08,1.5+i*0.12,'sine',0.06);});
    // 灵光一闪的高音点缀，慢慢淡出
    tone(ac,2093,2093,0.5,0.9,'sine',0.025);
  }
  function play(type){
    const ac=ensure();if(!ac)return;
    if(type==='stone'){
      noiseBurst(ac,0,0.05,0.35);tone(ac,190,95,0,0.06,'sine',0.22);
    }else if(type==='piece'){
      noiseBurst(ac,0,0.04,0.30);tone(ac,300,150,0,0.05,'triangle',0.18);
    }else if(type==='capture'){
      noiseBurst(ac,0,0.1,0.5);tone(ac,130,60,0,0.15,'sine',0.4);
    }else if(type==='divine'){
      divine(ac);
    }else if(type==='gameover'){
      tone(ac,196,196,0,0.5,'triangle',0.5);
      tone(ac,98,98,0.06,0.9,'sine',0.38);
    }
  }
  function playDelayed(type,delay){
    if(typeof window!=='undefined'&&typeof setTimeout==='function'){setTimeout(()=>play(type),delay||0);}
  }
  function bindGesture(){
    if(typeof document==='undefined')return;
    const h=()=>{ensure();};
    document.addEventListener('pointerdown',h,{once:true,passive:true});
    document.addEventListener('keydown',h,{once:true,passive:true});
  }
  bindGesture();
  return{play,playDelayed,ensure};
})();

// ============================================================
// 「神之一手」UI 特效：淡金色微光扩散 + 弹字（2~3秒自动消失）
// ============================================================
const DivineFX=(function(){
  function root(){
    let el=document.getElementById('divineFx');
    if(!el){
      const bc=document.getElementById('boardContainer');
      if(!bc)return null;
      el=document.createElement('div');
      el.id='divineFx';
      el.className='divine-fx';
      bc.appendChild(el);
    }
    return el;
  }
  function show(pos,reason){
    const el=root();if(!el)return;
    el.innerHTML='';
    // 全棋盘淡金色柔光
    const flash=document.createElement('div');flash.className='divine-flash';el.appendChild(flash);
    // 落子点位微光扩散
    if(pos&&typeof pos.x==='number'&&typeof pos.y==='number'){
      const glow=document.createElement('div');glow.className='divine-glow';
      glow.style.left=pos.x+'px';glow.style.top=pos.y+'px';
      el.appendChild(glow);
    }
    // 淡金色弹字
    const text=document.createElement('div');text.className='divine-text';
    text.textContent='神之一手！';
    if(reason)text.title=reason;
    el.appendChild(text);
    // 2.6 秒后自动清理
    setTimeout(()=>{if(el&&el.parentElement){el.innerHTML='';}},2600);
  }
  return{show};
})();

// ============================================================
// 游戏基类：统一处理对战模式（内置AI/外部AI/双人/AI对战）
// ============================================================
class GameBase{
  constructor(gameType,mode){
    this.gameType=gameType;
    this.mode=mode||'battle';
    this.gameOver=false;
    this.aiThinking=false;
    this.winner=null;
    this.timers=[];
    this.moveHistory=[];
    this.divineCount=0;           // 「神之一手」本局触发计数（最多2次）
    this._divineLastPly=null;     // 上次触发时的回合数，用于冷却，避免连发
    // 双方风格画像（AI vs AI 时双方各有一份）
    this.styleProfiles={red:null,black:null};
    this.canvas=null;this.ctx=null;this.cellSize=0;
    this.firstSide=null;this.secondSide=null;
    // 历史记录与吃子显示
    this.historyListEl=$('historyList');
    this.historyPanelEl=$('historyPanel');
    this.capturedBarEl=$('capturedBar');
    this.capturedRedEl=$('capturedRed');
    this.capturedBlackEl=$('capturedBlack');
  }
  aivaiKey(side){return side===this.firstSide?'red':'black';}
  humanSide(){return CONFIG.playerSide==='red'?this.firstSide:this.secondSide;}
  controllerFor(side){
    const c=CONFIG.opponentType;
    if(c==='human')return 'human';
    if(c==='aivai')return (CONFIG.aivai[this.aivaiKey(side)]||{type:'builtin'}).type;
    return side===this.humanSide()?'human':c;
  }
  sideLabel(side){return side==='red'?'红方':(side==='black'?'黑方':'白方');}
  schedule(fn,ms){const id=setTimeout(()=>{this.timers=this.timers.filter(t=>t!==id);fn();},ms);this.timers.push(id);return id;}
  clearTimers(){this.timers.forEach(t=>clearTimeout(t));this.timers=[];}
  status(msg){setText('statusMsg',msg||'');}
  setTurnUI(side){
    if(!side)return;
    const label=this.sideLabel(side);
    let text=label+'回合';
    if(this.gameOver){
      text=label+' '+(this.winner===side?'获胜':'落败');
    }else{
      const ctrl=this.controllerFor(side);
      if(ctrl==='human')text=label+'（请操作）';
      else if(this.aiThinking)text=label+'（AI 思考中…）';
      else text=label+'（等待AI）';
    }
    GameLauncher.updateTurnUI(side,text);
  }
  updateAiStatus(){
    const f=this.firstSide,s=this.secondSide;
    setText('aiNameRed',this.sideLabel(f));
    setText('aiNameBlack',this.sideLabel(s));
    setText('aiTypeRed',ctlLabel(this.controllerFor(f)));
    setText('aiTypeBlack',ctlLabel(this.controllerFor(s)));
    const fd=$('aiDotRed'),sd=$('aiDotBlack');
    fd.className='ai-status-dot '+(f==='red'?'red':(f==='white'?'white':'black'));
    sd.className='ai-status-dot '+(s==='red'?'red':(s==='white'?'white':'black'));
  }

  // ============================================================
  //  回合流转 & AI 调度
  // ============================================================

  // 统一回合流转：当前方是人类则等待操作，否则调度AI
  afterAction(){
    if(this.gameOver){this.aiThinking=false;this.draw&&this.draw();return;}
    // 【步骤1】AI对战时刷新风格面板
    if(CONFIG.opponentType==='aivai')this.refreshStylePanel();
    // 【步骤2】判断当前方控制器类型
    const side=this.currentTurn;
    const ctrl=this.controllerFor(side);
    if(ctrl==='human'){this.aiThinking=false;this.setTurnUI(side);this.draw&&this.draw();return;}
    // 【步骤3】调度AI走棋
    this.aiThinking=true;
    this.setTurnUI(side);
    // AI对战暂停检查
    if(CONFIG.opponentType==='aivai'&&(!aivaiRunning||aivaiPaused)){
      this.aiThinking=false;this.draw&&this.draw();return;
    }
    const delay=CONFIG.opponentType==='aivai'?CONFIG.aivaiSpeed:CONFIG.aiDelay;
    this.draw&&this.draw();
    this.schedule(()=>this.triggerAI(side,ctrl),delay);
  }

  // 触发AI走棋（分发到内置/外部）
  triggerAI(side,ctrl){
    if(this.gameOver){this.aiThinking=false;return;}
    if(ctrl==='external')this.callExternalAI(side);
    else this.runBuiltinAI(side);
  }

  // 外部AI调用
  async callExternalAI(side){
    const cfg=CONFIG.opponentType==='aivai'?CONFIG.aivai[this.aivaiKey(side)]:null;
    const url=cfg?cfg.url:CONFIG.externalAiUrl;
    if(!url){this.runBuiltinAI(side);return;}
    const payload=this.buildExternalPayload(side);
    const controller=new AbortController();
    const to=setTimeout(()=>controller.abort(),15000);
    try{
      const res=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:controller.signal});
      clearTimeout(to);
      if(!res.ok)throw new Error('HTTP '+res.status);
      const data=await res.json();
      const move=this.parseExternalMove(data);
      if(!this.validateExternalMove(move,side))throw new Error('非法走法');
      this.aiThinking=false;
      this.applyAIMove(side,move);
    }catch(e){
      clearTimeout(to);
      console.error('外部AI调用失败，改用内置AI:',e);
      this.aiThinking=false;
      this.status('外部AI失败，改用内置AI');
      this.runBuiltinAI(side);
    }
  }

  // ============================================================
  //  风格分析系统
  // ============================================================

  // --- 风格画像存储 ---

  // 获取某方的风格画像
  getSideStyleProfile(side){
    return this.styleProfiles?.[side]||null;
  }

  // 保存某方的风格画像
  setSideStyleProfile(side,profile){
    if(!this.styleProfiles)this.styleProfiles={red:null,black:null};
    this.styleProfiles[side]=profile;
  }

  // 将当前分析出的对手风格存入双方画像（AI vs AI 面板用）
  saveOpponentStyleProfile(oppSide){
    if(!this.styleProfile)return;
    if(!this.styleProfiles)this.styleProfiles={red:null,black:null};
    try{
      this.styleProfiles[oppSide]=JSON.parse(JSON.stringify(this.styleProfile));
    }catch(e){
      this.styleProfiles[oppSide]=Object.assign({},this.styleProfile);
    }
  }

  // --- 风格面板 UI 更新 ---

  // 刷新风格分析面板（AI对战时每步调用）
  refreshStylePanel(){
    const panel=document.getElementById('styleAnalysis');
    if(!panel)return;
    panel.classList.add('show');
    this.renderSideStyle('red',this.firstSide);
    this.renderSideStyle('black',this.secondSide);
  }

  // 渲染单方风格显示（slot 为面板左右槽位，side 为实际执子方）
  renderSideStyle(slot,side){
    const sideEl=document.getElementById(slot==='red'?'styleRed':'styleBlack');
    if(!sideEl)return;
    const lab=sideEl.querySelector('.style-side-label');
    if(lab)lab.textContent=this.sideLabel(side);
    const dims=this.getTopTwoDimensions(this.getSideStyleProfile(side));
    const s1id=slot==='red'?'s1r':'s1b';
    const s1cid=slot==='red'?'s1rc':'s1bc';
    const s2id=slot==='red'?'s2r':'s2b';
    const s2cid=slot==='red'?'s2rc':'s2bc';
    this.setStyleDim(s1id,s1cid,dims[0]);
    this.setStyleDim(s2id,s2cid,dims[1]);
  }

  // 设置单个维度显示
  setStyleDim(textId,barId,dim){
    const txt=document.getElementById(textId);
    const bar=document.getElementById(barId);
    if(txt)txt.textContent=dim?dim.name:'分析中';
    if(txt&&dim)txt.title=dim.desc||'';
    if(bar)bar.style.width=(dim?(dim.conf*100).toFixed(0):0)+'%';
  }

  // --- 风格维度提取（子类重写以显示中文名） ---

  // 从风格画像中提取置信度最高的两个维度
  getTopTwoDimensions(sp){
    if(!sp)return [null,null];
    const dims=[];
    for(const key in sp){
      const v=sp[key];
      if(v&&typeof v==='object'&&v.style&&typeof v.conf==='number'){
        dims.push({key,style:v.style,conf:v.conf,name:v.style,desc:''});
      }
    }
    dims.sort((a,b)=>b.conf-a.conf);
    return dims.slice(0,2);
  }
  // 历史记录添加（需要在子类中调用）
  addHistory(side, text) {
    const span = document.createElement('span');
    span.className = 'history-item ' + (side==='red' ? 'red-move' : 'black-move');
    span.textContent = text;
    this.historyListEl.appendChild(span);
    this.historyListEl.scrollTop = this.historyListEl.scrollHeight;
  }
  updateCapturedDisplay() {
    // 由子类实现具体逻辑
  }

  // ============================================================
  //  「神之一手」判定与表现（子类通过 winrateFor/pixelAt 提供局面评估与坐标）
  // ============================================================
  winrateFor(side){return 0.5;}           // 子类覆盖：返回 0~1 的胜率估计
  pixelAt(row,col){return null;}          // 子类覆盖：返回棋盘交叉点在 boardContainer 内的 CSS 像素坐标 {x,y}
  triggerDivine(side,pos,reason){
    if(this.divineCount>=2)return;  // 每局最多2次，稀有高光
    if(this._divineLastPly!=null && this.moveHistory.length-this._divineLastPly<6)return; // 冷却：至少间隔6手
    this.divineCount++;
    this._divineLastPly=this.moveHistory.length;
    const px=(pos&&typeof this.pixelAt==='function')?this.pixelAt(pos.row,pos.col):null;
    // 层次感：先落子碰撞声，约120ms后（碰撞声结束）再播放神之一手
    SoundFX.playDelayed('divine',120);
    this.status(this.sideLabel(side)+' 下出「神之一手」！'+(reason?' · '+reason:''));
    DivineFX.show(px,reason||'');
  }
}

// ============================================================
// 游戏启动器
// ============================================================
const GameLauncher={
  currentGame:null,
  showXiangqiSubmenu(){const sm=$('xiangqiSubmenu');sm.classList.toggle('show');const gs=$('goSubmenu');if(gs)gs.classList.remove('show');},
  showGoSubmenu(){const sm=$('goSubmenu');if(sm)sm.classList.toggle('show');$('xiangqiSubmenu').classList.remove('show');},
  openGoKataGo(){window.location.href='围棋/katago.html';},
  enterGame(game,title,modeLabel,boardCls){
    // 防御：先销毁上一个游戏实例，清理其定时器与事件监听，避免残留下棋回调导致“串棋”
    if(this.currentGame&&this.currentGame!==game){
      if(this.currentGame.clearTimers)this.currentGame.clearTimers();
      if(this.currentGame.destroy)this.currentGame.destroy();
      this.currentGame=null;
    }
    $('xiangqiSubmenu').classList.remove('show');
    $('mainMenu').classList.add('hidden');
    $('gameScreen').classList.add('active');
    $('gameTitle').textContent=title;
    $('modeTag').textContent=modeLabel;
    const bc=$('boardContainer');
    bc.className='board-container '+boardCls;
    $('btnPass').style.display='none';
    $('historyPanel').style.display='block';
    $('typeSelector').classList.remove('show');
    $('capturedBar').classList.remove('show');
    this.currentGame=game;
    window.CurrentGame=game;
    aivaiRunning=false;aivaiPaused=false;
    this.updateAivaiControls();
    game.init();
  },
  openXiangqi(mode){
    const blind=mode==='blind';
    this.enterGame(new XiangqiGame(blind?'blind':'battle'),
      blind?'象棋·盲棋':'中国象棋',
      blind?'盲棋翻棋':(opponentName()+' · 正常对战'),
      blind?'xiangqi-blind':'xiangqi');
  },
  openGomoku(){
    this.enterGame(new GomokuGame(),'五子棋',opponentName()+' · 五子棋','gomoku');
  },
  openGo(){
    this.enterGame(new GoGame(CONFIG.goBoardSize),'围棋',opponentName()+' · 围棋','go');
  },
  backToMenu(){
    if(this.currentGame){this.currentGame.clearTimers();this.currentGame.destroy&&this.currentGame.destroy();this.currentGame=null;}
    window.CurrentGame=null;
    aivaiRunning=false;aivaiPaused=false;
    $('gameScreen').classList.remove('active');
    $('mainMenu').classList.remove('hidden');
    $('xiangqiSubmenu').classList.remove('show');
    this.updateMenuInfo();
  },
  showWin(winner,msg){
    const title=$('winTitle');
    const wname=winner==='red'?'红方':(winner==='black'?'黑方':'白方');
    title.textContent=wname+'胜利';
    let cls='black';
    if(winner==='red')cls='red';
    else if(winner==='white')cls='white';
    title.className='win-title '+cls;
    $('winMsg').textContent=msg||'恭喜获胜！';
    $('winOverlay').classList.add('show');
  },
  hideWin(){$('winOverlay').classList.remove('show');},
  openSettings(){
    this.syncSettingsUI();
    $('settingsOverlay').classList.add('show');
  },
  closeSettings(){$('settingsOverlay').classList.remove('show');},
  openApiDoc(){$('apiDocOverlay').classList.add('show');},
  closeApiDoc(){$('apiDocOverlay').classList.remove('show');},
  syncSettingsUI(){
    const setOpt=(rowId,val)=>{
      document.querySelectorAll('#'+rowId+' .settings-option').forEach(b=>b.classList.toggle('active',b.dataset.value===val));
    };
    setOpt('opponentTypeRow',CONFIG.opponentType);
    setOpt('difficultyRow',CONFIG.difficulty);
    setOpt('engineRow',CONFIG.engine);
    setOpt('playerSideRow',CONFIG.playerSide);
    $('externalAiUrl').value=CONFIG.externalAiUrl;
    $('aivaiRedUrl').value=CONFIG.aivai.red.url;
    $('aivaiBlackUrl').value=CONFIG.aivai.black.url;
    setOpt('goSizeRow',String(CONFIG.goBoardSize));
    document.querySelectorAll('[data-aivai="red"]').forEach(b=>b.classList.toggle('active',b.dataset.value===CONFIG.aivai.red.type));
    document.querySelectorAll('[data-aivai="black"]').forEach(b=>b.classList.toggle('active',b.dataset.value===CONFIG.aivai.black.type));
    this.updateSettingsVisibility();
  },
  updateSettingsVisibility(){
    const type=(document.querySelector('#opponentTypeRow .settings-option.active')||{}).dataset&&document.querySelector('#opponentTypeRow .settings-option.active').dataset.value||CONFIG.opponentType;
    $('difficultyGroup').style.display=(type==='builtin'||type==='aivai')?'':'none';
    $('engineGroup').style.display=(type==='builtin'||type==='aivai')?'':'none';
    $('externalAiGroup').style.display=(type==='external')?'':'none';
    $('aivaiGroup').style.display=(type==='aivai')?'':'none';
    $('playerSideGroup').style.display=(type==='aivai'||type==='human')?'none':'';
    const redType=(document.querySelector('[data-aivai="red"].active')||{dataset:{value:'builtin'}}).dataset.value||'builtin';
    const blackType=(document.querySelector('[data-aivai="black"].active')||{dataset:{value:'builtin'}}).dataset.value||'builtin';
    $('aivaiRedUrl').style.display=(redType==='external')?'':'none';
    $('aivaiBlackUrl').style.display=(blackType==='external')?'':'none';
  },
  saveSettings(){
    const getVal=(rowId,def)=>{const el=document.querySelector('#'+rowId+' .settings-option.active');return el?el.dataset.value:def;};
    CONFIG.opponentType=getVal('opponentTypeRow',CONFIG.opponentType);
    CONFIG.difficulty=getVal('difficultyRow',CONFIG.difficulty);
    CONFIG.engine=getVal('engineRow',CONFIG.engine);
    CONFIG.playerSide=getVal('playerSideRow',CONFIG.playerSide);
    CONFIG.externalAiUrl=$('externalAiUrl').value.trim()||CONFIG.externalAiUrl;
    CONFIG.aivai.red.type=(document.querySelector('[data-aivai="red"].active')||{dataset:{value:'builtin'}}).dataset.value||'builtin';
    CONFIG.aivai.black.type=(document.querySelector('[data-aivai="black"].active')||{dataset:{value:'builtin'}}).dataset.value;
    CONFIG.aivai.red.url=$('aivaiRedUrl').value.trim()||CONFIG.aivai.red.url;
    CONFIG.aivai.black.url=$('aivaiBlackUrl').value.trim()||CONFIG.aivai.black.url;
    const gs=(document.querySelector('#goSizeRow .settings-option.active')||{dataset:{value:'19'}}).dataset.value;
    CONFIG.goBoardSize=parseInt(gs)||19;
    try{localStorage.setItem('chessMasterConfig',JSON.stringify(CONFIG));}catch(e){}
    this.closeSettings();
    this.updateMenuInfo();
  },
  updateMenuInfo(){
    let info=opponentName();
    if(CONFIG.opponentType==='builtin'){
      info+=' · '+(CONFIG.engine==='wasm'?'WASM':'JS')+' '+({easy:'简单',medium:'中等',hard:'困难',master:'大师级'})[CONFIG.difficulty];
    }else if(CONFIG.opponentType==='external'){
      info+=' · '+(CONFIG.externalAiUrl?'已配置':'未配置URL');
    }
    info+=' · 执'+(CONFIG.playerSide==='red'?'先手':'后手');
    $('menuModeInfo').textContent=info;
  },
  updateTurnUI(turn,text){
    $('turnDot').className='turn-dot '+turn;
    $('turnText').textContent=text;
  },
  updateAivaiControls(){
    const show=CONFIG.opponentType==='aivai';
    $('aivaiControls').classList.toggle('show',show);
    if(show){
      $('aivaiPlay').style.display='';
      $('aivaiPause').style.display='none';
    }
    $('btnUndo').disabled=show;
  },
  startAivai(){
    const g=this.currentGame;
    if(!g||g.gameOver)return;
    aivaiRunning=true;aivaiPaused=false;
    $('aivaiPlay').style.display='none';
    $('aivaiPause').style.display='';
    const side=g.currentTurn;
    g.aiThinking=true;
    g.setTurnUI(side);
    g.draw&&g.draw();
    g.schedule(()=>g.triggerAI(side,g.controllerFor(side)),300);
  },
  pauseAivai(){
    aivaiPaused=true;aivaiRunning=false;
    const g=this.currentGame;
    if(g){g.clearTimers();g.aiThinking=false;g.setTurnUI(g.currentTurn);g.draw&&g.draw();}
    $('aivaiPlay').style.display='';
    $('aivaiPause').style.display='none';
  },
  stopAivai(){
    aivaiRunning=false;aivaiPaused=false;
    const g=this.currentGame;
    if(g){g.clearTimers();g.restart();}
  }
};
// ============================================================
// 中国象棋（正常对战 + 盲棋翻棋）
// ============================================================
const TYPE_VALUES={'帅':10000,'将':10000,'车':900,'马':400,'炮':450,'相':200,'象':200,'士':200,'兵':100,'卒':100};
const BLIND_RANK={'帅':7,'将':7,'士':6,'相':5,'象':5,'车':4,'马':3,'炮':2,'兵':1,'卒':1};
const AI_PERSONALITIES=['aggressive','balanced','solid','tricky'];
// ============================================================
// 完整风格数据库 · 三大棋全体系
// ============================================================

// ===== 中国象棋风格体系 =====
const XIANGQI_STYLES={
  // 一、攻防倾向（核心二元）
  offense:{name:'进攻型',category:'攻防倾向',
    detect:m=>{let agg=0,total=0;m.forEach(mv=>{total++;
      const adv=(mv.side==='red'&&mv.tr<mv.fr)||(mv.side==='black'&&mv.tr>mv.fr);
      if(adv||mv.captured)agg++;});
    return total>0?agg/total:0.5;},
    threshold:0.65,
    counter:'稳固防守，诱敌深入后反击'},
  defense:{name:'防御型',category:'攻防倾向',
    detect:m=>{let def=0,total=0;m.forEach(mv=>{total++;
      const isDef=mv.piece.type==='士'||mv.piece.type==='相'||mv.piece.type==='象'||
        ((mv.side==='red'&&mv.tr>mv.fr&&mv.piece.type!=='兵')||
         (mv.side==='black'&&mv.tr<mv.fr&&mv.piece.type!=='卒'));
      if(isDef)def++;});
    return total>0?def/total:0.5;},
    threshold:0.6,
    counter:'慢慢挤压，调动子力找破绽'},
  balanced:{name:'攻守兼备型',category:'攻防倾向',
    detect:m=>{let agg=0,def=0,total=0;m.forEach(mv=>{total++;
      const adv=(mv.side==='red'&&mv.tr<mv.fr)||(mv.side==='black'&&mv.tr>mv.fr);
      const isDef=mv.piece.type==='士'||mv.piece.type==='相'||mv.piece.type==='象';
      if(adv||mv.captured)agg++;if(isDef)def++;});
    return total>0?1-Math.abs(agg-def)/total:0.5;},
    threshold:0.7,
    counter:'比拼综合实力，无明显短板可抓'},
  // 二、战术打法（降龙十八掌体系）
  sticky:{name:'粘连型',category:'战术打法',
    desc:'贴身纠缠，破坏对手棋路',
    counter:'保持棋型完整，不被带乱节奏'},
  exchange:{name:'消耗型',category:'战术打法',
    desc:'热衷兑子，残局放大优势',
    counter:'不随便兑子，保留关键进攻兵力'},
  breakthrough:{name:'突破型',category:'战术打法',
    desc:'牺牲子力换取一次突击',
    counter:'守住要害，顶住攻势后多子胜'},
  assassin:{name:'暗杀型',category:'战术打法',
    desc:'集中兵力暗算对方重要子力',
    counter:'注意保护车、马等关键棋子'},
  counterPunch:{name:'拆解型',category:'战术打法',
    desc:'见招拆招，等对方失误后反击',
    counter:'不轻易暴露战术意图，多算几步'},
  ambush:{name:'埋伏型',category:'战术打法',
    desc:'示弱诱敌深入，合围擒杀',
    counter:'不贪吃，看清陷阱再行动'},
  control:{name:'控制型',category:'战术打法',
    desc:'排兵布阵封锁棋路，不战而屈人之兵',
    counter:'寻找突破口，不惜兑子打开局面'},
  tricky:{name:'偏锋型',category:'战术打法',
    desc:'剑走偏锋，用诡奇棋路制造陌生感',
    counter:'回归基本功，不为怪招所乱'},
  steady:{name:'不变型',category:'战术打法',
    desc:'以不变应万变，走最熟的套路',
    counter:'针对其固定套路制定克制方案'},
  adaptive:{name:'应变型',category:'战术打法',
    desc:'对症下药，避长攻短',
    counter:'隐藏真实风格，让他难以针对'},
  rhythm:{name:'节奏型',category:'战术打法',
    desc:'抢最快节奏，以少步数换最大效益',
    counter:'拖慢节奏，逼他进入长考'},
  // 三、开局流派
  cannonOpening:{name:'炮类开局',category:'开局流派',
    openings:['当头炮','过宫炮','士角炮'],
    desc:'进攻性强，直接威胁对方九宫'},
  pawnOpening:{name:'兵类开局',category:'开局流派',
    openings:['仙人指路'],
    desc:'投石问路，可演变成各种阵法'},
  elephantOpening:{name:'相类开局',category:'开局流派',
    openings:['飞相局'],
    desc:'先为不可胜，阵型稳固'},
  horseOpening:{name:'马类开局',category:'开局流派',
    openings:['起马局'],
    desc:'攻守兼备，灵活多变'},
  wildOpening:{name:'冷门类开局',category:'开局流派',
    openings:['铁滑车','敢死炮','瞎眼狗'],
    desc:'主动弃子设陷阱，风险极高'},
  // 四、棋手气质（四象流派）
  taiyang:{name:'太阳派·朱雀',category:'棋手气质',
    desc:'大刀阔斧、刚猛雄奇，进攻是永恒主题',
    figures:['王天一','洪智','吕钦']},
  shaoyang:{name:'少阳派·青龙',category:'棋手气质',
    desc:'积极进取但留有收的余地，轻盈灵动',
    figures:['郑惟桐','蒋川']},
  shaoyin:{name:'少阴派·白虎',category:'棋手气质',
    desc:'老练持重，防守反击，鬼手百出',
    figures:['汪洋','黄竹风']},
  taiyin:{name:'太阴派·玄武',category:'棋手气质',
    desc:'至阴至柔，追求不败率而非胜率',
    figures:['许银川','谢靖']}
};

// ===== 五子棋风格体系 =====
const GOMOKU_STYLES={
  // 一、攻防倾向
  offense:{name:'进攻型',category:'攻防倾向',
    desc:'争先意识强烈，利用先手连接棋形',
    counter:'及时堵关键线，同时做自己的双线'},
  defense:{name:'防守型',category:'攻防倾向',
    desc:'善于防守，宁可老实也不冒险',
    counter:'做两个方向同时活三，一次只能堵一边'},
  balanced:{name:'均衡型',category:'攻防倾向',
    desc:'攻守平衡，根据局面灵活切换',
    counter:'拼中盘计算，把局面导向复杂'},
  // 二、实战风格
  counterAttack:{name:'防守反击型',category:'实战风格',
    desc:'先全力防守，等对方攻势减弱后反攻',
    counter:'保持持续压力，不中途松懈'},
  fastAttack:{name:'快攻型',category:'实战风格',
    desc:'信奉最佳防守就是攻击，棋风刚烈',
    counter:'顶住前三板，拖入中盘'},
  trapper:{name:'陷阱型',category:'实战风格',
    desc:'摆假线路引诱，暗藏真正杀线',
    counter:'不急着堵三子，先扫描所有方向'},
  random:{name:'乱下随缘型',category:'实战风格',
    desc:'没有规划，想到哪下哪',
    counter:'快速做活三活四，抢先五连'},
  // 三、开局类型
  mustWin:{name:'必胜开局',category:'开局类型',
    openings:['花月','浦月'],
    desc:'黑方必胜开局'},
  advantage:{name:'优势开局',category:'开局类型',
    desc:'黑方有利但非必胜'},
  balanced:{name:'平衡开局',category:'开局类型',
    openings:['疏星','松月','瑞星','银月'],
    desc:'双方大致平衡的开局（约20种）'},
  mustLose:{name:'必败开局',category:'开局类型',
    openings:['游星','彗星'],
    desc:'黑方必败开局'},
  // 四、阵法
  obliqueThree:{name:'斜三阵',category:'阵法',
    desc:'由浦月、流星演变，进攻以成角或半燕翼发起'},
  fourCorners:{name:'四角阵',category:'阵法',
    desc:'黑方四子呈四方形摆布'},
  plumBlossom:{name:'梅花阵',category:'阵法',
    desc:'黑方四子如梅花状'},
  swordFormation:{name:'剑阵',category:'阵法',
    desc:'黑白双方所下子成剑状'},
  swallowFormation:{name:'燕阵',category:'阵法',
    desc:'形态像展翅飞翔的燕子'},
  eightTrigrams:{name:'八卦阵',category:'阵法',
    desc:'从峡月演变，标准防守阵型'}
};

// ===== 围棋风格体系 =====
const GO_STYLES={
  // 一、战略取向
  territory:{name:'实利派·实地流',category:'战略取向',
    desc:'重视边角实地，每一步算目数',
    counter:'走厚势，用外势攻击其孤棋'},
  influence:{name:'厚势派·宇宙流',category:'战略取向',
    desc:'重视中腹外势，以四线高位构筑大模样',
    counter:'尽早打入，制造两块孤棋让其难以兼顾'},
  // 二、战斗风格
  fighting:{name:'力战派',category:'战斗风格',
    desc:'算力深厚，棋路刚猛，嗜血战斗',
    counter:'不硬碰，弃子转换，占大场'},
  kungfu:{name:'功夫型',category:'战斗风格',
    desc:'思路缜密，没有大起大落，偏重实地',
    counter:'打入其领地，制造复杂局面'},
  elegant:{name:'飘逸型',category:'战斗风格',
    desc:'才华横溢，大局观强，行云流水',
    counter:'稳扎稳打，不被他带节奏'},
  // 三、经典流派
  cosmicFlow:{name:'宇宙流',category:'经典流派',
    desc:'重视外势，四线高位，大模样作战',
    figure:'武宫正树'},
  pragmatic:{name:'务实围棋',category:'经典流派',
    desc:'重视实利，效率优先',
    figures:['小林光一','赵治勋']},
  aesthetic:{name:'美学围棋',category:'经典流派',
    desc:'追求棋型优美、高效率',
    figures:['藤泽秀行','大竹英雄']},
  zombieFlow:{name:'僵尸流',category:'经典流派',
    desc:'神出鬼没的翻盘术，劣势下逆转',
    figure:'李世石'},
  orthodox:{name:'本格派',category:'经典流派',
    desc:'走一般分寸，注重棋理',
    desc2:'旧式日本围棋'},
  powerFighting:{name:'力战派',category:'经典流派',
    desc:'攻杀凌厉，万箭齐发',
    figures:['刘昌赫','徐奉洙']},
  // 四、局面把握
  balanced:{name:'均衡型',category:'局面把握',
    desc:'任何局面都能从容把握，内外兼修'},
  combat:{name:'战斗型',category:'局面把握',
    desc:'依托计算，在复杂局面中取胜'},
  stable:{name:'平稳型',category:'局面把握',
    desc:'倚重判断，在平稳局面中取胜'}
};


// 位置价值表（红方视角，row 0=黑方底线，row 9=红方底线）
const PST={
  兵:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,10,12,14,14,12,10,10,15,18,20,22,22,20,18,15,20,22,25,28,28,25,22,20,30,35,40,45,45,40,35,30,50,55,60,65,65,60,55,50,80,85,90,95,95,90,85,80].map((v,i)=>v*(i<45?1:1.5)),
  卒:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,10,12,14,14,12,10,10,15,18,20,22,22,20,18,15,20,22,25,28,28,25,22,20,30,35,40,45,45,40,35,30,50,55,60,65,65,60,55,50,80,85,90,95,95,90,85,80].map((v,i)=>v*(i<45?1:1.5)),
  车:[180,190,195,200,200,195,190,180,185,195,200,205,205,200,195,185,190,200,205,210,210,205,200,190,195,205,210,215,215,210,205,195,200,210,215,220,220,215,210,200,200,210,215,220,220,215,210,200,195,205,210,215,215,210,205,195,190,200,205,210,210,205,200,190,185,195,200,205,205,200,195,185,180,190,195,200,200,195,190,180].map((v,i)=>v*(i<18?1.1:1)),
  马:[140,145,150,155,155,150,145,140,145,155,160,165,165,160,155,145,150,160,170,175,175,170,160,150,155,165,175,185,185,175,165,155,160,170,180,190,190,180,170,160,160,170,180,190,190,180,170,160,155,165,175,185,185,175,165,155,150,160,170,175,175,170,160,150,145,155,160,165,165,160,155,145,140,145,150,155,155,150,145,140],
  炮:[150,155,160,165,165,160,155,150,155,160,165,170,170,165,160,155,160,165,175,180,180,175,165,160,165,170,180,190,190,180,170,165,170,175,185,195,195,185,175,170,170,175,185,195,195,185,175,170,165,170,180,190,190,180,170,165,160,165,175,180,180,175,165,160,155,160,165,170,170,165,160,155,150,155,160,165,165,160,155,150],
  相:[190,195,200,200,200,195,190,195,200,205,205,205,200,195,200,205,210,210,210,205,200,200,205,210,215,210,205,200,200,205,210,215,210,205,200,200,205,210,215,210,205,200,200,205,210,210,210,205,200,195,200,205,205,205,200,195,190,195,200,200,200,195,190].map((v,i)=>v+(i<14?5:0)),
  士:[200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200,200].map((v,i)=>v+(i<21?10:0)),
  帅:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,100,105,110,115,115,110,105,100,120,125,130,135,135,130,125,120,130,135,140,145,145,140,135,130]
};
