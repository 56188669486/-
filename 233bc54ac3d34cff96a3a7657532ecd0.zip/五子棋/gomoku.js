// 棋王 · 五子棋（GomokuGame），VCT 搜索 + 内置AI
class GomokuGame extends GameBase{
  constructor(){
    super('gomoku','battle');
    this.SIZE=15;
    this.firstSide='black';this.secondSide='white';
    this.currentTurn='black';
    this.board=[];this.offset=0;
    this.aiPersonality='balanced';
    this.playerSkillTracker={gamesPlayed:0,gamesWon:0,currentStreak:0,effectiveDifficulty:0.5};
    this.gameId='gomoku_'+Date.now()+'_'+Math.floor(Math.random()*9999);
  }
  opp(side){return side==='black'?'white':'black';}
  init(){
    this.canvas=$('gameCanvas');this.ctx=this.canvas.getContext('2d');
    this.board=Array.from({length:15},()=>Array(15).fill(null));
    this.currentTurn='black';this.moveHistory=[];this.gameOver=false;this.winner=null;this.aiThinking=false;
    this.aiPersonality=AI_PERSONALITIES[Math.floor(Math.random()*AI_PERSONALITIES.length)];
    this.openingRot=Math.floor(Math.random()*4);
    this.clearTimers();
    $('historyPanel').style.display='block';
    $('capturedBar').classList.remove('show');
    this.historyListEl.innerHTML='';
    this.resize();this.bindEvents();this.updateAiStatus();
    this.draw();
    const ctrl=this.controllerFor('black');
    this.setTurnUI('black');
    this.status(ctrl==='human'?'黑子先手，请落子':'');
  }
  destroy(){this.unbindEvents();this.clearTimers();}
  resize(){
    const rect=this.canvas.parentElement.getBoundingClientRect();const dpr=window.devicePixelRatio||1;
    this.canvas.width=rect.width*dpr;this.canvas.height=rect.height*dpr;this.ctx.setTransform(dpr,0,0,dpr,0,0);
    this.cellSize=Math.min(rect.width,rect.height)/16;this.offset=this.cellSize;
  }
  bindEvents(){this._tap=(e)=>this.handleTap(e);this._unbindTap=bindTap(this.canvas,this._tap)||null;this._resize=()=>{this.resize();this.draw();};this._orientation=()=>setTimeout(()=>{this.resize();this.draw();},200);window.addEventListener('resize',this._resize);window.addEventListener('orientationchange',this._orientation);}
  unbindEvents(){if(this._unbindTap){try{this._unbindTap();}catch(e){}this._unbindTap=null;}if(this._resize)window.removeEventListener('resize',this._resize);if(this._orientation)window.removeEventListener('orientationchange',this._orientation);}
  getPos(e){const rect=this.canvas.getBoundingClientRect();const col=Math.round((e.clientX-rect.left-this.offset)/this.cellSize);const row=Math.round((e.clientY-rect.top-this.offset)/this.cellSize);return{row,col};}
  winrateFor(side){const s=this.evalBoard(side);return 1/(1+Math.exp(-s/4000));}
  pixelAt(row,col){return{x:this.offset+col*this.cellSize,y:this.offset+row*this.cellSize};}
  hasOpenFourThrough(row,col,side){
    for(const [dr,dc] of [[0,1],[1,0],[1,1],[1,-1]]){
      let count=1;
      let fwdR=row+dr,fwdC=col+dc;
      while(fwdR>=0&&fwdR<15&&fwdC>=0&&fwdC<15&&this.board[fwdR][fwdC]===side){count++;fwdR+=dr;fwdC+=dc;}
      let bwdR=row-dr,bwdC=col-dc;
      while(bwdR>=0&&bwdR<15&&bwdC>=0&&bwdC<15&&this.board[bwdR][bwdC]===side){count++;bwdR-=dr;bwdC-=dc;}
      if(count===4){
        const openFwd=(fwdR>=0&&fwdR<15&&fwdC>=0&&fwdC<15&&!this.board[fwdR][fwdC]);
        const openBwd=(bwdR>=0&&bwdR<15&&bwdC>=0&&bwdC<15&&!this.board[bwdR][bwdC]);
        if(openFwd&&openBwd)return true;
      }
    }
    return false;
  }
  handleTap(e){
    if(this.gameOver||this.aiThinking)return;
    if(this.controllerFor(this.currentTurn)!=='human')return;
    const {row,col}=this.getPos(e);
    if(row<0||row>=15||col<0||col>=15||this.board[row][col])return;
    this.commitMove(row,col,this.currentTurn);
    this.draw();
    this.afterAction();
  }
  commitMove(row,col,side){
    const before=this.winrateFor(side);
    this.board[row][col]=side;
    const wins=this.checkWin(row,col,side);
    const after=this.winrateFor(side);
    this.moveHistory.push({row,col,side});
    this.addHistory(side, `${side==='black'?'黑':'白'} (${row},${col})`);
    this.currentTurn=this.opp(side);
    SoundFX.play('stone');
    if(wins)this.triggerDivine(side,{row,col},'连珠绝杀·一锤定音');
    else if(this.hasOpenFourThrough(row,col,side))this.triggerDivine(side,{row,col},'妙手生花·挺进必胜');
    else if(after-before>=0.5)this.triggerDivine(side,{row,col},'惊天逆转·棋势升腾');
  }
  undoMove(){const last=this.moveHistory.pop();if(!last)return false;this.board[last.row][last.col]=null;this.currentTurn=last.side;if(this.historyListEl.lastChild)this.historyListEl.removeChild(this.historyListEl.lastChild);return true;}
  undo(){
    if(this.aiThinking||CONFIG.opponentType==='aivai'||this.gameOver)return;
    if(this.moveHistory.length===0)return;
    const n=CONFIG.opponentType==='human'?1:2;
    for(let i=0;i<n&&this.moveHistory.length>0;i++)this.undoMove();
    this.clearTimers();this.aiThinking=false;this.gameOver=false;this.winner=null;
    this.draw();
    const ctrl=this.controllerFor(this.currentTurn);
    if(ctrl==='human'){this.setTurnUI(this.currentTurn);}
    else{this.aiThinking=true;this.setTurnUI(this.currentTurn);this.schedule(()=>this.triggerAI(this.currentTurn,ctrl),CONFIG.aiDelay);}
  }
  restart(){
    this.clearTimers();
    this.divineCount=0;this._divineLastPly=null;  // 重置「神之一手」计数
    this.board=Array.from({length:15},()=>Array(15).fill(null));
    this.currentTurn='black';this.moveHistory=[];this.gameOver=false;this.winner=null;this.aiThinking=false;
    this.aiPersonality=AI_PERSONALITIES[Math.floor(Math.random()*AI_PERSONALITIES.length)];
    this.gameId='gomoku_'+Date.now()+'_'+Math.floor(Math.random()*9999);
    aivaiRunning=false;aivaiPaused=false;
    GameLauncher.updateAivaiControls();
    GameLauncher.hideWin();
    this.historyListEl.innerHTML='';
    this.updateAiStatus();
    this.draw();
    const ctrl=this.controllerFor('black');
    this.setTurnUI('black');
    this.status(ctrl==='human'?'黑子先手，请落子':'');
  }
  pass(){}
  afterAction(){
    const last=this.moveHistory[this.moveHistory.length-1];
    if(last&&this.checkWin(last.row,last.col,last.side)){
      this.gameOver=true;this.winner=last.side;
      this.finishWin();return;
    }
    if(this.moveHistory.length===225){
      this.gameOver=true;this.winner=null;
      this.aiThinking=false;this.clearTimers();
      GameLauncher.showWin('平局','棋盘已满，和棋');
      return;
    }
    GameBase.prototype.afterAction.call(this);
  }
  finishWin(){
    this.aiThinking=false;this.clearTimers();
    if(this.winner){
      this.updateAdaptiveDifficulty();
      let msg='五子连珠！'+this.sideLabel(this.winner)+'获胜';
      if(CONFIG.opponentType==='human')msg='双人对战 · '+this.sideLabel(this.winner)+'胜';
      else if(CONFIG.opponentType==='aivai')msg='AI对战 · '+this.sideLabel(this.winner)+'AI胜';
      GameLauncher.showWin(this.winner,msg);
    }
    this.setTurnUI(this.currentTurn);
    this.draw();
  }
  updateAdaptiveDifficulty(){
    if(CONFIG.opponentType!=='builtin'&&CONFIG.opponentType!=='external')return;
    if(!this.winner)return;
    const playerWin=this.winner===this.humanSide();
    this.playerSkillTracker.gamesPlayed++;
    if(playerWin){
      this.playerSkillTracker.gamesWon++;
      this.playerSkillTracker.currentStreak++;
      this.playerSkillTracker.effectiveDifficulty=Math.min(1.0,this.playerSkillTracker.effectiveDifficulty+0.08);
    }else{
      this.playerSkillTracker.currentStreak=0;
      this.playerSkillTracker.effectiveDifficulty=Math.max(0.2,this.playerSkillTracker.effectiveDifficulty-0.06);
    }
  }
  checkWin(row,col,side){
    const dirs=[[0,1],[1,0],[1,1],[1,-1]];
    for(const [dr,dc] of dirs){let count=1;
      for(let i=1;i<5;i++){const r=row+dr*i,c=col+dc*i;if(r<0||r>=15||c<0||c>=15||this.board[r][c]!==side)break;count++;}
      for(let i=1;i<5;i++){const r=row-dr*i,c=col-dc*i;if(r<0||r>=15||c<0||c>=15||this.board[r][c]!==side)break;count++;}
      if(count>=5)return true;
    }
    return false;
  }
  // ===== 外部AI协议 =====
  buildExternalPayload(side){
    return{
      gameId:this.gameId,
      gameType:'gomoku',
      mode:'battle',
      currentTurn:side,
      board:this.board.map(r=>r.slice()),
      legalMoves:this.getCandidates().map(c=>({row:c.row,col:c.col})),
      moveHistory:this.moveHistory
    };
  }
  parseExternalMove(data){if(!data)return null;return{row:parseInt(data.row,10),col:parseInt(data.col,10)};}
  validateExternalMove(move,side){
    if(!move)return false;
    const row=move.row,col=move.col;
    if(isNaN(row)||isNaN(col))return false;
    if(row<0||row>=15||col<0||col>=15)return false;
    if(this.board[row][col])return false;
    return this.getCandidates().some(c=>c.row===row&&c.col===col);
  }
  applyAIMove(side,move){
    this.commitMove(move.row,move.col,side);
    this.draw();this.afterAction();
  }
  runBuiltinAI(side){
    const start=performance.now();
    const move=this.findBestMove(side);
    const wait=Math.max(0,CONFIG.aiDelay-(performance.now()-start));
    this.schedule(()=>{
      if(this.gameOver){this.aiThinking=false;return;}
      this.aiThinking=false;
      if(move){this.commitMove(move.row,move.col,side);this.draw();this.afterAction();}
      else{this.gameOver=true;this.winner=this.opp(side);this.finishWin();}
    },wait);
  }
  // ===== 五子棋 · 四维度风格识别 =====
  analyzeGomokuOpponentStyle(oppSide){
    if(this.moveHistory.length<5)return;
    const oppMoves=this.moveHistory.filter(m=>m.side===oppSide);
    if(oppMoves.length<3)return;
    
    if(!this.styleProfile)this.styleProfile={
      offenseDefense:null, // 攻防倾向
      combatStyle:null,    // 实战风格
      openingType:null,    // 开局类型
      formation:null,      // 阵法
      history:[]
    };
    
    // 维度1：攻防倾向
    this.analyzeGomokuOffenseDefense(oppMoves,oppSide);
    
    // 维度2：实战风格（8步后）
    if(oppMoves.length>=8)this.analyzeGomokuCombatStyle(oppMoves,oppSide);
    
    // 维度3：开局类型（前10步）
    if(this.moveHistory.length<=12)this.analyzeGomokuOpening(oppSide);
    
    // 维度4：阵法识别（12步后）
    if(oppMoves.length>=10)this.analyzeGomokuFormation(oppSide);
    
    // 历史记录
    const snap={
      step:this.moveHistory.length,
      od:this.styleProfile.offenseDefense?.style,
      cs:this.styleProfile.combatStyle?.style
    };
    this.styleProfile.history.push(snap);
    if(this.styleProfile.history.length>10)this.styleProfile.history.shift();
    
    // 风格切换检测
    this.detectGomokuStyleShift();
    
    // 更新主风格
    this.updateGomokuPrimaryStyle();
    
    // 保存到双方画像（用于AI vs AI风格面板）
    this.saveOpponentStyleProfile(oppSide);
  }
  analyzeGomokuOffenseDefense(moves,side){
    const aiSide=this.opp(side);
    let attack=0,defense=0,total=moves.length;
    
    for(const mv of moves){
      // 进攻：发展自己棋形（3子及以上）
      //  针对已落下的棋子做棋形评估。mv 是对手已落子位置，原本即为 side，
      //  此前误写为 null 会把对手棋子从棋盘上抹掉，导致后续白子集体消失。
      const prev=this.board[mv.row][mv.col];
      this.board[mv.row][mv.col]=side;
      const info=this.maxLineInfo(mv.row,mv.col,side);
      this.board[mv.row][mv.col]=prev;
      if(info.count>=3)attack++;
      
      // 防守：堵住对方的棋（对方有2子以上）
      let oppNear=0;
      for(let dr=-2;dr<=2;dr++)for(let dc=-2;dc<=2;dc++){
        const nr=mv.row+dr,nc=mv.col+dc;
        if(nr>=0&&nr<15&&nc>=0&&nc<15&&this.board[nr][nc]===aiSide)oppNear++;
      }
      if(oppNear>=2)defense++;
    }
    
    const attRate=attack/total;
    const defRate=defense/total;
    
    let style,conf;
    if(attRate>=0.5&&defRate<0.3){style='offense';conf=0.65;}
    else if(defRate>=0.6){style='defense';conf=0.65;}
    else if(Math.abs(attRate-defRate)<0.2){style='balanced';conf=0.55;}
    else{style='balanced';conf=0.35;}
    
    const cur=this.styleProfile.offenseDefense;
    if(!cur||cur.style===style){
      this.styleProfile.offenseDefense={style,conf:Math.min(0.9,(cur?.conf||0)+0.08)};
    }else{
      cur.conf-=0.08;
      if(cur.conf<=0.3)this.styleProfile.offenseDefense={style,conf:0.4};
    }
  }
  analyzeGomokuCombatStyle(moves,side){
    const aiSide=this.opp(side);
    const recent=moves.slice(-10);
    let fastAttack=0,counter=0,trapper=0,randomPlay=0;
    const total=recent.length;
    
    for(const mv of recent){
      // 快攻型：每步都在发展进攻
      //  同样针对已落子做评估，不能把对手棋子误清为 null。
      const prev=this.board[mv.row][mv.col];
      this.board[mv.row][mv.col]=side;
      const info=this.maxLineInfo(mv.row,mv.col,side);
      this.board[mv.row][mv.col]=prev;
      if(info.count>=3)fastAttack++;
      
      // 防守反击型：先防守再反攻
      let oppNear=0;
      for(let dr=-2;dr<=2;dr++)for(let dc=-2;dc<=2;dc++){
        const nr=mv.row+dr,nc=mv.col+dc;
        if(nr>=0&&nr<15&&nc>=0&&nc<15&&this.board[nr][nc]===aiSide)oppNear++;
      }
      if(oppNear>=2&&info.count>=2)counter++;
      
      // 乱下型：远离主战场
      let allNear=0;
      for(let dr=-3;dr<=3;dr++)for(let dc=-3;dc<=3;dc++){
        const nr=mv.row+dr,nc=mv.col+dc;
        if(nr>=0&&nr<15&&nc>=0&&nc<15&&this.board[nr][nc])allNear++;
      }
      if(allNear<=2)randomPlay++;
      
      // 陷阱型：进攻防守交错
      if(oppNear>=1&&info.count>=2)trapper++;
    }
    
    const fastRate=fastAttack/total;
    const counterRate=counter/total;
    const randomRate=randomPlay/total;
    const trapRate=trapper/total;
    
    let style='balanced',score=0;
    if(randomRate>0.4){style='randomPlay';score=randomRate;}
    else if(fastRate>0.5&&counterRate<0.3){style='fastAttack';score=fastRate;}
    else if(counterRate>=0.4&&fastRate<0.4){style='counterAttack';score=counterRate;}
    else if(trapRate>0.35){style='trapper';score=trapRate;}
    
    const cur=this.styleProfile.combatStyle;
    if(!cur||cur.style===style){
      this.styleProfile.combatStyle={style,conf:Math.min(0.85,(cur?.conf||0.3)+0.07)};
    }else{
      cur.conf-=0.07;
      if(cur.conf<=0.25)this.styleProfile.combatStyle={style,conf:0.35};
    }
  }
  analyzeGomokuOpening(oppSide){
    const side=oppSide;
    const moves=this.moveHistory.filter(m=>m.side===side).slice(0,3);
    if(moves.length<2)return;
    
    // 判断开局类型：看前几步的位置关系
    let opening='balanced';
    let conf=0.5;
    
    // 计算前几步的分散程度
    const first=moves[0];
    let maxDist=0;
    for(const mv of moves){
      const dist=Math.abs(mv.row-first.row)+Math.abs(mv.col-first.col);
      maxDist=Math.max(maxDist,dist);
    }
    
    // 必胜开局特征：紧密相连，快速发展
    if(maxDist<=3&&moves.length>=2){opening='mustWin';conf=0.5;}
    // 优势开局：较近
    else if(maxDist<=5){opening='advantage';conf=0.5;}
    // 平衡开局：中等距离
    else if(maxDist<=7){opening='balanced';conf=0.55;}
    // 必败开局：非常分散
    else{opening='mustLose';conf=0.5;}
    
    this.styleProfile.openingType={style:opening,conf};
  }
  analyzeGomokuFormation(side){
    const moves=this.moveHistory.filter(m=>m.side===side);
    if(moves.length<5)return;
    
    // 简单阵法识别
    let formation=null;
    let conf=0.4;
    
    // 统计子力分布特征
    const rows=moves.map(m=>m.row);
    const cols=moves.map(m=>m.col);
    const uniqueRows=new Set(rows).size;
    const uniqueCols=new Set(cols).size;
    
    // 斜三阵：对角线分布
    let diagCount=0;
    for(let i=0;i<moves.length;i++){
      for(let j=i+1;j<moves.length;j++){
        if(Math.abs(moves[i].row-moves[j].row)===Math.abs(moves[i].col-moves[j].col)){
          diagCount++;
        }
      }
    }
    if(diagCount>=3){formation='obliqueThree';conf=0.45;}
    
    // 八卦阵/防守阵型：对称分布
    if(uniqueRows>=4&&uniqueCols>=4&&diagCount<=2){formation='eightTrigrams';conf=0.4;}
    
    if(formation){
      this.styleProfile.formation={style:formation,conf};
    }
  }
  detectGomokuStyleShift(){
    if(!this.styleProfile||this.styleProfile.history.length<6)return;
    const hist=this.styleProfile.history;
    const recent=hist.slice(-3);
    const earlier=hist.slice(0,3);
    
    const recentOD=recent.filter(h=>h.od);
    const earlierOD=earlier.filter(h=>h.od);
    
    if(recentOD.length>=2&&earlierOD.length>=2){
      const recentStyle=this.modeOfG(recentOD.map(h=>h.od));
      const earlierStyle=this.modeOfG(earlierOD.map(h=>h.od));
      if(recentStyle!==earlierStyle&&!this.styleShiftDetected){
        this.styleShiftDetected=true;
        this.styleShiftCount=(this.styleShiftCount||0)+1;
        if(this.styleProfile.combatStyle)this.styleProfile.combatStyle.conf*=0.6;
      }
    }
  }
  modeOfG(arr){
    const counts={};
    arr.forEach(x=>counts[x]=(counts[x]||0)+1);
    let best=null,bestCount=0;
    for(const k in counts){if(counts[k]>bestCount){bestCount=counts[k];best=k;}}
    return best;
  }
  updateGomokuPrimaryStyle(){
    if(!this.styleProfile)return;
    const od=this.styleProfile.offenseDefense;
    if(od&&od.conf>0.4){
      this.opponentStyle=od.style;
      this.styleConfidence=od.conf;
    }
  }
  // 五子棋风格维度中文名称
  getTopTwoDimensions(sp){
    if(!sp)return [null,null];
    const nameMap={
      offenseDefense:'攻防倾向',
      combatStyle:'实战风格',
      openingType:'开局类型',
      formation:'阵法'
    };
    const styleNames={
      offense:'进攻型',defense:'防守型',balanced:'均衡型',
      fastAttack:'快攻型',counterAttack:'防守反击',trapper:'陷阱型',randomPlay:'乱下型',
      mustWin:'必胜局',advantage:'优势局',equal:'平衡局',mustLose:'必败局',
      obliqueThree:'斜三阵',eightTrigrams:'八卦阵',vFormation:'V型阵'
    };
    const dims=[];
    for(const key in sp){
      const v=sp[key];
      if(v&&typeof v==='object'&&v.style&&typeof v.conf==='number'){
        dims.push({
          key,style:v.style,conf:v.conf,
          name:(nameMap[key]||key)+'·'+(styleNames[v.style]||v.style),
          desc:''
        });
      }
    }
    dims.sort((a,b)=>b.conf-a.conf);
    return dims.slice(0,2);
  }
  // ===== AI搜索 =====
  findBestMove(aiSide){
    const oppSide=this.opp(aiSide);
    const candidates=this.getCandidates();
    if(candidates.length===0)return null;
    if(this.moveHistory.length===0)return{row:7,col:7};
    
    // 识别对手风格（黑白双方对称触发：对手累计落子达到 4 的整数倍时分析一次）
    const oppMoveCount=this.moveHistory.filter(m=>m.side===oppSide).length;
    if(oppMoveCount>=4&&oppMoveCount%4===0){
      this.analyzeGomokuOpponentStyle(oppSide);
    }
    // 优先级1：自己能赢的话直接赢（四连变五连）
    const myFour=this.findThreat(aiSide,'openFour');
    if(myFour)return myFour;
    const myFourBlocked=this.findThreat(aiSide,'four');
    if(myFourBlocked)return myFourBlocked;
    
    // 优先级2：对方四连必须堵
    const oppFour=this.findThreat(oppSide,'openFour');
    if(oppFour){
      // 找能堵住四连的位置
      for(const c of candidates){
        this.board[c.row][c.col]=aiSide;
        if(!this.findThreat(oppSide,'openFour')&&!this.findThreat(oppSide,'four')){
          this.board[c.row][c.col]=null;return c;
        }
        this.board[c.row][c.col]=null;
      }
      // 如果堵不住，至少选一个减少威胁的位置
      return oppFour;
    }
    const oppFourBlocked=this.findThreat(oppSide,'four');
    if(oppFourBlocked){
      for(const c of candidates){
        this.board[c.row][c.col]=aiSide;
        if(!this.findThreat(oppSide,'four')){
          this.board[c.row][c.col]=null;return c;
        }
        this.board[c.row][c.col]=null;
      }
    }
    
    // 优先级3：自己活三必须走（形成双三或活四威胁）
    const myOpenThree=this.findThreat(aiSide,'openThree');
    if(myOpenThree){
      // 检查走这步后是否形成活四
      this.board[myOpenThree.row][myOpenThree.col]=aiSide;
      const hasOpenFour=this.findThreat(aiSide,'openFour');
      this.board[myOpenThree.row][myOpenThree.col]=null;
      if(hasOpenFour)return myOpenThree;
    }
    
    // 优先级4：对方活三必须堵（尤其是双活三）
    const oppOpenThrees=this.findAllThreats(oppSide,'openThree');
    if(oppOpenThrees.length>=2){
      // 双活三！必须堵，而且要找能同时减少威胁的位置
      let bestBlock=null,bestBlockScore=-Infinity;
      for(const c of candidates){
        this.board[c.row][c.col]=aiSide;
        const remaining=this.findAllThreats(oppSide,'openThree').length;
        this.board[c.row][c.col]=null;
        const score=-remaining*10000+this.evalPos(c.row,c.col,aiSide);
        if(score>bestBlockScore){bestBlockScore=score;bestBlock=c;}
      }
      if(bestBlock)return bestBlock;
    }
    if(oppOpenThrees.length===1){
      // 单个活三，优先堵住
      const threat=oppOpenThrees[0];
      // 找所有能堵住这个活三的位置
      const blockPoints=this.findBlockPoints(threat.row,threat.col,oppSide,'openThree');
      if(blockPoints.length>0){
        // 在堵点中选最优的（兼顾进攻）
        let bestBlock=null,bestScore=-Infinity;
        for(const bp of blockPoints){
          const score=this.evalPos(bp.row,bp.col,aiSide)*0.5+this.evalPos(bp.row,bp.col,oppSide)*0.5;
          if(score>bestScore){bestScore=score;bestBlock=bp;}
        }
        if(bestBlock)return bestBlock;
      }
      return threat; // 兜底：直接下在威胁点
    }
    
    // 优先级5：对方眠三也要注意（防止冲四）
    const oppThrees=this.findAllThreats(oppSide,'three');
    if(oppThrees.length>=2&&CONFIG.difficulty!=='easy'){
      // 多个眠三，考虑提前防守
      let bestBlock=null,bestBlockScore=-Infinity;
      for(const c of candidates.slice(0,12)){
        this.board[c.row][c.col]=aiSide;
        const remaining=this.findAllThreats(oppSide,'three').length;
        this.board[c.row][c.col]=null;
        const score=-remaining*500+this.evalPos(c.row,c.col,aiSide);
        if(score>bestBlockScore){bestBlockScore=score;bestBlock=c;}
      }
      if(bestBlock)return bestBlock;
    }
    
    // 正常搜索
    let best=candidates[0],bestScore=-Infinity;
    const scored=candidates.map(c=>({...c,s:this.evalPos(c.row,c.col,aiSide)+this.evalPos(c.row,c.col,oppSide)*0.9})).sort((a,b)=>b.s-a.s).slice(0,CONFIG.difficulty==='easy'?10:18);
    const depth=DIFFICULTY_DEPTH[CONFIG.difficulty];
    for(let d=1;d<=Math.min(depth,CONFIG.difficulty==='easy'?2:3);d++){
      for(const c of scored){
        this.board[c.row][c.col]=aiSide;
        const score=-this.abSearch(d-1,-Infinity,Infinity,oppSide,aiSide);
        this.board[c.row][c.col]=null;
        if(score>bestScore){bestScore=score;best=c;}
      }
    }
    if(CONFIG.difficulty==='easy'&&scored.length>1){
      const good=scored.filter(c=>c.s>=scored[Math.floor(scored.length*0.5)].s);
      if(good.length>0&&Math.random()<0.25)return good[Math.floor(Math.random()*good.length)];
    }
    return best;
  }
  abSearch(depth,alpha,beta,side,aiSide){
    if(depth<=0)return side===aiSide?this.evalBoard(aiSide):-this.evalBoard(aiSide);
    const cands=this.getCandidates().slice(0,CONFIG.difficulty==='easy'?8:12);
    if(cands.length===0)return side===aiSide?this.evalBoard(aiSide):-this.evalBoard(aiSide);
    for(const c of cands){
      this.board[c.row][c.col]=side;
      const score=-this.abSearch(depth-1,-beta,-alpha,this.opp(side),aiSide);
      this.board[c.row][c.col]=null;
      if(score>=beta)return beta;alpha=Math.max(alpha,score);
    }
    return alpha;
  }
  findThreat(side,type){
    const threats=this.findAllThreats(side,type);
    return threats.length>0?threats[0]:null;
  }
  findAllThreats(side,type){
    const threats=[];
    for(const c of this.getCandidates()){
      this.board[c.row][c.col]=side;
      const info=this.maxLineInfo(c.row,c.col,side);
      this.board[c.row][c.col]=null;
      if(type==='openFour'&&info.count>=4&&info.blocked===0)threats.push(c);
      else if(type==='four'&&info.count>=4)threats.push(c);
      else if(type==='openThree'&&info.count>=3&&info.blocked===0)threats.push(c);
      else if(type==='three'&&info.count>=3)threats.push(c);
      if(threats.length>20)break; // 避免过多
    }
    return threats;
  }
  findBlockPoints(row,col,side,type){
    // 找出能堵住指定威胁的所有点
    const points=[];
    const dirs=[[0,1],[1,0],[1,1],[1,-1]];
    // 先模拟落子找到形成威胁的方向
    this.board[row][col]=side;
    for(const [dr,dc] of dirs){
      let count=1,blocked=0;
      let nr=row+dr,nc=col+dc;
      while(nr>=0&&nr<15&&nc>=0&&nc<15&&this.board[nr][nc]===side){count++;nr+=dr;nc+=dc;}
      if(nr<0||nr>=15||nc<0||nc>=15||this.board[nr][nc])blocked++;
      let endR=nr,endC=nc; // 一端
      nr=row-dr;nc=col-dc;
      while(nr>=0&&nr<15&&nc>=0&&nc<15&&this.board[nr][nc]===side){count++;nr-=dr;nc-=dc;}
      if(nr<0||nr>=15||nc<0||nc>=15||this.board[nr][nc])blocked++;
      let startR=nr,startC=nc; // 另一端
      
      const isOpenThree=count>=3&&blocked===0;
      const isThree=count>=3;
      const isOpenFour=count>=4&&blocked===0;
      const isFour=count>=4;
      
      if((type==='openThree'&&isOpenThree)||(type==='three'&&isThree)||
         (type==='openFour'&&isOpenFour)||(type==='four'&&isFour)){
        // 两端的空位都是堵点
        if(this.isInBoard(startR,startC)&&!this.board[startR][startC]){
          points.push({row:startR,col:startC});
        }
        if(this.isInBoard(endR,endC)&&!this.board[endR][endC]){
          points.push({row:endR,col:endC});
        }
      }
    }
    this.board[row][col]=null;
    // 去重
    const set=new Set();
    return points.filter(p=>{
      const k=p.row*100+p.col;
      if(set.has(k))return false;
      set.add(k);return true;
    });
  }
  isInBoard(r,c){return r>=0&&r<15&&c>=0&&c<15;}
  maxLine(row,col,side){
    return this.maxLineInfo(row,col,side).count;
  }
  maxLineInfo(row,col,side){
    const dirs=[[0,1],[1,0],[1,1],[1,-1]];
    let maxCount=0,minBlocked=2;
    for(const [dr,dc] of dirs){
      let count=1,blocked=0;
      let nr=row+dr,nc=col+dc;
      while(nr>=0&&nr<15&&nc>=0&&nc<15&&this.board[nr][nc]===side){count++;nr+=dr;nc+=dc;}
      if(nr<0||nr>=15||nc<0||nc>=15||this.board[nr][nc])blocked++;
      nr=row-dr;nc=col-dc;
      while(nr>=0&&nr<15&&nc>=0&&nc<15&&this.board[nr][nc]===side){count++;nr-=dr;nc-=dc;}
      if(nr<0||nr>=15||nc<0||nc>=15||this.board[nr][nc])blocked++;
      if(count>maxCount){maxCount=count;minBlocked=blocked;}
      else if(count===maxCount&&blocked<minBlocked){minBlocked=blocked;}
    }
    return{count:maxCount,blocked:minBlocked};
  }
  getCandidates(){
    if(this.moveHistory.length===0)return[{row:7,col:7}];
    const set=new Set(),cands=[];
    for(let r=0;r<15;r++)for(let c=0;c<15;c++){
      if(this.board[r][c]){
        for(let dr=-2;dr<=2;dr++)for(let dc=-2;dc<=2;dc++){
          const nr=r+dr,nc=c+dc;
          if(nr>=0&&nr<15&&nc>=0&&nc<15&&!this.board[nr][nc]){
            const k=nr*100+nc;
            if(!set.has(k)){set.add(k);cands.push({row:nr,col:nc});}
          }
        }
      }
    }
    return cands;
  }
  evalPos(row,col,side){this.board[row][col]=side;const s=this.evalBoard(side);this.board[row][col]=null;return s;}
  evalBoard(aiSide){
    const agg=this.aiPersonality==='aggressive';
    const def=this.aiPersonality==='solid';
    let score=0;
    const pat={five:100000,openFour:10000,four:1000,openThree:1000,three:100,openTwo:100,two:10};
    // 统计双方的各种棋形数量
    let myShapes={five:0,openFour:0,four:0,openThree:0,three:0,openTwo:0,two:0};
    let oppShapes={five:0,openFour:0,four:0,openThree:0,three:0,openTwo:0,two:0};
    const oppSide=this.opp(aiSide);
    for(let r=0;r<15;r++)for(let c=0;c<15;c++){
      const p=this.board[r][c];if(!p)continue;
      for(const [dr,dc] of [[0,1],[1,0],[1,1],[1,-1]]){
        const pr=r-dr,pc=c-dc;
        if(pr>=0&&pr<15&&pc>=0&&pc<15&&this.board[pr][pc]===p)continue;
        let count=1,blocked=0,nr=r+dr,nc=c+dc;
        while(nr>=0&&nr<15&&nc>=0&&nc<15&&this.board[nr][nc]===p){count++;nr+=dr;nc+=dc;}
        if(nr<0||nr>=15||nc<0||nc>=15||this.board[nr][nc])blocked++;
        nr=r-dr;nc=c-dc;if(nr<0||nr>=15||nc<0||nc>=15||this.board[nr][nc])blocked++;
        let v=0;let shapeKey='';
        if(count>=5){v=pat.five;shapeKey='five';}
        else if(count===4){v=blocked===0?pat.openFour:pat.four;shapeKey=blocked===0?'openFour':'four';}
        else if(count===3){v=blocked===0?pat.openThree:pat.three;shapeKey=blocked===0?'openThree':'three';}
        else if(count===2){v=blocked===0?pat.openTwo:pat.two;shapeKey=blocked===0?'openTwo':'two';}
        else {v=blocked===0?5:1;}
        if(p===aiSide){v=agg?Math.round(v*1.15):v;if(shapeKey)myShapes[shapeKey]++;}
        else{v=def?Math.round(v*1.2):v;if(shapeKey)oppShapes[shapeKey]++;}
        score+=p===aiSide?v:-v;
      }
    }
    // 根据对手风格调整评估（四维度体系）
    const sp=this.styleProfile;
    if(sp){
      // 维度1：攻防倾向应对
      const od=sp.offenseDefense;
      if(od&&od.conf>0.35){
        switch(od.style){
          case 'offense': // 进攻型 - 重点防守+双线反击
            score-=oppShapes.openThree*120*od.conf;
            score+=myShapes.openThree*60*od.conf;
            if(myShapes.openThree+myShapes.openFour>=2)score+=600*od.conf;
            break;
          case 'defense': // 防守型 - 做多活三
            score+=myShapes.openThree*90*od.conf;
            score+=myShapes.openTwo*18*od.conf;
            if(myShapes.openThree>=2)score+=900*od.conf;
            break;
          case 'balanced': // 均衡型 - 比拼综合
            score+=myShapes.openThree*40*od.conf;
            break;
        }
      }
      
      // 维度2：实战风格应对
      const cs=sp.combatStyle;
      if(cs&&cs.conf>0.35){
        switch(cs.style){
          case 'fastAttack': // 快攻型 - 顶住前三板
            score-=oppShapes.openThree*80*cs.conf;
            score-=oppShapes.four*60*cs.conf;
            break;
          case 'counterAttack': // 防守反击型 - 持续施压
            score+=myShapes.openThree*50*cs.conf;
            score+=myShapes.three*20*cs.conf;
            break;
          case 'trapper': // 陷阱型 - 警惕暗线
            score-=oppShapes.openTwo*25*cs.conf;
            score-=oppShapes.two*8*cs.conf;
            score+=myShapes.openThree*70*cs.conf;
            break;
          case 'randomPlay': // 乱下型 - 快速进攻
            score+=myShapes.openThree*120*cs.conf;
            score+=myShapes.openFour*250*cs.conf;
            if(myShapes.openThree+myShapes.three>=3)score+=400*cs.conf;
            break;
        }
      }
      
      // 维度3：开局类型应对
      const ot=sp.openingType;
      if(ot&&ot.conf>0.4){
        switch(ot.style){
          case 'mustWin': // 必胜开局 - 加强防守
            score-=oppShapes.openThree*50*ot.conf;
            break;
          case 'advantage': // 优势开局 - 稳健应对
            score-=oppShapes.three*30*ot.conf;
            break;
          case 'mustLose': // 必败开局 - 加速进攻
            score+=myShapes.openThree*40*ot.conf;
            break;
        }
      }
      
      // 维度4：阵法应对
      const fm=sp.formation;
      if(fm&&fm.conf>0.35){
        switch(fm.style){
          case 'obliqueThree': // 斜三阵 - 注意斜线方向
            score-=oppShapes.openTwo*15*fm.conf;
            break;
          case 'eightTrigrams': // 八卦阵 - 防守强，做活三
            score+=myShapes.openTwo*12*fm.conf;
            break;
        }
      }
      
      // 风格切换时降低应对权重
      if(this.styleShiftDetected){
        const factor=0.5;
        // 调整各维度权重
      }
    }
    return score;
  }
  // ===== 绘制 =====
  draw(){
    const ctx=this.ctx;const cs=this.cellSize;
    ctx.clearRect(0,0,this.canvas.width,this.canvas.height);
    ctx.fillStyle='#e8d9b0';ctx.fillRect(0,0,this.canvas.width,this.canvas.height);
    ctx.strokeStyle='#5a4020';ctx.lineWidth=0.8;
    for(let i=0;i<15;i++){
      ctx.beginPath();ctx.moveTo(this.offset,this.offset+i*cs);ctx.lineTo(this.offset+14*cs,this.offset+i*cs);ctx.stroke();
      ctx.beginPath();ctx.moveTo(this.offset+i*cs,this.offset);ctx.lineTo(this.offset+i*cs,this.offset+14*cs);ctx.stroke();
    }
    ctx.fillStyle='#5a4020';
    [[3,3],[3,11],[11,3],[11,11],[7,7]].forEach(([r,c])=>{ctx.beginPath();ctx.arc(this.offset+c*cs,this.offset+r*cs,cs*0.1,0,Math.PI*2);ctx.fill();});
    if(this.moveHistory.length>0){
      const last=this.moveHistory[this.moveHistory.length-1];
      ctx.strokeStyle='#c8342c';ctx.lineWidth=2;
      ctx.strokeRect(this.offset+last.col*cs-cs*0.22,this.offset+last.row*cs-cs*0.22,cs*0.44,cs*0.44);
    }
    for(let r=0;r<15;r++)for(let c=0;c<15;c++){
      const p=this.board[r][c];if(!p)continue;
      const x=this.offset+c*cs,y=this.offset+r*cs,rad=cs*0.4;
      const grad=ctx.createRadialGradient(x-rad*0.3,y-rad*0.3,rad*0.1,x,y,rad);
      if(p==='black'){grad.addColorStop(0,'#555');grad.addColorStop(1,'#111');}
      else{grad.addColorStop(0,'#fff');grad.addColorStop(1,'#d0d0d0');}
      ctx.beginPath();ctx.arc(x,y,rad,0,Math.PI*2);ctx.fillStyle=grad;ctx.fill();
      ctx.strokeStyle=p==='black'?'#000':'#999';ctx.lineWidth=0.5;ctx.stroke();
    }
  }
}
