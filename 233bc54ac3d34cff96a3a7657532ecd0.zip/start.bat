@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo =============================
echo   棋王启动中... 本机访问: http://localhost:8000/
echo   手机/其它设备连同一局域网，用启动日志里的 LAN 地址即可连接
echo   围棋 KataGo 神经网络必须通过本服务器访问，请勿双击 HTML 直接打开
echo =============================
python 入口文件\main.py
if errorlevel 1 (
  echo.
  echo 启动失败：请确认已安装 Python 3，并执行过: pip install -r 入口文件\requirements.txt
)
pause
