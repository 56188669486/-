# 棋王 v10 · 多棋种智能对战平台

一个同时支持 **中国象棋、五子棋、围棋** 三类棋的网页对弈平台。本版在原有「内置 AI + 豆包大模型外部 AI」基础之上，新增了从在线围棋站移植而来的 **KataGo 本地神经网络围棋 AI**（在浏览器里直接运行，无需联网）。

## 目录结构

```
棋王-v10/
├── index.html           # ★ 引导文件（根目录入口，加载全部棋种与公共框架）
├── start.sh             # 一键启动（Linux / macOS）
├── start.bat            # 一键启动（Windows）
├── 入口文件/            # 后端服务 + 公共框架
│   ├── index.html       # 兼容旧入口（自动跳转到根目录引导文件）
│   ├── shared.js        # 公共框架（配置/工具/UCCI引擎桥/音效/特效/启动器/风格库）
│   ├── app.js           # 入口装配（设置面板事件、AI对战控制、初始化）
│   ├── main.py          # FastAPI 后端（网页服务 + 豆包AI走棋接口 + 静态资源）
│   └── requirements.txt # Python 依赖
├── 中国象棋/            # 象棋（正常对战 + 盲棋翻棋）及其 WASM 引擎
│   ├── xiangqi.js       # 象棋游戏逻辑
│   ├── qiwang_engine.js # C++ 编译的 WASM 引擎（SINGLE_FILE）
│   └── qiwang_worker.js # 在 Web Worker 中通过 UCCI 协议驱动引擎
├── 五子棋/
│   └── gomoku.js        # 五子棋游戏逻辑（VCT 搜索）
└── 围棋/
    ├── go.js            # 经典围棋（内置启发式 AI）
    ├── katago.html      # ★ 围棋 · KataGo 本地神经网络 AI 独立页面
    ├── katago_worker.js # KataGo 引擎 worker（内置 TensorFlow.js）
    ├── models/          # KataGo 神经网络权重 g170-b6c96（约 3.7MB）
    └── tfjs/            # TensorFlow.js 的 WASM 后端
```

## 启动方法

> ⚠️ **必须通过本地服务器访问**，双击打开 `index.html` 会因浏览器安全策略无法加载 KataGo 模型与 WASM（此时围棋棋盘会画不出来）。本项目已做容错：即便如此，围棋棋盘仍会显示并可进行双人模式，但要用 KataGo AI 必须走服务器。

### 方式一：一键启动（推荐）

- **Windows**：双击 `start.bat`
- **Linux / macOS**：终端执行 `bash start.sh`

脚本会自动安装依赖并启动服务器，启动日志会打印本机访问地址和局域网 LAN 地址。

### 方式二：手动启动

```bash
cd 入口文件
pip install -r requirements.txt   # fastapi / uvicorn / openai
python main.py
```

然后浏览器打开 <http://localhost:8000/> ，会自动重定向到根目录引导文件 `index.html`（主菜单）。

### 外部连接（手机 / 其它设备）

服务器默认监听 `0.0.0.0:8000`，即**同一局域网内的其它设备可直接连接**。启动日志会显示一行：

```
外部访问(LAN): http://192.168.x.x:8000/  ← 手机/其它设备用此地址连接
```

用手机浏览器打开该地址即可对弈（围棋 KataGo 神经网络在手机浏览器本地运行）。

> 说明：根目录 `index.html` 是统一「引导文件」，其 `<script src>` 全部使用以根目录为基准的相对路径（如 `中国象棋/xiangqi.js`），不含 `../`，可兼容对「上跳目录引用」校验较严的托管/检查平台。

## 三种围棋 AI

| 方式 | 说明 |
|------|------|
| 内置 AI（go.js） | 网页自带启发式搜索，无需联网、零依赖 |
| KataGo 本地 AI（katago.html） | 真正的围棋神经网络（g170-b6c96），含 **提示 / 形势 / 领地 / 吃子 / 悔棋 / 重开 / 停一手**，棋力明显更强 |
| 外部 AI（豆包） | 由 `main.py` 的 `/api/move` 接口中转到大模型 |

## 对手模式（设置面板）

- **内置 AI**：本地引擎/启发式搜索
- **外部 AI**：调用你配置的 Webhook（默认豆包中转服务）
- **双人对战**：两人轮流落子
- **AI 对战**：两个 AI 自动对弈，可暂停/调速

## 豆包 AI 配置（可选）

不配置时进入「随机下棋」测试模式。配置环境变量即可启用大模型走棋：

```bash
export DOUBAO_API_KEY="你的火山方舟密钥"
export ENDPOINT_ID="ep-2024xxxxxx-xxxxx"
python main.py
```

## 说明

- 本项目为纯前端 + 极简后端，KataGo / WASM 象棋引擎均在用户浏览器本地运行，隐私友好。
- 文本与注释中的「棋王」等内容均为用户自有项目素材，不含任何第三方版权内容。