// 棋王 · 围棋（经典 GoGame），死活/胜负判定 + 内置AI + 可接外部大模型
class GoGame extends GameBase{
  constructor(size){
    super('go','battle');
    this.SIZE=size||19;
    this.firstSide='black';this.secondSide='white';
    this.currentTurn='black';
    this.board=[];this.offset=0;
    this.captured={black:0,white:0};
    this.consecutivePasses=0;this.koPoint=null;
    this.aiPersonality='balanced';
    this.openingRot=Math.floor(Math.random()*4);this.openingLength=14;
    this.playerSkillTracker={gamesPlayed:0,gamesWon:0,currentStreak:0,effectiveDifficulty:0.5};
    this.gameId='go_'+Date.now()+'_'+Math.floor(Math.random()*9999);
  }
  opp(side){return side==='black'?'white':'black';}
  init(){
    this.canvas=$('gameCanvas');this.ctx=this.canvas.getContext('2d');
    this.board=Array.from({length:this.SIZE},()=>Array(this.SIZE).fill(null));
    this.currentTurn='black';this.moveHistory=[];this.captured={black:0,white:0};
    this.gameOver=false;this.winner=null;this.aiThinking=false;this.consecutivePasses=0;this.koPoint=null;
    this.aiPersonality=AI_PERSONALITIES[Math.floor(Math.random()*AI_PERSONALITIES.length)];
    this.clearTimers();
    $('historyPanel').style.display='block';
    $('capturedBar').classList.add('show');
    this.historyListEl.innerHTML='';
    this.updateCapturedDisplay();
    this.resize();this.bindEvents();this.updateAiStatus();
    $('btnPass').style.display='inline-block';
    this.draw();
    const ctrl=this.controllerFor('black');
    this.setTurnUI('black');
    this.status(ctrl==='human'?'黑子先手，请落子（可停一手）':'');
  }
  destroy(){this.unbindEvents();this.clearTimers();}
  resize(){
    const rect=this.canvas.parentElement.getBoundingClientRect();const dpr=window.devicePixelRatio||1;
    this.canvas.width=rect.width*dpr;this.canvas.height=rect.height*dpr;this.ctx.setTransform(dpr,0,0,dpr,0,0);
    this.cellSize=Math.min(rect.width,rect.height)/(this.SIZE+1);this.offset=this.cellSize;
  }
  bindEvents(){this._tap=(e)=>this.handleTap(e);this._unbindTap=bindTap(this.canvas,this._tap)||null;this._resize=()=>{this.resize();this.draw();};this._orientation=()=>setTimeout(()=>{this.resize();this.draw();},200);window.addEventListener('resize',this._resize);window.addEventListener('orientationchange',this._orientation);}
  unbindEvents(){if(this._unbindTap){try{this._unbindTap();}catch(e){}this._unbindTap=null;}if(this._resize)window.removeEventListener('resize',this._resize);if(this._orientation)window.removeEventListener('orientationchange',this._orientation);}
  getPos(e){const rect=this.canvas.getBoundingClientRect();const col=Math.round((e.clientX-rect.left-this.offset)/this.cellSize);const row=Math.round((e.clientY-rect.top-this.offset)/this.cellSize);return{row,col};}
  winrateFor(side){
    const sc=this.countScore();const komi=6.5;
    const black=sc.black,white=sc.white+komi;
    const diff=side==='black'?black-white:white-black;
    return 1/(1+Math.exp(-diff/8));
  }
  pixelAt(row,col){return{x:this.offset+col*this.cellSize,y:this.offset+row*this.cellSize};}
  hasAtariFriendlyGroup(row,col,side){
    let rescued=false;
    this.neighbors(row,col).forEach(([nr,nc])=>{
      if(this.board[nr][nc]===side){
        const g=this.getGroup(nr,nc);
        if(g.length>=3&&this.liberties(g).length===1)rescued=true;
      }
    });
    return rescued;
  }
  handleTap(e){
    if(this.gameOver||this.aiThinking)return;
    if(this.controllerFor(this.currentTurn)!=='human')return;
    const {row,col}=this.getPos(e);
    if(row<0||row>=this.SIZE||col<0||col>=this.SIZE||this.board[row][col])return;
    if(this.koPoint&&this.koPoint.row===row&&this.koPoint.col===col)return;
    if(!this.tryMove(row,col,this.currentTurn)){this.status('禁入点/打劫，请换一处落子');return;}
    this.draw();this.afterAction();
  }
  neighbors(row,col){const n=[];if(row>0)n.push([row-1,col]);if(row<this.SIZE-1)n.push([row+1,col]);if(col>0)n.push([row,col-1]);if(col<this.SIZE-1)n.push([row,col+1]);return n;}
  getGroup(row,col){
    const side=this.board[row][col];if(!side)return[];
    const group=[],visited=new Set(),stack=[[row,col]];
    while(stack.length>0){
      const [r,c]=stack.pop();const k=r*100+c;
      if(visited.has(k))continue;
      visited.add(k);
      if(this.board[r][c]!==side)continue;
      group.push([r,c]);
      this.neighbors(r,c).forEach(([nr,nc])=>{if(!visited.has(nr*100+nc))stack.push([nr,nc]);});
    }
    return group;
  }
  liberties(group){
    const libs=new Set();
    for(const [r,c] of group){this.neighbors(r,c).forEach(([nr,nc])=>{if(!this.board[nr][nc])libs.add(nr*100+nc);});}
    return[...libs].map(k=>[Math.floor(k/100),k%100]);
  }
  tryMove(row,col,side){
    const beforeWin=this.winrateFor(side);
    const rescueBefore=this.hasAtariFriendlyGroup(row,col,side);
    this.board[row][col]=side;
    const opp=this.opp(side);
    let captured=[];
    this.neighbors(row,col).forEach(([nr,nc])=>{
      if(this.board[nr][nc]===opp){
        const g=this.getGroup(nr,nc);
        if(this.liberties(g).length===0){captured=captured.concat(g);g.forEach(([gr,gc])=>this.board[gr][gc]=null);}
      }
    });
    const myGroup=this.getGroup(row,col);
    if(this.liberties(myGroup).length===0){
      this.board[row][col]=null;
      captured.forEach(([cr,cc])=>this.board[cr][cc]=opp);
      return false;
    }
    if(captured.length===1&&myGroup.length===1&&this.liberties(myGroup).length===1){this.koPoint={row:captured[0][0],col:captured[0][1]};}
    else{this.koPoint=null;}
    this.captured[side]+=captured.length;
    this.moveHistory.push({row,col,side,captured:captured.map(([r,c])=>({row:r,col:c,side:opp}))});
    this.addHistory(side, `${side==='black'?'黑':'白'} (${row},${col})${captured.length?' 提'+captured.length+'子':''}`);
    this.currentTurn=opp;this.consecutivePasses=0;
    this.updateCapturedDisplay();
    // 音效：先落子/提子（碰撞声），再按妙手判定延迟触发神之一手
    SoundFX.play('stone');
    if(captured.length>0)SoundFX.play('capture');
    const afterWin=this.winrateFor(side);
    if(captured.length>=4)this.triggerDivine(side,{row,col},'一子点杀大块·净杀');
    else if(rescueBefore)this.triggerDivine(side,{row,col},'起死回生·净活大块');
    else if(afterWin-beforeWin>=0.30)this.triggerDivine(side,{row,col},'逆转乾坤·妙到毫巅');
    return true;
  }
  pass(){
    if(this.gameOver||this.aiThinking)return;
    if(this.controllerFor(this.currentTurn)!=='human')return;
    this.moveHistory.push({pass:true,side:this.currentTurn});
    this.addHistory(this.currentTurn, `${this.currentTurn==='black'?'黑':'白'} 停一手`);
    this.currentTurn=this.opp(this.currentTurn);
    this.consecutivePasses++;this.koPoint=null;
    this.draw();this.afterAction();
  }
  undoMove(){
    const last=this.moveHistory.pop();
    if(!last)return false;
    if(last.pass){this.currentTurn=last.side;this.consecutivePasses=Math.max(0,this.consecutivePasses-1);}
    else{
      this.board[last.row][last.col]=null;
      last.captured.forEach(c=>{this.board[c.row][c.col]=c.side;this.captured[last.side]--;});
      this.currentTurn=last.side;
    }
    if(this.historyListEl.lastChild)this.historyListEl.removeChild(this.historyListEl.lastChild);
    this.updateCapturedDisplay();
    return true;
  }
  undo(){
    if(this.aiThinking||CONFIG.opponentType==='aivai'||this.gameOver)return;
    if(this.moveHistory.length===0)return;
    const n=CONFIG.opponentType==='human'?1:2;
    for(let i=0;i<n&&this.moveHistory.length>0;i++)this.undoMove();
    this.clearTimers();this.aiThinking=false;this.gameOver=false;this.winner=null;this.koPoint=null;
    this.draw();
    const ctrl=this.controllerFor(this.currentTurn);
    if(ctrl==='human'){this.setTurnUI(this.currentTurn);}
    else{this.aiThinking=true;this.setTurnUI(this.currentTurn);this.schedule(()=>this.triggerAI(this.currentTurn,ctrl),CONFIG.aiDelay);}
  }
  restart(){
    this.clearTimers();
    this.divineCount=0;this._divineLastPly=null;  // 重置「神之一手」计数
    this.board=Array.from({length:this.SIZE},()=>Array(this.SIZE).fill(null));
    this.currentTurn='black';this.moveHistory=[];this.captured={black:0,white:0};
    this.gameOver=false;this.winner=null;this.aiThinking=false;this.consecutivePasses=0;this.koPoint=null;
    this.aiPersonality=AI_PERSONALITIES[Math.floor(Math.random()*AI_PERSONALITIES.length)];
    this.openingRot=Math.floor(Math.random()*4);
    this.gameId='go_'+Date.now()+'_'+Math.floor(Math.random()*9999);
    aivaiRunning=false;aivaiPaused=false;
    GameLauncher.updateAivaiControls();
    GameLauncher.hideWin();
    $('btnPass').style.display='inline-block';
    this.historyListEl.innerHTML='';
    this.updateCapturedDisplay();
    this.updateAiStatus();
    this.draw();
    const ctrl=this.controllerFor('black');
    this.setTurnUI('black');
    this.status(ctrl==='human'?'黑子先手，请落子（可停一手）':'');
  }
  updateCapturedDisplay(){
    const render=(container,count,label)=>{
      container.innerHTML='<span class="cs-label">'+label+'</span>';
      for(let i=0;i<count;i++){
        const span=document.createElement('span');
        span.className='cs-piece';
        span.textContent='●';
        container.appendChild(span);
      }
    };
    render(this.capturedRedEl,this.captured.black,'黑方提子');
    render(this.capturedBlackEl,this.captured.white,'白方提子');
  }
  afterAction(){
    if(this.consecutivePasses>=2){this.endGame();return;}
    GameBase.prototype.afterAction.call(this);
  }
  endGame(){
    this.gameOver=true;this.aiThinking=false;this.clearTimers();
    const result=this.countScore();const komi=6.5;
    const blackScore=result.black,whiteScore=result.white+komi;
    let winner,msg;
    if(Math.abs(blackScore-whiteScore)<0.05){winner=null;}
    else{winner=blackScore>whiteScore?'black':'white';}
    msg=`黑:${blackScore.toFixed(1)} 白:${whiteScore.toFixed(1)}(含贴目${komi})`;
    if(winner)msg+=' · '+this.sideLabel(winner)+'胜'+(Math.abs(blackScore-whiteScore).toFixed(1))+'目';
    else msg+=' · 和棋';
    if(CONFIG.opponentType==='human')msg='双人对战 · '+msg;
    else if(CONFIG.opponentType==='aivai')msg='AI对战 · '+msg;
    this.winner=winner;
    if(winner)this.updateAdaptiveDifficulty();
    GameLauncher.showWin(winner?this.sideLabel(winner):'平局',msg);
    // 终局音效：一方“没办法继续下”时，奏响神之一手 + 终局重音
    SoundFX.play('divine');SoundFX.play('gameover');
    this.draw();
  }
  countScore(){
    const visited=Array.from({length:this.SIZE},()=>Array(this.SIZE).fill(false));
    let bt=0,wt=0,bs=0,ws=0;
    for(let r=0;r<this.SIZE;r++)for(let c=0;c<this.SIZE;c++){
      if(this.board[r][c]==='black')bs++;
      else if(this.board[r][c]==='white')ws++;
    }
    for(let r=0;r<this.SIZE;r++)for(let c=0;c<this.SIZE;c++){
      if(visited[r][c]||this.board[r][c])continue;
      const {territory,owner}=this.floodTerritory(r,c,visited);
      if(owner==='black')bt+=territory;else if(owner==='white')wt+=territory;
    }
    return{black:bs+bt,white:ws+wt};
  }
  floodTerritory(row,col,visited){
    const stack=[[row,col]],terr=[];let tb=false,tw=false;
    while(stack.length>0){
      const [r,c]=stack.pop();
      if(r<0||r>=this.SIZE||c<0||c>=this.SIZE)continue;
      if(visited[r][c])continue;
      if(this.board[r][c]==='black'){tb=true;continue;}
      if(this.board[r][c]==='white'){tw=true;continue;}
      visited[r][c]=true;terr.push([r,c]);
      stack.push([r-1,c],[r+1,c],[r,c-1],[r,c+1]);
    }
    let owner=null;
    if(tb&&!tw)owner='black';
    else if(tw&&!tb)owner='white';
    return{territory:terr.length,owner};
  }
  updateAdaptiveDifficulty(){
    if(CONFIG.opponentType!=='builtin'&&CONFIG.opponentType!=='external')return;
    if(!this.winner)return;
    const playerWin=this.winner===this.humanSide();
    this.playerSkillTracker.gamesPlayed++;
    if(playerWin){
      this.playerSkillTracker.gamesWon++;
      this.playerSkillTracker.currentStreak++;
      this.playerSkillTracker.effectiveDifficulty=Math.min(1.0,this.playerSkillTracker.effectiveDifficulty+0.08);
    }else{
      this.playerSkillTracker.currentStreak=0;
      this.playerSkillTracker.effectiveDifficulty=Math.max(0.2,this.playerSkillTracker.effectiveDifficulty-0.06);
    }
  }
  // ===== 外部AI协议 =====
  buildExternalPayload(side){
    return{
      gameId:this.gameId,
      gameType:'go',
      mode:'battle',
      currentTurn:side,
      boardSize:this.SIZE,
      board:this.board.map(r=>r.slice()),
      legalMoves:this.getCandidates().map(c=>({row:c.row,col:c.col})),
      moveHistory:this.moveHistory,
      captured:this.captured
    };
  }
  parseExternalMove(data){if(!data)return null;return{row:parseInt(data.row,10),col:parseInt(data.col,10)};}
  validateExternalMove(move,side){
    if(!move)return false;
    const row=move.row,col=move.col;
    if(isNaN(row)||isNaN(col))return false;
    if(row<0||row>=this.SIZE||col<0||col>=this.SIZE)return false;
    if(this.board[row][col])return false;
    if(this.koPoint&&this.koPoint.row===row&&this.koPoint.col===col)return false;
    return this.getCandidates().some(c=>c.row===row&&c.col===col);
  }
  applyAIMove(side,move){
    if(this.tryMove(move.row,move.col,side)){
      this.draw();this.afterAction();
    }else{
      this.moveHistory.push({pass:true,side});
      this.addHistory(side, `${side==='black'?'黑':'白'} 停一手（无效落子）`);
      this.currentTurn=this.opp(side);
      this.consecutivePasses++;this.koPoint=null;
      this.status('外部AI落子无效，停一手');
      this.draw();this.afterAction();
    }
  }
  runBuiltinAI(side){
    const start=performance.now();
    const move=this.findBestMove(side);
    const wait=Math.max(0,CONFIG.aiDelay-(performance.now()-start));
    this.schedule(()=>{
      if(this.gameOver){this.aiThinking=false;return;}
      this.aiThinking=false;
      if(move&&this.tryMove(move.row,move.col,side)){
        this.draw();this.afterAction();
      }else{
        this.moveHistory.push({pass:true,side});
        this.addHistory(side, `${side==='black'?'黑':'白'} 停一手`);
        this.currentTurn=this.opp(side);
        this.consecutivePasses++;this.koPoint=null;
        this.draw();this.afterAction();
      }
    },wait);
  }
  // ===== 围棋开局棋谱（金角银边草肚皮：先占角、后挂角/拆边、再中腹）=====
  inBoard(r,c){return r>=0&&r<this.SIZE&&c>=0&&c<this.SIZE;}
  lineDist(r,c){return Math.min(r,c,this.SIZE-1-r,this.SIZE-1-c);}
  openingCorners(){
    const s=this.SIZE-1;
    const a=this.SIZE>=19?3:(this.SIZE===13?3:2);
    return[[a,a],[a,s-a],[s-a,s-a],[s-a,a]];
  }
  openingBookMove(){
    const n=this.moveHistory.length;
    if(n>=this.openingLength)return null;
    const corners=this.openingCorners();
    // 阶段一：互占四角（对角星开局，带旋转变化保证“各式各样”）
    if(n<4){
      const order=[0,2,1,3];
      const [r,c]=corners[(order[n]+this.openingRot)%4];
      if(this.board[r][c])return null;
      return{row:r,col:c};
    }
    // 阶段二：挂角/拆边 —— 对己方每个靠角棋形做三~四线延伸，形成有机棋形
    const mine=this.moveHistory.filter(m=>m.side===this.currentTurn&&!m.pass);
    if(mine.length===0)return null;
    const seeds=mine.filter(m=>this.lineDist(m.row,m.col)<=3).reverse();
    const dirs=[[0,2],[0,-2],[0,3],[0,-3],[2,0],[-2,0],[3,0],[-3,0],[1,2],[1,-2],[-1,2],[-1,-2],[2,1],[2,-1],[-2,1],[-2,-1]];
    for(const s0 of seeds){
      for(const [dr,dc] of dirs){
        const r=s0.row+dr,c=s0.col+dc;
        if(!this.inBoard(r,c)||this.board[r][c])continue;
        const ld=this.lineDist(r,c);
        if(ld>=2&&ld<=4){
          if(this.koPoint&&this.koPoint.row===r&&this.koPoint.col===c)continue;
          return{row:r,col:c};
        }
      }
    }
    return null;
  }
  // ===== AI搜索 =====
  findBestMove(aiSide){
    // 开局阶段按棋谱流程下（仪式感 + 有强度的布局）
    const book=this.openingBookMove();
    if(book)return book;
    const cands=this.getCandidates();
    if(cands.length===0)return null;
    // 识别对手风格
    if(this.moveHistory.length>=10&&this.moveHistory.length%5===0){
      this.analyzeGoOpponentStyle(this.opp(aiSide));
    }
    const diff=CONFIG.difficulty;
    const scored=cands.map(c=>({...c,s:this.evalMove(c.row,c.col,aiSide)})).sort((a,b)=>b.s-a.s);
    if(diff==='easy'){const top=scored.slice(0,Math.min(5,scored.length));return top[Math.floor(Math.random()*top.length)];}
    const topN=diff==='master'?12:diff==='hard'?8:5;
    const sd=diff==='master'?2:1;
    let best=scored[0],bs=-Infinity;
    for(const c of scored.slice(0,Math.min(topN,scored.length))){
      this.board[c.row][c.col]=aiSide;
      const opp=this.opp(aiSide);let cap=[];
      this.neighbors(c.row,c.col).forEach(([nr,nc])=>{
        if(this.board[nr][nc]===opp){
          const g=this.getGroup(nr,nc);
          if(this.liberties(g).length===0){cap=cap.concat(g);g.forEach(([gr,gc])=>this.board[gr][gc]=null);}
        }
      });
      const score=-this.miniSearch(sd,-Infinity,Infinity,opp,aiSide);
      cap.forEach(([cr,cc])=>this.board[cr][cc]=opp);
      this.board[c.row][c.col]=null;
      if(score>bs){bs=score;best=c;}
    }
    return best;
  }
  miniSearch(depth,alpha,beta,side,aiSide){
    if(depth<=0)return side===aiSide?this.evalBoard(aiSide):-this.evalBoard(aiSide);
    const cands=this.getCandidates().slice(0,6);
    if(cands.length===0)return side===aiSide?this.evalBoard(aiSide):-this.evalBoard(aiSide);
    for(const c of cands){
      this.board[c.row][c.col]=side;
      const opp=this.opp(side);let cap=[];
      this.neighbors(c.row,c.col).forEach(([nr,nc])=>{
        if(this.board[nr][nc]===opp){
          const g=this.getGroup(nr,nc);
          if(this.liberties(g).length===0){cap=cap.concat(g);g.forEach(([gr,gc])=>this.board[gr][gc]=null);}
        }
      });
      const score=-this.miniSearch(depth-1,-beta,-alpha,opp,aiSide);
      cap.forEach(([cr,cc])=>this.board[cr][cc]=opp);
      this.board[c.row][c.col]=null;
      if(score>=beta)return beta;alpha=Math.max(alpha,score);
    }
    return alpha;
  }
  evalMove(row,col,side){
    let score=0;
    const opp=this.opp(side),mn=this.moveHistory.length;
    // 提子价值：拍住气紧（只剩一口气）的对手棋
    let cv=0;
    this.neighbors(row,col).forEach(([nr,nc])=>{
      if(this.board[nr][nc]===opp){
        const g=this.getGroup(nr,nc);
        if(this.liberties(g).length===1)cv+=g.length*50;
      }
    });
    score+=cv;
    // 救急：补强己方气紧的棋
    let sv=0;
    this.neighbors(row,col).forEach(([nr,nc])=>{
      if(this.board[nr][nc]===side){
        const g=this.getGroup(nr,nc);
        const l=this.liberties(g).length;
        if(l<=2)sv+=(3-l)*30;
      }
    });
    score+=sv;
    // 布局阶段（初期）：金角银边草肚皮 + 星位 + 好形拆二
    if(mn<this.SIZE*2){
      const cd=this.lineDist(row,col);
      if(cd===2)score+=24;
      else if(cd===3)score+=20;
      else if(cd===4)score+=10;
      else if(cd===0)score-=18;
      else if(cd===1)score+=4;
      if(this.SIZE===19){
        const sp=[3,9,15];let ns=0;
        for(const sr of sp)for(const sc of sp)ns=Math.max(ns,12-Math.abs(row-sr)-Math.abs(col-sc));
        score+=ns*4;
      }
      let ext=0;
      [[0,2],[0,-2],[2,0],[-2,0]].forEach(([dr,dc])=>{
        const r2=row+dr,c2=col+dc;
        if(this.inBoard(r2,c2)&&this.board[r2][c2]===side)ext+=12;
      });
      score+=Math.min(24,ext);
    }
    // 连接/接触价值（战斗时贴气更有价值）
    let inf=0;
    this.neighbors(row,col).forEach(([nr,nc])=>{
      if(this.board[nr][nc]===side)inf+=2;
      if(this.board[nr][nc]===opp)inf+=(cv>0?6:3);
    });
    score+=inf;
    // 全局大局观：到最近棋子的切比雪夫距离，越远越利于拓张（落子分散、有强度）
    let nd=9;
    for(const m of this.moveHistory){
      if(m.pass)continue;
      nd=Math.min(nd,Math.max(Math.abs(row-m.row),Math.abs(col-m.col)));
      if(nd<=1)break;
    }
    if(nd>=4)score+=nd*4;
    // 首二线贴边惩罚（提子/救急优先，其余场景避免无谓贴边，保持有强度）
    if(cv===0){
      const cd2=this.lineDist(row,col);
      if(cd2===0)score-=20;
      else if(cd2===1)score-=7;
    }
    // 进攻/打入：邻近对手且远离己方时，制造战斗强度
    let ownNear=0,oppNear=0;
    for(let dr=-2;dr<=2;dr++)for(let dc=-2;dc<=2;dc++){
      if(dr===0&&dc===0)continue;
      const nr=row+dr,nc=col+dc;
      if(!this.inBoard(nr,nc))continue;
      if(this.board[nr][nc]===side)ownNear++;
      else if(this.board[nr][nc]===opp)oppNear++;
    }
    if(oppNear>=2&&ownNear<=1)score+=oppNear*8;
    // 避免自填眼/无用落子：贴满己方气且无对手接触时减分（防止“没办法下”的颓势）
    let ownAdj=0;
    this.neighbors(row,col).forEach(([nr,nc])=>{if(this.board[nr][nc]===side)ownAdj++;});
    if(ownAdj===4)score-=40;
    else if(ownAdj===3&&oppNear===0)score-=18;
    // 自杀判定（禁入点）
    this.board[row][col]=side;
    const g=this.getGroup(row,col);
    if(this.liberties(g).length===0)score=-10000;
    this.board[row][col]=null;
    return score;
  }
  // ===== 围棋对手风格识别 =====
  // ===== 围棋 · 四维度风格识别 =====
  analyzeGoOpponentStyle(oppSide){
    if(this.moveHistory.length<6)return;
    const oppMoves=this.moveHistory.filter(m=>m.side===oppSide&&!m.pass);
    if(oppMoves.length<4)return;
    
    if(!this.styleProfile)this.styleProfile={
      strategy:null,      // 战略取向
      combat:null,        // 战斗风格
      classicSchool:null, // 经典流派
      situation:null,     // 局面把握
      history:[]
    };
    
    // 维度1：战略取向
    this.analyzeGoStrategy(oppMoves,oppSide);
    
    // 维度2：战斗风格（10步后）
    if(oppMoves.length>=10)this.analyzeGoCombat(oppMoves,oppSide);
    
    // 维度3：经典流派（15步后）
    if(oppMoves.length>=15)this.analyzeGoClassicSchool(oppMoves,oppSide);
    
    // 维度4：局面把握类型
    if(oppMoves.length>=12)this.analyzeGoSituation(oppMoves,oppSide);
    
    // 历史记录
    const snap={
      step:this.moveHistory.length,
      strat:this.styleProfile.strategy?.style,
      combat:this.styleProfile.combat?.style
    };
    this.styleProfile.history.push(snap);
    if(this.styleProfile.history.length>10)this.styleProfile.history.shift();
    
    // 风格切换检测
    this.detectGoStyleShift();
    
    // 更新主风格
    this.updateGoPrimaryStyle();
    
    // 保存到双方画像（用于AI vs AI风格面板）
    this.saveOpponentStyleProfile(oppSide);
  }
  analyzeGoStrategy(moves,side){
    let territory=0,influence=0,total=moves.length;
    const size=this.SIZE;
    
    for(const mv of moves){
      // 实地型：靠近边角，低线
      const cornerDist=Math.min(mv.row,mv.col,size-1-mv.row,size-1-mv.col);
      const edgeDist=Math.min(mv.row,mv.col,size-1-mv.row,size-1-mv.col);
      const lineHeight=Math.min(mv.row,size-1-mv.row); // 离最近边的距离
      
      if(cornerDist<=3)territory++; // 边角附近 = 实地
      
      // 厚势型：四线高位，中腹发展
      if(lineHeight>=3&&lineHeight<=5)influence++;
    }
    
    const terrRate=territory/total;
    const inflRate=influence/total;
    
    let style,conf;
    if(terrRate>inflRate*1.3&&terrRate>0.5){style='territory';conf=0.6;}
    else if(inflRate>terrRate*1.2&&inflRate>0.4){style='influence';conf=0.55;}
    else{style='balanced';conf=0.5;}
    
    const cur=this.styleProfile.strategy;
    if(!cur||cur.style===style){
      this.styleProfile.strategy={style,conf:Math.min(0.85,(cur?.conf||0)+0.06)};
    }else{
      cur.conf-=0.06;
      if(cur.conf<=0.25)this.styleProfile.strategy={style,conf:0.35};
    }
  }
  analyzeGoCombat(moves,side){
    const aiSide=this.opp(side);
    const recent=moves.slice(-12);
    let fighting=0,kungfu=0,elegant=0,total=recent.length;
    
    for(const mv of recent){
      // 力战型：每步都挨着对方棋子
      let nearOpp=0;
      for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){
        const nr=mv.row+dr,nc=mv.col+dc;
        if(nr>=0&&nr<this.SIZE&&nc>=0&&nc<this.SIZE&&this.board[nr][nc]===aiSide)nearOpp++;
      }
      if(nearOpp>=2)fighting++;
      
      // 功夫型：稳健，有自己的棋连接
      let nearOwn=0;
      for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){
        const nr=mv.row+dr,nc=mv.col+dc;
        if(nr>=0&&nr<this.SIZE&&nc>=0&&nc<this.SIZE&&this.board[nr][nc]===side)nearOwn++;
      }
      if(nearOwn>=2&&nearOpp<=1)kungfu++;
      
      // 飘逸型：大场为主，不接触
      if(nearOpp===0&&nearOwn<=1)elegant++;
    }
    
    const fightRate=fighting/total;
    const kungRate=kungfu/total;
    const elegRate=elegant/total;
    
    let style='balanced';
    if(fightRate>0.5)style='fighting';
    else if(kungRate>0.4)style='kungfu';
    else if(elegRate>0.4)style='elegant';
    
    const cur=this.styleProfile.combat;
    if(!cur||cur.style===style){
      this.styleProfile.combat={style,conf:Math.min(0.8,(cur?.conf||0.3)+0.05)};
    }else{
      cur.conf-=0.05;
      if(cur.conf<=0.25)this.styleProfile.combat={style,conf:0.3};
    }
  }
  analyzeGoClassicSchool(moves,side){
    const size=this.SIZE;
    let cosmic=0,pragmatic=0,total=moves.length;
    
    for(const mv of moves){
      const lineHeight=Math.min(mv.row,size-1-mv.row);
      // 宇宙流：四线高位
      if(lineHeight===3||lineHeight===4)cosmic++;
      // 务实流：三线以下
      if(lineHeight<=2)pragmatic++;
    }
    
    const cosmicRate=cosmic/total;
    const pragRate=pragmatic/total;
    
    let school=null,conf=0.35;
    if(cosmicRate>0.4){school='cosmicFlow';conf=0.45;}
    else if(pragRate>0.5){school='pragmatic';conf=0.45;}
    
    if(school){
      this.styleProfile.classicSchool={style:school,conf};
    }
  }
  analyzeGoSituation(moves,side){
    const aiSide=this.opp(side);
    const recent=moves.slice(-10);
    let combatMoves=0,stableMoves=0,total=recent.length;
    
    for(const mv of recent){
      let nearOpp=0;
      for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){
        const nr=mv.row+dr,nc=mv.col+dc;
        if(nr>=0&&nr<this.SIZE&&nc>=0&&nc<this.SIZE&&this.board[nr][nc]===aiSide)nearOpp++;
      }
      if(nearOpp>=1)combatMoves++;
      
      let nearOwn=0;
      for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){
        const nr=mv.row+dr,nc=mv.col+dc;
        if(nr>=0&&nr<this.SIZE&&nc>=0&&nc<this.SIZE&&this.board[nr][nc]===side)nearOwn++;
      }
      if(nearOwn>=2&&nearOpp===0)stableMoves++;
    }
    
    const combatRate=combatMoves/total;
    const stableRate=stableMoves/total;
    
    let sit='balanced';
    if(combatRate>0.5)sit='combat';
    else if(stableRate>0.4)sit='stable';
    
    this.styleProfile.situation={style:sit,conf:0.45};
  }
  detectGoStyleShift(){
    if(!this.styleProfile||this.styleProfile.history.length<6)return;
    const hist=this.styleProfile.history;
    const recent=hist.slice(-3);
    const earlier=hist.slice(0,3);
    
    const recentS=recent.filter(h=>h.strat).map(h=>h.strat);
    const earlierS=earlier.filter(h=>h.strat).map(h=>h.strat);
    
    if(recentS.length>=2&&earlierS.length>=2){
      const rMode=this.modeOfGo(recentS);
      const eMode=this.modeOfGo(earlierS);
      if(rMode!==eMode&&!this.styleShiftDetected){
        this.styleShiftDetected=true;
        this.styleShiftCount=(this.styleShiftCount||0)+1;
        if(this.styleProfile.combat)this.styleProfile.combat.conf*=0.6;
      }
    }
  }
  modeOfGo(arr){
    const counts={};
    arr.forEach(x=>counts[x]=(counts[x]||0)+1);
    let best=null,bestCount=0;
    for(const k in counts){if(counts[k]>bestCount){bestCount=counts[k];best=k;}}
    return best;
  }
  updateGoPrimaryStyle(){
    if(!this.styleProfile)return;
    const st=this.styleProfile.strategy;
    if(st&&st.conf>0.4){
      this.opponentStyle=st.style;
      this.styleConfidence=st.conf;
    }
  }
  // 围棋风格维度中文名称
  getTopTwoDimensions(sp){
    if(!sp)return [null,null];
    const nameMap={
      strategy:'战略取向',
      combat:'战斗风格',
      classicSchool:'经典流派',
      situation:'局面把握'
    };
    const styleNames={
      territory:'实利派',influence:'厚势派',balanced:'均衡型',
      fighting:'力战派',kungfu:'功夫型',elegant:'飘逸型',
      cosmicFlow:'宇宙流',pragmatic:'务实流',
      combat:'战斗型',stable:'平稳型'
    };
    const dims=[];
    for(const key in sp){
      const v=sp[key];
      if(v&&typeof v==='object'&&v.style&&typeof v.conf==='number'){
        dims.push({
          key,style:v.style,conf:v.conf,
          name:(nameMap[key]||key)+'·'+(styleNames[v.style]||v.style),
          desc:''
        });
      }
    }
    dims.sort((a,b)=>b.conf-a.conf);
    return dims.slice(0,2);
  }
  evalBoard(aiSide){
    // 以「实地＋空」做局面评估（含贴目），让 AI 看起来有围空、有强度，而不是乱摆子
    const res=this.countScore(),komi=6.5;
    let score=(res.white+komi-res.black)*3+(this.captured.white-this.captured.black)*6;
    if(this.aiPersonality==='aggressive')score+=(this.captured[aiSide]-this.captured[this.opp(aiSide)])*3;
    // 对手风格应对（四维度体系）
    const sp=this.styleProfile;
    if(sp){
      // 维度1：战略取向应对
      const st=sp.strategy;
      if(st&&st.conf>0.35){
        switch(st.style){
          case 'territory': // 实利派 - 走厚势攻击孤棋
            score+=this.evaluateMoyo(aiSide)*st.conf*0.8;
            break;
          case 'influence': // 厚势派 - 尽早打入
            score+=this.evaluateInvasion(aiSide)*st.conf;
            break;
          case 'balanced': // 均衡型
            score+=this.evaluateConnection(aiSide)*st.conf*0.3;
            break;
        }
      }
      
      // 维度2：战斗风格应对
      const cb=sp.combat;
      if(cb&&cb.conf>0.35){
        switch(cb.style){
          case 'fighting': // 力战派 - 不硬碰，弃子转换
            score-=5*cb.conf;
            score+=this.evaluateMoyo(aiSide)*cb.conf*0.5;
            break;
          case 'kungfu': // 功夫型 - 打入制造复杂
            score+=this.evaluateInvasion(aiSide)*cb.conf*0.8;
            break;
          case 'elegant': // 飘逸型 - 稳扎稳打
            score+=this.evaluateConnection(aiSide)*cb.conf*0.6;
            break;
        }
      }
      
      // 维度3：经典流派应对
      const cs=sp.classicSchool;
      if(cs&&cs.conf>0.35){
        switch(cs.style){
          case 'cosmicFlow': // 宇宙流 - 打入破空
            score+=this.evaluateInvasion(aiSide)*cs.conf*0.7;
            break;
          case 'pragmatic': // 务实流 - 厚势对抗
            score+=this.evaluateMoyo(aiSide)*cs.conf*0.5;
            break;
        }
      }
      
      // 维度4：局面把握应对
      const sit=sp.situation;
      if(sit&&sit.conf>0.35){
        switch(sit.style){
          case 'combat': // 战斗型 - 避免复杂局面
            score-=2*sit.conf;
            break;
          case 'stable': // 平稳型 - 制造战斗
            score+=this.evaluateInvasion(aiSide)*sit.conf*0.4;
            break;
        }
      }
      
      // 风格切换时降低应对权重
      if(this.styleShiftDetected){
        // 降低风格应对权重，增加不确定性
      }
    }
    return aiSide==='white'?score:-score;
  }
  evaluateMoyo(side){
    // 大模样评估：统计己方棋子控制的区域
    let territory=0;
    for(let r=0;r<this.SIZE;r++)for(let c=0;c<this.SIZE;c++){
      if(this.board[r][c])continue;
      let nearOwn=0,nearOpp=0;
      for(let dr=-3;dr<=3;dr++)for(let dc=-3;dc<=3;dc++){
        const nr=r+dr,nc=c+dc;
        if(nr>=0&&nr<this.SIZE&&nc>=0&&nc<this.SIZE){
          if(this.board[nr][nc]===side)nearOwn++;
          else if(this.board[nr][nc])nearOpp++;
        }
      }
      if(nearOwn>nearOpp*2)territory++;
    }
    return territory*0.5;
  }
  evaluateInvasion(side){
    // 侵入评估：奖励深入对方阵地的棋子
    let invasion=0;
    const opp=this.opp(side);
    for(let r=0;r<this.SIZE;r++)for(let c=0;c<this.SIZE;c++){
      if(this.board[r][c]!==side)continue;
      // 看周围是否是对方的地盘
      let nearOpp=0;
      for(let dr=-2;dr<=2;dr++)for(let dc=-2;dc<=2;dc++){
        const nr=r+dr,nc=c+dc;
        if(nr>=0&&nr<this.SIZE&&nc>=0&&nc<this.SIZE&&this.board[nr][nc]===opp)nearOpp++;
      }
      if(nearOpp>=3)invasion+=10;
    }
    return invasion;
  }
  evaluateConnection(side){
    // 连接评估：奖励己方棋子连片
    let connected=0;
    for(let r=0;r<this.SIZE;r++)for(let c=0;c<this.SIZE;c++){
      if(this.board[r][c]!==side)continue;
      let nearOwn=0;
      for(const [dr,dc] of [[1,0],[-1,0],[0,1],[0,-1]]){
        const nr=r+dr,nc=c+dc;
        if(nr>=0&&nr<this.SIZE&&nc>=0&&nc<this.SIZE&&this.board[nr][nc]===side)nearOwn++;
      }
      connected+=nearOwn;
    }
    return connected*2;
  }
  getCandidates(){
    if(this.moveHistory.length===0){
      const s=Math.floor(this.SIZE/4);
      return[{row:s,col:s},{row:s,col:this.SIZE-1-s},{row:this.SIZE-1-s,col:s},{row:this.SIZE-1-s,col:this.SIZE-1-s}];
    }
    const set=new Set(),cands=[];
    for(let r=0;r<this.SIZE;r++)for(let c=0;c<this.SIZE;c++){
      if(this.board[r][c]){
        for(let dr=-2;dr<=2;dr++)for(let dc=-2;dc<=2;dc++){
          const nr=r+dr,nc=c+dc;
          if(nr>=0&&nr<this.SIZE&&nc>=0&&nc<this.SIZE&&!this.board[nr][nc]){
            if(this.koPoint&&this.koPoint.row===nr&&this.koPoint.col===nc)continue;
            const k=nr*100+nc;
            if(!set.has(k)){set.add(k);cands.push({row:nr,col:nc});}
          }
        }
      }
    }
    // 大场点：跨棋盘的大片空白中枢，让 AI 有大局观、落子分散而有强度，不扎堆
    for(const b of this.bigPoints()){
      const k=b.row*100+b.col;
      if(!this.board[b.row][b.col]&&!set.has(k)&&!(this.koPoint&&this.koPoint.row===b.row&&this.koPoint.col===b.col)){
        set.add(k);cands.push({row:b.row,col:b.col});
      }
    }
    return cands;
  }
  bigPoints(){
    // 找出棋盘上各片连通空白区域的中枢点与三~四线好点，作为「大场」候选
    const s=this.SIZE,pts=[];
    const visited=Array.from({length:s},()=>Array(s).fill(false));
    for(let r=0;r<s;r++)for(let c=0;c<s;c++){
      if(this.board[r][c]||visited[r][c])continue;
      const stack=[[r,c]],cells=[];
      while(stack.length){
        const [cr,cc]=stack.pop();
        if(cr<0||cr>=s||cc<0||cc>=s||visited[cr][cc]||this.board[cr][cc])continue;
        visited[cr][cc]=true;cells.push([cr,cc]);
        stack.push([cr-1,cc],[cr+1,cc],[cr,cc-1],[cr,cc+1]);
      }
      if(!cells.length)continue;
      // 区域中枢（取离几何中心最近的空点）
      const cx=cells.reduce((a,p)=>a+p[0],0)/cells.length;
      const cy=cells.reduce((a,p)=>a+p[1],0)/cells.length;
      let cen=cells[0],cd=Infinity;
      for(const [gr,gc] of cells){const d=Math.abs(gr-cx)+Math.abs(gc-cy);if(d<cd){cd=d;cen=[gr,gc];}}
      pts.push({row:cen[0],col:cen[1]});
      // 三~四线好点（利于围空/拆边）
      let best=null,bsp=-1;
      for(const [gr,gc] of cells){
        const ld=this.lineDist(gr,gc);
        const sp=(ld>=2&&ld<=3)?3:(ld===4?1:0.1);
        if(sp>bsp){bsp=sp;best=[gr,gc];}
      }
      if(best)pts.push({row:best[0],col:best[1]});
    }
    return pts;
  }
  // ===== 绘制 =====
  draw(){
    const ctx=this.ctx;const cs=this.cellSize;const size=this.SIZE;
    ctx.clearRect(0,0,this.canvas.width,this.canvas.height);
    ctx.fillStyle='#dcb35c';ctx.fillRect(0,0,this.canvas.width,this.canvas.height);
    ctx.strokeStyle='#3a2a10';ctx.lineWidth=0.7;
    for(let i=0;i<size;i++){
      ctx.beginPath();ctx.moveTo(this.offset,this.offset+i*cs);ctx.lineTo(this.offset+(size-1)*cs,this.offset+i*cs);ctx.stroke();
      ctx.beginPath();ctx.moveTo(this.offset+i*cs,this.offset);ctx.lineTo(this.offset+i*cs,this.offset+(size-1)*cs);ctx.stroke();
    }
    ctx.fillStyle='#3a2a10';
    const so=size===19?3:(size===13?3:2),sm=Math.floor(size/2);
    const stars=[[so,so],[so,size-1-so],[size-1-so,so],[size-1-so,size-1-so],[sm,sm]];
    if(size>=13)stars.push([so,sm],[size-1-so,sm],[sm,so],[sm,size-1-so]);
    stars.forEach(([r,c])=>{ctx.beginPath();ctx.arc(this.offset+c*cs,this.offset+r*cs,cs*0.09,0,Math.PI*2);ctx.fill();});
    if(this.moveHistory.length>0){
      const last=this.moveHistory[this.moveHistory.length-1];
      if(!last.pass){ctx.strokeStyle='#c8342c';ctx.lineWidth=1.8;ctx.beginPath();ctx.arc(this.offset+last.col*cs,this.offset+last.row*cs,cs*0.18,0,Math.PI*2);ctx.stroke();}
    }
    for(let r=0;r<size;r++)for(let c=0;c<size;c++){
      const p=this.board[r][c];if(!p)continue;
      const x=this.offset+c*cs,y=this.offset+r*cs,rad=cs*0.43;
      const grad=ctx.createRadialGradient(x-rad*0.3,y-rad*0.3,rad*0.1,x,y,rad);
      if(p==='black'){grad.addColorStop(0,'#555');grad.addColorStop(1,'#111');}
      else{grad.addColorStop(0,'#fff');grad.addColorStop(1,'#d0d0d0');}
      ctx.beginPath();ctx.arc(x,y,rad,0,Math.PI*2);ctx.fillStyle=grad;ctx.fill();
      ctx.strokeStyle=p==='black'?'#000':'#999';ctx.lineWidth=0.5;ctx.stroke();
    }
  }
}
