#!/usr/bin/env bash
# 棋王 · 一键启动本地服务器（外部可连接）
# 用法: bash start.sh   （Linux / macOS）
cd "$(dirname "$0")"

if command -v python3 >/dev/null 2>&1; then PY=python3
elif command -v python >/dev/null 2>&1; then PY=python
else
  echo "未找到 Python，请先安装 Python 3，再执行: pip install -r 入口文件/requirements.txt"
  exit 1
fi

# 首次运行自动安装依赖
if ! $PY -c "import fastapi,uvicorn" >/dev/null 2>&1; then
  echo "首次运行，正在安装依赖（fastapi/uvicorn/openai）..."
  $PY -m pip install -r 入口文件/requirements.txt
fi

echo "============================="
echo "  棋王启动中… 本机访问: http://localhost:8000/"
echo "  手机/其它设备连同一局域网，用启动日志里的 LAN 地址即可连接"
echo "  围棋 KataGo 神经网络必须通过本服务器访问，请勿双击 HTML 直接打开"
echo "============================="
exec $PY 入口文件/main.py
